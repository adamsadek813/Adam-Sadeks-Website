void say_hello_to(char *);
