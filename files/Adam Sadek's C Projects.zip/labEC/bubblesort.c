#include <stdio.h>

void bubblesort(int [], int);
void swap(int*,int*);

int main()
{
  //write your code here to sort an array of 10 integers
  return 0;
}

void swap(int *i, int *j) {
	//write your code to swap the values of i and j
}

void bubblesort(int list[], int n)
{
	//write your code to sort the array list[] using the swap function and bubble sort algorithm
}
