#!/bin/bash

./cpubench flops single 1 1
./cpubench flops double 1 1
./cpubench matrix single 1024 1
./cpubench matrix double 1024 1