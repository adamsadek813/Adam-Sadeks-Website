import java.util.Random;
public class SwitchNoSwitch {

	public static void main(String[] args) {
		double sumOfWinSwitches = 0;
		for(int x=0;x<1000000; x++) {
		double switchedDoors = montyHallTrial(true);
		sumOfWinSwitches += switchedDoors;
		}
		double sumOfWinStays = 0;
		for(int x=0;x<1000000; x++) {
			double nonSwitchedDoors = montyHallTrial(false);
			sumOfWinStays += nonSwitchedDoors;
			}
		System.out.println("Win percentage when switching doors is: " + (sumOfWinSwitches / 1000000) * 100 + "%" );
		System.out.println("Win percentage when not switching doors is: " + (sumOfWinStays / 1000000) * 100 + "%" );

	}

	public static int  montyHallTrial (boolean playerSwitch){
		 Random randomizer = new Random();
			int win = 0;
			int [] doors = {0,0,0};
			doors[randomizer.nextInt(3)] = 1;  
			int doorChosen = randomizer.nextInt(3);
			int whereCarIsnt;
			do {
				whereCarIsnt = randomizer.nextInt(3);
			} while(whereCarIsnt == doorChosen || doors[whereCarIsnt] == 1);

			
				if(playerSwitch == true) {
		win = doors[doorChosen];
				}
		else {
			win = doors[3 - doorChosen - whereCarIsnt];
		}
				return win;
	}
}
	
	 



