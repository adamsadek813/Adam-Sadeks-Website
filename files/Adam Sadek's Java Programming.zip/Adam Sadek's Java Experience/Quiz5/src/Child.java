
public class Child {

public int howdy() {
	return 7;
}
}