
final public class Parent {

	public int howdy() {
		return 5;
	}
	
	
}
