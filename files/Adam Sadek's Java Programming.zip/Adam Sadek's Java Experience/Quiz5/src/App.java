
public class App {
	public static void main(String [] args) {
		
		int [] arr = {-2,3,-4,5,11,9};
		int a = 5;
		int b = 2 * (a % 2);
		int c = (int) Math.pow(2, b);

		int g = 2;

		while (g > 0){
		  g--;
		  c--;
		}
		System.out.println(arr[c]);
		}
}
