/**
 * @author Adam Sadek
 * @author Gabriel Roskowski
 */

import java.util.Scanner;

public class VehicleClient {
	public static void main(String[] args) {
		Vehicle vehicle0 = new Vehicle(-1); // testing the constructor
		System.out.println(vehicle0);// id, lineArrivalTime and boothArrivalTime should be zero. boothLeaveTime
										// should be max integer.

		vehicle0 = new Vehicle(0); // testing the constructor again
		System.out.println(vehicle0); // id should be one (the second existing vehicle instance), lineArrivalTime and
										// boothArrivalTime should be zero. boothLeaveTime should be max integer

		Vehicle vehicle1 = new Vehicle(10);// testing the constructor again
		System.out.println("Vehicle count for third vehicle: " + Vehicle.getVehicleCount()); // should print 3
		System.out.println(vehicle1); // should print lineArrivalTime and boothArrivalTime as 10 and boothLeaveTime
										// still as max integer. the vehicle id should be 2

		vehicle1.setBoothArrivalTime(5);// testing the logic of the mutators (boothArrivalTime should then be set to
										// zero)

		// the mutator method shouldn't allow the variable that is being modified to be
		// changed if incongruences are detected. Currently it is being set to zero. But
		// when that happens, internal incongruences may happen. The value should just
		// remain unchanged logically

		System.out.println(vehicle1); // should print the lineArrivalTime as 10, the boothArrivalTime as 0 and
										// boothLeaveTime and id remain unchanged

		vehicle1.setBoothArrivalTime(15);// testing the correct mutation

		System.out.println(vehicle1); // should print lineArrivalTime as 10, boothArrivalTime as 15 and boothLeaveTime
										// and id remain unchanged

		vehicle1.setBoothLeaveTime(15);// this shouldn't be allowed as the vehicle shouldn't leave at the same time as
										// arriving

		System.out.println(vehicle1); // should print lineArrivalTime as 10, boothArrivalTime as 15 and boothLeaveTime
										// as 0 and id remains 2

		vehicle1.setBoothLeaveTime(20);// testing valid mutation for boothLeaveTime

		System.out.println(vehicle1); // should print lineArrivalTime as 10, boothArrivalTime as 15 and boothLeaveTime
										// as 20 and id remains 2

		vehicle1.setBoothArrivalTime(25);// that would be an illegal mutation that should not be allowed

		System.out.println(vehicle1); // should print lineArrivalTime as 10, boothArrivalTime as 0 and boothLeaveTime
										// as 0 and id remains 2

		vehicle1.setBoothArrivalTime(12);// going back to valid with boothArrivalTime

		vehicle1.setLineArrivalTime(8);// should set line arrival time to 8 without problem

		System.out.println("(After legal changes)");
		System.out.println("Vehicle 3 ID: " + vehicle1.getId());// should print 2
		System.out.println("Vehicle 3 line arrival time: " + vehicle1.getLineArrivalTime());// should print 8
		System.out.println("Vehicle 3 booth arrival time: " + vehicle1.getBoothArrivalTime());// should print 12
		System.out.println("Vehicle 3 booth leave time: " + vehicle1.getBoothLeaveTime());// should print 20

		// testing illegal values
		vehicle1.setLineArrivalTime(-1);
		vehicle1.setBoothArrivalTime(-1);
		vehicle1.setBoothLeaveTime(-1);
		System.out.println("(After illegal changes)");
		System.out.println("Vehicle 3 line arrival time: " + vehicle1.getLineArrivalTime());// should print 0
		System.out.println("Vehicle 3 booth arrival time: " + vehicle1.getBoothArrivalTime());// should print 0
		System.out.println("Vehicle 3 booth leave time: " + vehicle1.getBoothLeaveTime());// should print 0

		//User input loop
		Scanner myScanner = new Scanner(System.in);
		while (true) {
			try {
				System.out.println("What time did your car arrive to the line?");
				int lineArrivalTime = myScanner.nextInt();
				Vehicle newVehicle = new Vehicle(lineArrivalTime);
				System.out.println("What time did your car arrive to the booth?");
				newVehicle.setBoothArrivalTime(myScanner.nextInt());
				System.out.println("What time did your car leave the booth?");
				newVehicle.setBoothLeaveTime(myScanner.nextInt());
				System.out.println(newVehicle);
			} catch (Exception e) {
				// If the user inputs something wrong that causes exception, runs the loop again
				System.out.println("Input Error. Try again");
				myScanner = new Scanner(System.in);
			}
		}

	}

}