/**
 * @author Adam Sadek
 * @author Gabriel Roskowski
 */

public class Vehicle {
	private static int vehicleCount;

	private int id;

	private int lineArrivalTime;
	private int boothArrivalTime;
	private int boothLeaveTime;

	public Vehicle(int lineArrivalTime) {
		// Increments the id
		id = vehicleCount++;

		// Assuming boothArrivalTime = lineArrivalTime and boothLeaveTime = max integer
		// value. It considers that when the car arrived, there were no others on the
		// line. And the car still hasn't left the lot

		setBoothLeaveTime(Integer.MAX_VALUE);

		// The leaving time should be set before everything. Otherwise the mutator will
		// not allow, as things should not happen after the car already left

		setBoothArrivalTime(lineArrivalTime);

		// BoothArrivalTime should be set before lineArrivalTime, otherwise the mutator
		// will not allow

		setLineArrivalTime(lineArrivalTime);

		// This was the interpretation we had about the default values for booth arrival
		// and booth leaving times
	}

	@Override
	public String toString() {
		return "[Vehicle id: " + id + ", Line arrival: " + lineArrivalTime + ", Booth arrival: " + boothArrivalTime
				+ ", Booth leaving: " + boothLeaveTime + "]";
	}

	// Checks the validity conditions for the provided values (everything great or
	// equal to zero and lineArrivalTime <= boothArrivalTime < boothLeaveTime)
	private boolean checksValidity(long lineArrivalTime, long boothArrivalTime, long boothLeaveTime) {
		return lineArrivalTime >= 0 && lineArrivalTime <= boothArrivalTime && boothArrivalTime < boothLeaveTime;
	}

	public static int getVehicleCount() {
		return vehicleCount;
	}

	public int getId() {
		return id;
	}

	public int getLineArrivalTime() {
		return lineArrivalTime;
	}

	public void setLineArrivalTime(int lineArrivalTime) {
		if (checksValidity(lineArrivalTime, boothArrivalTime, boothLeaveTime))
			this.lineArrivalTime = lineArrivalTime;
		else
			this.lineArrivalTime = 0;
	}

	public int getBoothArrivalTime() {
		return boothArrivalTime;
	}

	public void setBoothArrivalTime(int boothArrivalTime) {
		if (checksValidity(lineArrivalTime, boothArrivalTime, boothLeaveTime))
			this.boothArrivalTime = boothArrivalTime;
		else
			this.boothArrivalTime = 0;
	}

	public int getBoothLeaveTime() {
		return boothLeaveTime;
	}

	public void setBoothLeaveTime(int boothLeaveTime) {
		if (checksValidity(lineArrivalTime, boothArrivalTime, boothLeaveTime))
			this.boothLeaveTime = boothLeaveTime;
		else
			this.boothLeaveTime = 0;
	}
}