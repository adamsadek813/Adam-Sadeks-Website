import java.util.Random;
public class CoinPatterns {
  public static void main(String [] args) {
	  int [] seq = null;
	  // Set up the random number generator ** **********
	  Random rand = new Random();
	  if (rand.nextInt(2) == 1){
		seq = new int[100];
		for (int i = 0; i < seq.length; i++){
			seq[i] = rand.nextInt(2);
			System.out.print(seq[i]+" ");
		}
		System.out.println();
	  }
	  CoinTosses flip = new CoinTosses();
	  System.out.println(flip.locate(seq,0,3));
	  System.out.println(flip.locate(seq,1,5));
  }
}
