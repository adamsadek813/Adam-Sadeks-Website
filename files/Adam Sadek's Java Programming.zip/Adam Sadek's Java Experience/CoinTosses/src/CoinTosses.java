import java.lang.NullPointerException;
public class CoinTosses {

	
	int locate(int [] reference, int whichSide, int lengthDesired){
	int length=1;
	int index=-1;
	int success = -1;
	int failure = -1;
	try {
	int [] arr = new int[reference.length];
	for(int x = 0; x<reference.length; x++) {
	arr[x] = reference[x];
	}
		for(int i = arr.length-1; i > 0; i--) {
			int j = i-1;
			if(arr[i]==arr[j] && whichSide == arr[j]) {
				length++;
				if (length == lengthDesired || length > lengthDesired) {
					success = j;
				}
			}
			else {length = 1;
			}
		}
		if(success !=-1) {
			return success;
			}
				else {return failure;
				}
	}
 catch (NullPointerException NPE) {
		System.out.println("Given array is null");
		return -1;
	}
		}
}


