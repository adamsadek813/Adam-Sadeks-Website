
public class Polynomials {

	int k;
	double [] coefficients;
	Polynomials(int k) {
		coefficients = new double [k];
	}
	
	public double getKthCoefficient(int whichCoefficient) {
		return coefficients[whichCoefficient];
	}
	public void setKthCoefficient(int whichCoefficient, double newCoefficient) {
		coefficients[whichCoefficient] = newCoefficient;
	}
}
