import java.util.Scanner;
public class PolynomialsApp {
	 public static void main(String args[]){
		 

		 
		 Scanner myScanner = new Scanner(System.in);
		 System.out.println("What is the value of x?");
		 double xValue = myScanner.nextDouble();
		 
		
		 Scanner myScanner2 = new Scanner(System.in);
		 System.out.println("What is the value of k?");
		 int kValue = myScanner2.nextInt();
		 if(kValue > 2) {
		 Polynomials polynomials = new Polynomials(kValue);
		 int increment = 0;
		 for(int x = 0; x < polynomials.coefficients.length; x++) {
			 increment++;
			 System.out.println("What is the value for coefficient " + increment + "?");
			 Scanner myScanner3 = new Scanner(System.in);
			 double newCoefficient = myScanner3.nextDouble();
			 polynomials.setKthCoefficient(x, newCoefficient);
		 }
		 
		 double y = 0;
		 for(int x = 0; x < polynomials.coefficients.length; x++) {
			y = y + polynomials.getKthCoefficient(x) * Math.pow(xValue, polynomials.getKthCoefficient(x) - x); 
			
		 }
		 System.out.println("y= " + y);
		 }
		 else {System.out.println("k must be greater than 2!");
		 }
		 
		
	 }
}
