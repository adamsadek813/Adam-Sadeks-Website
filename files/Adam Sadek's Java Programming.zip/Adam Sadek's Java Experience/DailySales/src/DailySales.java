import java.util.Arrays;

public class DailySales {

	int daysInMonth;
	int [] daySales;
	
	DailySales() {
		daySales =  new int[31];
		daysInMonth = 31;
	}
	
	DailySales(int newDaysInMonth){
		if(newDaysInMonth < 32 && newDaysInMonth > 27) {
		daySales =  new int[newDaysInMonth];
		daysInMonth = newDaysInMonth;
	}
		else {
			System.out.println("Value error. Days in month set to 31");
			daysInMonth = 31;
			daySales =  new int[daysInMonth];
		}
	}
	
	public boolean addSales(int dayNumber, int sales) {
	boolean worked;
		if(dayNumber > 0 && dayNumber <= daysInMonth && sales >= 0) {
		daySales[dayNumber - 1] = sales;
			worked = true;
		}
			else {worked = false;}
		return worked;
	}
	
	public int maxDay() {
		int greatestSales = -1;
		int maximumDay = 0;
		for(int x = 0; x < daySales.length; x++ ) {
			if(greatestSales < daySales[x]) {
				greatestSales = daySales[x];
				maximumDay = x + 1;
			}
		}
		return maximumDay;
	}
	
	public  int[] daysBelowGoal() {
		int numberOfBelow100Days = 0;
	for(int index = 0; index < daySales.length; index++) {
		if(daySales[index] < 100) {
			numberOfBelow100Days++;
		}
	}
	int [] lowDays = new int[numberOfBelow100Days];
	int lowDaysIndex = 0;
	for(int index = 0; index < daySales.length; index++) {
		if(daySales[index] < 100) {
			lowDays[lowDaysIndex] = index + 1;
			lowDaysIndex++;
		}
	}
		return lowDays;
	}

	@Override
	public String toString() {
		return "DailySales [daysInMonth=" + daysInMonth + ", daySales=" + Arrays.toString(daySales) + "]";
	}

	
}

