import java.util.Arrays;
public class DailySalesApp {
	public static void main (String args []) {
		DailySales a = new DailySales();
		a.addSales(5,600);
		a.addSales(3,10);
		a.addSales(4,190);
		a.addSales(2,120);
		a.addSales(1,90);
		a.addSales(6,90);
		a.addSales(7,90);
		a.addSales(8,90);
		a.addSales(9,90);
		a.addSales(10,90);
		a.addSales(11,90);
		a.addSales(12,90);
		a.addSales(13,130);
		a.addSales(14,90);
		a.addSales(15,140);
		a.addSales(16,90);
		a.addSales(17,90);
		a.addSales(18,90);
		a.addSales(19,90);
		a.addSales(20,113);
		a.addSales(21,90);
		a.addSales(22,90);
		a.addSales(23,118);
		a.addSales(24,90);
		a.addSales(25,90);
		a.addSales(26,90);
		a.addSales(27,210);
		a.addSales(28,90);
		a.addSales(29,260);
		a.addSales(30,90);
		a.addSales(31,130);
		System.out.println(a.toString());
		System.out.println(Arrays.toString(a.daysBelowGoal()));
	}
}
