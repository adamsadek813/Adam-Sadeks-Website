import java.util.Scanner;
import java.util.InputMismatchException;
public class LoanDecisionApp {
	public static void main(String[] args) {
		
		boolean qualify;
		boolean properInput = false;
		do {
			try {
		Scanner myScanner = new Scanner(System.in);
		System.out.println("What is your salary in USD?");
		double userSalary = myScanner.nextDouble();
		if (userSalary <= 60000) {
			System.out.println("Does not qualify");
			qualify = false;
			properInput = true;
			System.exit(0);
		}
		else {
		System.out.println("How many years have you held your current job?");
		int userYears = myScanner.nextInt();
		if (userYears > 3) {
			System.out.println("Qualifies");
			properInput = true;
			qualify = true;
		}
		else {
				System.out.println("Does not qualify");
				qualify = false;
				properInput = true;
			}
		}
			
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Try again.");
			properInput = false;
		}
		} while (properInput == false);
	}
}
