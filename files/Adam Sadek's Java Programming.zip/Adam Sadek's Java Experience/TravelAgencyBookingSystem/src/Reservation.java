import java.util.Random;
public abstract class Reservation {
	protected static int IDCounter;
	protected int ID;
	protected String customerName;
	protected double price;
	
	public Reservation(String newCustomerName){
		Random rng = new Random();
		this.ID = this.IDCounter++;
		this.customerName = newCustomerName;
		this.price = rng.nextInt(2000);
	}
	
	public int getID(){
		return this.ID;
	}
	
	public String getCustomerName(){
		return this.customerName;
	}

	public double getPrice(){
		return this.price;
	}	
}
