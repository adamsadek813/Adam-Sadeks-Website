import java.util.ArrayList;
public class AppClass {
	public static void main(String[] args) {

	ArrayList<Reservation> flightList = new ArrayList<Reservation>();
	Reservation myFlight = new FlightReservation("AX745","Cate Blanchett");
	flightList.add(myFlight);
	myFlight = new FlightReservation("AX745","That CS 116 guy");
	flightList.add(myFlight);
	myFlight = new FlightReservation("AX745","Franz Kafka");
	flightList.add(myFlight);
	myFlight = new FlightReservation("AX745","Tom Cruise");
	flightList.add(myFlight);
	myFlight = new FlightReservation("AX745","Beetlejuice");
	flightList.add(myFlight);
	System.out.println(flightList);

	
}
}