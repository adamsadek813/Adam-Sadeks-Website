
public class FlightReservation extends Reservation {
	
	private String flightCode;


	
	public FlightReservation(String newFlightCode, String newCustomerName) {
		super(newCustomerName);
		flightCode = newFlightCode;
	}

	
	public String getFlightCode() {
		return flightCode;
	}

	@Override
	public String toString() {
		return  "\n" + "[ID: " + ID + " | Flight: " + flightCode + " | Passenger: " + customerName +
				 " | Price: " + price + "]" ;
	}
	
	
	
}
