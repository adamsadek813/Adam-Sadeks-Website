

public class Square {
	private double side;
	private Point2D lowerLeft;

	public Square(double initialSide, Point2D initialLowerLeft) {
		this.side = initialSide < 0 ? 0 : initialSide;
		this.lowerLeft = initialLowerLeft == null ? new Point2D() : initialLowerLeft;
	}

	public Square() {
		this(0, null);
	}

	public Square(Square otherSquare) {
		this(otherSquare == null ? 0 : otherSquare.side,
				otherSquare == null || otherSquare.lowerLeft == null ? new Point2D()
						: new Point2D(otherSquare.lowerLeft.getX(), otherSquare.lowerLeft.getY()));
	}

	public double getArea() {
		return side * side;
	}

	public double getCircumference() {
		return 4 * side;
	}

	@Override
	public String toString() {
		return "Square: lower left corner: " + lowerLeft + " | side: " + side + " | area: " + getArea()
				+ " | circumference: " + getCircumference();
	}

	public boolean equals(Square square) {
		return square != null && square.side == this.side && square.lowerLeft.equals(this.lowerLeft);
	}

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = side;
	}

	public Point2D getLowerLeft() {
		return lowerLeft;
	}

	public void setLowerLeft(Point2D lowerLeft) {
		this.lowerLeft = lowerLeft;
	}

}
