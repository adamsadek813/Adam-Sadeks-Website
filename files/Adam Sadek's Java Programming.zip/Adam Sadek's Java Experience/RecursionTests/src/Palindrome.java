
public class Palindrome {
	  public static void main( String [] args ) {
		  
		System.out.println(isPalindrome("tacocat"));
		  
	  }
	  public static boolean isPalindrome(String string) {
		  if(string.length() == 1 || string.length() == 0){
			  return true;
		  }
			  else {
				  if(string.charAt(0) == string.charAt(string.length()-1)){
					  return isPalindrome(string.substring(1, string.length()-1));
					  }
					  else{
					  return false;
					  }
  
			  }
	  }
}
