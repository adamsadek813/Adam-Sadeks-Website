import java.util.Scanner;
public class FindDuplicatesApp {
	public static void main (String args[]) {
		
		Scanner myScanner = new Scanner(System.in);
		System.out.println("Enter file name > ");
		String fileName = myScanner.next();
		System.out.println("FileName: " + fileName + " \n" + "DUPLICATES:");
		FindDuplicates file1 = new FindDuplicates(fileName);
		System.out.println(file1.getDuplicates());
		
	}
}
