import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class FindDuplicates{
	
	String fileName;
	File inputFile;
	FindDuplicates(String newFileName){
		inputFile = new File(newFileName);
		fileName = newFileName;
	}

	String getFileName(){
		return fileName;
	}
	
	void setFileName(String newFileName) {
		fileName = newFileName;
	}
	
	String getDuplicates() {
		String foundDuplicates = "";
		try {
			Scanner fileScanner = new Scanner(inputFile);
			int index = 0;
			while (fileScanner.hasNextLine()) {
				String dummy = fileScanner.nextLine(); 
				index++;
			}
			fileScanner.close();
			Scanner fileScanner2 = new Scanner(inputFile);
			String [] anArray = new String[index];
			for(int x = 0; x < anArray.length; x++) {
				anArray[x] = fileScanner2.nextLine();
			}
			boolean found = false;
			String previous = "";
			for (int i = 0; i < anArray.length-1; i++) {
				int j = i+1;
						if (anArray[i].substring(0,6).equals(anArray[j].substring(0,6)) && i != j) {
							found = true;
							foundDuplicates = foundDuplicates + (j+1) + ": " + anArray[j] + " \n";
						}
						else {
							found = false;
						}
				}	
		}catch (FileNotFoundException fnfe) {
			System.out.println("Message: " + fnfe.getMessage());
			System.out.println("\ntoString( ): " + fnfe + "\n" );
			fnfe.printStackTrace();
			}
		return foundDuplicates;
	}

	public String toString() {
		return "FindDuplicates [fileName = " + fileName + "]";
	}
}
