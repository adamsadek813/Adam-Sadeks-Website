
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringJoiner;

public class UnsortedDataApp {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		// Main loop that keeps asking the user for input
		while (true) {
			System.out.print("What is the name of the input file? ");
			double[] sorted = read(scanner.nextLine());

			// Skips if the array is empty
			if (sorted.length == 0)
				continue;

			System.out.println("Total Out of Order BEFORE Bubble = " + UnsortedData.countOutOfPositions(sorted));
			UnsortedData.bubble(sorted);
			System.out.println("Total Out of Order AFTER Bubble = " + UnsortedData.countOutOfPositions(sorted) + "\n");
		}

		// dataRandom.txt - seems like the average scenario
		// dataSorted.txt - the best scenario (score is zero)
		// dataReverseSorted.txt - the worst scenario (is it a coincidence that the
		// worst sortedness score will be n(n-1)/2 with n being the array lenght?)

	}

	// Method to read a double array from a file with the path + name
	private static double[] read(String name) {
		StringJoiner sj = new StringJoiner(" ");
		int q = 0;
		try {
			Scanner scanner = new Scanner(new File(name));
			while (scanner.hasNext()) {
				q++;
				sj.add(scanner.nextLine());
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			System.out.println("This file was not found!");
			return new double[0];
		}
		double array[] = new double[q];
		try {
			Scanner scanner = new Scanner(sj.toString());
			int i = 0;
			// Cant't just read next double because of different java locales (point as
			// decimal separator gives exception in Brazil)
			while (scanner.hasNext())
				array[i++] = Double.parseDouble(scanner.next());
			scanner.close();
		} catch (NumberFormatException e) {
			System.out.println("There is a problem with the data in the file!");
			return new double[0];
		}
		return array;
	}
}
