

public class UnsortedData {
	// Scores a sortedness value to a double array by counting how many out of
	// positions items there are
	public static int countOutOfPositions(double[] arr) {
		int out = 0;
		for (int n = 0; n < arr.length; n++)
			for (int z = n + 1; z < arr.length; z++)
				if (arr[z] < arr[n])
					out++;
		return out;
	}

	// Executes the bubble operation in the array
	public static void bubble(double[] arr) {
		for (int n = 0; n < arr.length - 1; n++)
			if (arr[n] > arr[n + 1]) {
				double temp = arr[n + 1];
				arr[n + 1] = arr[n];
				arr[n] = temp;
			}
	}

	// An experiment just to test what would bubble sort be (in the worst case, it
	// should make the last element to be the first one, needing n swaps)
	public static void bubbleSort(double[] arr) {
		for (int n = 0; n < arr.length; n++)
			bubble(arr);
	}

	// A method to print the array
	public static void print(double[] array) {
		for (double d : array)
			System.out.print(d + ", ");
		System.out.println();
	}
}
