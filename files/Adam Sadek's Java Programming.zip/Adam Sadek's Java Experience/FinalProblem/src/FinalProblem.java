	public class FinalProblem {
		public static void main(String [] str){
			int [] a = {2,3,5,8,14};
			int [] b = {1,2,6,8,3};
			System.out.println(callMe(a, 0, a.length-1));
			System.out.println(callMe(b, 0, b.length-1));
		}
		static int sum = 0;
		public static int callMe(int [] arr, int m, int n){
			if (n==-1) {
				return m;
			}
			else{
				if (arr[n]%2 == 0) {
					m = m +arr[n];
			}
				return callMe( arr,  m,  n-1);
		}
		}
	}

