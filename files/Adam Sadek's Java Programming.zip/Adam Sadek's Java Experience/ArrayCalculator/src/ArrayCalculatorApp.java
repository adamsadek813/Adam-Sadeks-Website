import java.util.Random;
public class ArrayCalculatorApp {
	 public static void main(String args[]){

	 Random randomizer = new Random();
	 
	 int [] array1 = new int[100];
	 
	 int [] array2 = new int[100];
	 
	 for (int x = 0; x < array1.length; x++) {
		 array1[x] = randomizer.nextInt(100)+1;
		 array2[x] = randomizer.nextInt(100)+1;
	 }
	
	 double minimumValue1 = 100;
	 double maximumValue1 = 0;
	 double minimumValue2 = 100;
	 double maximumValue2 = 0;
	 for (int y = 0; y<array1.length;y++) {
		 if(array1[y] < minimumValue1) {
			 minimumValue1 = array1[y];
		 }
		 if(array1[y]>maximumValue1) {
			 maximumValue1 = array1[y];
		 }
		 if(array2[y] < minimumValue2) {
			 minimumValue2 = array2[y];
		 }
		 if(array2[y]>maximumValue2) {
			 maximumValue2 = array2[y];
		 }
	 }
	 
	double productOfArray1 = 1;
	double productOfArray2 = 1;
		 for (int z = 0; z<array1.length;z++) {
			 productOfArray1 = productOfArray1 * array1[z];
			 productOfArray2 = productOfArray2 * array2[z];
		 }
	
	int [] lowerProductArray;
	if(productOfArray1 > productOfArray2) {
		lowerProductArray = array2;
	}
	else
		if (productOfArray1 < productOfArray2) {
			lowerProductArray = array1;
		}
		else { lowerProductArray = array2;
		
		}

	
	double p = 9;
	if(lowerProductArray == array2) {
		p = ((maximumValue2 - minimumValue2)/maximumValue2) * 100;
	}
	else {
		p = ((maximumValue1 - minimumValue1)/maximumValue1) * 100;
	}
	
	 System.out.println("Minimum element in this array is " + p +  " % smaller than its maximum");

}

}