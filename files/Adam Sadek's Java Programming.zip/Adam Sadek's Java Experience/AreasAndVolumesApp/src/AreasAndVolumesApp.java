import java.util.Scanner;
public class AreasAndVolumesApp {
	public static void main (String args[]){

	Scanner scan = new Scanner (System.in);
		System.out.println("Enter cube side length > ");
	double cubeSideLength = scan.nextDouble();
	
	 double cubeSurfaceArea = 6 * Math.pow(2, cubeSideLength);
	 double sphereRadiusSameSurfaceArea = Math.sqrt(cubeSurfaceArea/(4*Math.PI));
	 System.out.println("The radius of a sphere with the same cube side length is: " + sphereRadiusSameSurfaceArea);
	 
	 double cubeVolume = Math.pow(3,  cubeSideLength);
	 double sphereRadiusSameVolume = Math.cbrt((3 * cubeVolume) / 4 * Math.PI);
	 System.out.println("The radius of a sphere with the same cube volume is: " + sphereRadiusSameVolume);
	}
}
