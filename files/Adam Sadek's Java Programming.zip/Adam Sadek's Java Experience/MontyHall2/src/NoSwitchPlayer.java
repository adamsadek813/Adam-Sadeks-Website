import java.util.Random;

public class NoSwitchPlayer extends Player implements PlayerInterface {

	int initialSelection;
	Random myRandom = new Random();
	
	@Override
	public int selectDoorAgain(int openDoor) {
		return selectedDoor;
	}

	@Override
	public int selectDoor() {
		selectedDoor = myRandom.nextInt(3)+1;
		return selectedDoor;
	}

}
