public interface PlayerInterface {
	// Abstract method
	// Make second prize location "guess"
	// Knowing which door is open (with no prize)
	public abstract int selectDoorAgain(int openDoor);
}

