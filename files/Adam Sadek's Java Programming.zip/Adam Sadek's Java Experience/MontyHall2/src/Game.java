import java.util.Random;
public class Game {
	
private int prizeLocation;
Random randomDoor = new Random();

public Game() {
	prizeLocation = randomDoor.nextInt(3) + 1;
}

public int getPrizeLocation() {
	return prizeLocation;
}

public void reset() {
	prizeLocation = randomDoor.nextInt(3) + 1;
}

public int getOpenDoor(int initialGuess) {
	int openDoor;
	do{
		openDoor = randomDoor.nextInt(3)+1;
		}
	while(openDoor == initialGuess || openDoor == prizeLocation);
	return openDoor;
}

}
