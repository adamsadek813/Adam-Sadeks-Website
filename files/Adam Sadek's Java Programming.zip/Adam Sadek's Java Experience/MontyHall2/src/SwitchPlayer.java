import java.util.Random;
public class SwitchPlayer extends Player implements PlayerInterface {

	int initialSelection;
	Random myRandom = new Random();
	
	@Override
	public int selectDoorAgain(int openDoor) {
		initialSelection = selectedDoor;
		do{
			selectedDoor = myRandom.nextInt(3)+1;
		}
		while(selectedDoor == initialSelection || selectedDoor == openDoor);
		return selectedDoor;
	}

	@Override
	public int selectDoor() {
		selectedDoor = myRandom.nextInt(3)+1;
		return selectedDoor;
	}

}
