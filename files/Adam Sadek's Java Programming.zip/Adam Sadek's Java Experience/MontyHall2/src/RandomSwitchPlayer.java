import java.util.Random;

public class RandomSwitchPlayer extends Player implements PlayerInterface {

	int initialSelection;
	Random myRandom = new Random();
	
	@Override
	public int selectDoorAgain(int openDoor) {
		do{
			selectedDoor = myRandom.nextInt(3)+1;
		}
		while(selectedDoor == openDoor);
		return selectedDoor;
	}

	@Override
	public int selectDoor() {
		selectedDoor = myRandom.nextInt(3)+1;
		return selectedDoor;
	}

}
