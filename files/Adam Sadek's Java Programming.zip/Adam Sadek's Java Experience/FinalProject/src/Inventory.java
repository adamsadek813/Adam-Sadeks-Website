import java.text.DecimalFormat;
import java.util.Arrays;

public class Inventory {

	private double [] ingredients = new double[5];
	
	final String [] ingredientNames = new String[5];
	
	final double [] ingredientCosts = new double[5];
	
	private int shells;
	
	Inventory(){
		for(int x = 0; x < ingredients.length; x++) {
		ingredients[x] = 300;
		}
	 ingredientNames[0] = "Beef";
	 ingredientNames[1] = "Fish";
	 ingredientNames[2] = "Chilli";
	 ingredientNames[3] = "Tomato";
	 ingredientNames[4] = "Onion";
	 ingredientCosts[0] = 1.00;
	 ingredientCosts[1] = 1.00;
	 ingredientCosts[2] = 0.75;
	 ingredientCosts[3] = 0.28;
	 ingredientCosts[4] = 0.28;
	 shells = 200;

	}
	
	public boolean checkIfEnough(double [] ingredientsNeeded){
		boolean enough = false;
		if(ingredientsNeeded.length == ingredients.length) {
			if (ingredients[0] >= ingredientsNeeded[0] && ingredients[1] >= ingredientsNeeded[1] && ingredients[2] >= ingredientsNeeded[2] && ingredients[3] >= ingredientsNeeded[3] && ingredients[4] >= ingredientsNeeded[4] && shells > 0) {
				enough = true;
		}
		}
		return enough;
	}
	
	public void update(Orders newOrder){
		if(newOrder != null && newOrder.getIngredients().length == ingredients.length) {
		for (int x = 0; x < ingredients.length; x++) {
			ingredients[x] = ingredients[x] - newOrder.getIngredients()[x];
		}
		shells = shells - 1;
		}
	}
	
	public void showSummary() {
		DecimalFormat df = new DecimalFormat("0.00");
		System.out.println("Amount of Beef used: " + df.format(300 - ingredients[0]));
		System.out.println("Amount of Fish used: " + df.format(300 - ingredients[1]));
		System.out.println("Amount of Chilli used: " + df.format(300 - ingredients[2]));
		System.out.println("Amount of Tomato used: " + df.format(300 - ingredients[3]));
		System.out.println("Amount of Onion used: " + df.format(300 - ingredients[4]));

	}
	
	public double getIngredientsLeft(int ingredientNumber) {
		return ingredients[ingredientNumber];
	}
	
	
	public int getShellsLeft() {
		return shells;
	}
}
