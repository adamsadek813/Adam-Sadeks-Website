import java.math.BigDecimal;
import java.math.RoundingMode;
public class OrderList {
	
private Orders [] orders;

private int [] menuItemsSold;

private int totalOrdersPlaced;

private double totalCost;

private double totalProfit;

private double totalSales;

public OrderList(){
	orders = new Orders[200];
	menuItemsSold = new int[4];
	totalOrdersPlaced = 0;
	totalCost = 0.0d;
	totalProfit = 0.0d;
	totalSales = 0.0d;
}

public void add(Orders newOrder) {
	orders[newOrder.getOrderID()] = newOrder;
	
	for (int x = 0; x < menuItemsSold.length; x++) {
		if (x == newOrder.getMenuID()) {
			menuItemsSold[x]++;
		}
	}
	totalOrdersPlaced++;
	totalCost = totalCost + newOrder.getCost();
	totalProfit = totalProfit + (newOrder.getPrice() - newOrder.getCost());
	totalSales = totalSales + newOrder.getPrice();
}

public int getTotalOrdersPlaced(){
	return totalOrdersPlaced;
}

public double getTotalCost() {
	BigDecimal bd = new BigDecimal(totalCost).setScale(2, RoundingMode.HALF_UP);
	double totalCost2Decimals = bd.doubleValue();
	return totalCost2Decimals;
}

public double getTotalProfit() {
	BigDecimal bd = new BigDecimal(totalProfit).setScale(2, RoundingMode.HALF_UP);
	double totalProfit2Decimals = bd.doubleValue();
	return totalProfit2Decimals;
}

public double getTotalSales() {
	BigDecimal bd = new BigDecimal(totalSales).setScale(2, RoundingMode.HALF_UP);
	double totalSales2Decimals = bd.doubleValue();
	return totalSales2Decimals;
}

public int getOrdersByMenuItem(int menuItemID) {
	return menuItemsSold[menuItemID];
}

}
