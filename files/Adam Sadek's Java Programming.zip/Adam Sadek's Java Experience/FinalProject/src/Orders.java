public class Orders {

	private static int orderIDCount = 0;
	private int orderID;
	private int menuID;
	private double cost;
	private double price;
	private double [] ingredients = new double[5];
	
	public Orders(int newMenuID, double newCost, double newPrice, double [] newIngredients ){
		orderID = orderIDCount;
		menuID = newMenuID;
		cost = newCost;
		price = newPrice;
		ingredients = newIngredients;
		orderIDCount++;
	}
	public int getOrderID(){
		return orderID;
	}
	public int getMenuID(){
		return menuID;
	}
	public double getCost() {
		return cost;
	}
	public double getPrice() {
		return price;
	}
	
	public double [] getIngredients() {
		return ingredients;
	}
}
