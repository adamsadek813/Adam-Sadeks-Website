import java.util.Scanner;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Random;
public class TacoTruck {

	final String name;
	private Inventory inventory;
	final double [][] recipes = {{2.00,0.00,1.00,1.00,1.00},{0.00,2.00,1.00,1.00,1.00},{1.00,1.00,2.00,1.00,1.00},{0.00,0.00,0.00,1.00,1.00}};
	private OrderList orders;
	final private String [] menuItems = new String[4];
	
	public TacoTruck(){
		 name = "Nacho Mama's Tacos";
		inventory = new Inventory();
		orders = new OrderList();
		menuItems[0] = "Beef Taco";
		menuItems[1] = "Fish Taco";
		menuItems[2] = "Chilli Taco";
		menuItems[3] = "Veggie Taco";
	}
	
	private double [] getRecipe(int menuItemID){
			return recipes[menuItemID];
	}
	
	private String getMenuItemName(int menuItemID) {
		return menuItems[menuItemID];
	}
	
	public void run() {
		System.out.println("Welcome to " + name);
		System.out.println("==============================" + "\n" + "[1] Manual order" + "\n" + "[2] Simulated ordering" + "\n" + "[3] Sales summary" + "\n" + "[4] Quit");
		System.out.print("What would you like to do?");
		Scanner myScanner = new Scanner(System.in);
		int chosenNumber = myScanner.nextInt();
		if (chosenNumber == 1) {
			System.out.println("[1] [" + menuItems[0] + "] " + Arrays.toString(recipes[0]));
			System.out.println("[2] [" + menuItems[1] + "] " + Arrays.toString(recipes[1]));
			System.out.println("[3] [" + menuItems[2] + "] " + Arrays.toString(recipes[2]));
			System.out.println("[4] [" + menuItems[3] + "] " + Arrays.toString(recipes[3]));
			System.out.println("[5] Go back");
			System.out.print("What would you like to do/order? ");
			int menuChoice = myScanner.nextInt();
			if(menuChoice==5) {
				run();
			}
			else if(menuChoice < 5 && menuChoice > 0) {
				manual(menuChoice-1);
			}
			else {System.out.println("Invalid number inputted. Try again");
			run();
			}
		}else
		if (chosenNumber == 2) {
			simulate();
		}else
		if(chosenNumber == 3) {
			showSalesSummary();
			run();
		}else
		if(chosenNumber == 4) {
			System.exit(0);
		}
		else {System.out.println("Invalid number inputted. Try again");
		run();
		}
	}
	
	private void manual(int menuItemID) {
			order(menuItemID);
			run();
	}
	
	private void simulate() {
		Random randomPicker = new Random();
		int menuItemID = randomPicker.nextInt(4);
		while(inventory.checkIfEnough(recipes[menuItemID]) == true) {
			order(menuItemID);
			menuItemID = randomPicker.nextInt(4);
		}
		if(inventory.checkIfEnough(recipes[menuItemID]) == false) {
			System.out.println("Order cannot be fulfilled. Not enough ingredients");
			boolean twoItemsBelowOne = false;
			int numberOfBelowOne = 0;
			for (int x = 0; x < getRecipe(menuItemID).length;x++) {
				if(inventory.getIngredientsLeft(x) < 1){
					numberOfBelowOne++;
				}
			}
				if(numberOfBelowOne >=2) {
					twoItemsBelowOne = true;
				}
			if(inventory.getShellsLeft() == 0 || twoItemsBelowOne == true) {
				showSalesSummary();
				System.exit(1);
			}
			else {run();}
		}
	}
	
	private void order(int menuItemID) {
		double newCost = 0;
		double newPrice = 0;
		double [] newIngredients = new double[5];
		Random randomizer = new Random();
		if(inventory.checkIfEnough(recipes[menuItemID]) == true) {
			for (int x = 0; x < recipes[menuItemID].length; x++) {
			 newCost = newCost + (recipes[menuItemID][x] * inventory.ingredientCosts[x]);
			 if(recipes[menuItemID][x] != 0.0d) {
			 newIngredients[x] = recipes[menuItemID][x] + (Math.random() * (0.1 + 0.1) - 0.1);
			}
			}
			newPrice = newCost + (newCost*0.2);
			Orders newOrder = new Orders(menuItemID, newCost, newPrice, newIngredients);
			orders.add(newOrder);
			inventory.update(newOrder);
			System.out.println("Order # " + (orders.getTotalOrdersPlaced()-1) + " for " + getMenuItemName(menuItemID) + " successfully placed");
		}
		else {
			System.out.println("Order cannot be fulfilled. Not enough ingredients");
			boolean twoItemsBelowOne = false;
			int numberOfBelowOne = 0;
			for (int x = 0; x < getRecipe(menuItemID).length;x++) {
				if(inventory.getIngredientsLeft(x) < 1){
					numberOfBelowOne++;
				}
			}
				if(numberOfBelowOne >=2) {
					twoItemsBelowOne = true;
				}
			if(inventory.getShellsLeft() == 0 || twoItemsBelowOne == true) {
				showSalesSummary();
				System.exit(1);
			}
			else {run();}
		}
		}
	
	
	public void showSalesSummary() {
		System.out.println("Total number of tacos sold: " + orders.getTotalOrdersPlaced());
		for(int x = 0; x<menuItems.length; x++) {
		System.out.println("Total number of " + menuItems[x] + "s sold: " + orders.getOrdersByMenuItem(x));
		}
		inventory.showSummary();
		System.out.println("Total cost: $" + orders.getTotalCost());
		System.out.println("Total sales: $" + orders.getTotalSales());
		System.out.println("Total profit: $" + orders.getTotalProfit());
	//	run();
	}
}
