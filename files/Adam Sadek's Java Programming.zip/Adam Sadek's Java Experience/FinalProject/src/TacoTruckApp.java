public class TacoTruckApp {
public static void main(String[] args) {
	
	final TacoTruck myTruck = new TacoTruck();
	myTruck.run();
}
}
