public class StringManipulationDemo2 {
	public static void main(String[] args) {
		String mainString = "This is CS115";
		String s1 = "CS115";
		String s2 = "cs115";
		String s3 = "  Hello Class!  ";
		String s4 = "abc,def,ghi,123,456,789";
		
		System.out.println("Char at index 2(third position): " + mainString.charAt(2));
		System.out.println("After Concat: "+ mainString.concat("-Enjoy-"));
		System.out.println("Checking equals IGNORING CASE: " +s2.equalsIgnoreCase(s1));
		System.out.println("Checking equals with case: " +s2.equals(s1));
		System.out.println("Checking Length: "+ mainString.length());
		System.out.println("Replace function: "+ mainString.replace("fun", "easy"));
		System.out.println("SubString of mainString: "+ mainString.substring(8));
		System.out.println("SubString of mainString: "+ mainString.substring(8, 12));
		System.out.println("Converting to lower case: "+ mainString.toLowerCase());
		System.out.println("Converting to upper case: "+ mainString.toUpperCase());
		System.out.println("Trimming string: " + s3.trim());
		System.out.println("Found string s1 in mainString? " + mainString.contains(s1));
		System.out.println("Found string s2 in mainString? " + mainString.contains(s2));


	}

}