public class StudentApp {
	public static void main(String [] args){
		Student A = new Student();
		Student B = new Student("John Doe", 28);
		
		System.out.println("Student A name: " + A.getName() + " | age : " + A.getAge());
		
		System.out.println("Student B name: " + B.getName() + " | age : " + B.getAge());
		
		System.out.println();
		
		A.setName("Jane Doe");
		A.setAge(18);
		
		System.out.println("Student A " + A);  // toString()
		System.out.println("Student B " + B);  // toString()
	}
}
