public class Student {

	String name;
	int age;
	
public Student() {
	name = "Unknown";
	age = 0;
}

public Student(String newName,int newAge) {
	name = newName;
	age = newAge;
	correctAge();
}

public String getName() {
	return name;
}

public int getAge() {
	return age;
}

public void setAge(int newAge) {
	age = newAge;
	correctAge();
}

public void setName(String newName) {
	name = newName;
}

private void correctAge() {
	if (age < 0) {
		age = 0;
	}
}

public String toString() {
String isBlankAge = name + " Is " + age + " years old";
return isBlankAge;
}
}
