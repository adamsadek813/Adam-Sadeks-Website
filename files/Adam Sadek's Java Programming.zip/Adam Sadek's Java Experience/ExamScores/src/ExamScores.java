import java.util.Scanner;
import java.util.InputMismatchException;
import java.lang.NegativeArraySizeException;
public class ExamScores {
	public static void main(String[] args) {
		boolean properInput = false;
		while (properInput == false) {
		System.out.println("How many exam scores do you have to enter?");
		Scanner myScanner = new Scanner(System.in);
		try {
		int questionAmount = myScanner.nextInt();
		double [] score = new double[questionAmount];
		double scoreSum = 0;
		double possibleScore;
		for (int x = 0; x < questionAmount; x++) {
			do {
			System.out.println("Enter score #" + (x+1));
			possibleScore = myScanner.nextDouble();
			} while(possibleScore < 0);
			score[x] = possibleScore;
			scoreSum = scoreSum + score[x];
		}
		double averageScore = scoreSum / questionAmount;
		int scoresLarger = 0;
		System.out.println("The average score is " + averageScore);
		for (int y = 0; y < score.length; y++) {
			if (score[y] > averageScore) {
				scoresLarger++;
				properInput = true;
			}
		}
		System.out.println("There are/is " + scoresLarger + " score(s) larger than the average");
		}
		catch (InputMismatchException IME) {
			System.out.println("Invalid input! Please try again!");
			properInput = false;
		}
		catch (NegativeArraySizeException NASE) {
			System.out.println("Invalid input! Please try again!");
			properInput = false;
		}
		}
	}
}
