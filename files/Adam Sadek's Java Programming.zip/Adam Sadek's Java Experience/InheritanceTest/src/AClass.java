
public class AClass {
	private int x; 
	   protected int y; 

	   AClass(int a, int b) {
	      x = a; y = b; 
	   }

	   public int addEm( ){ 
	      return x + y; 
	   }

	   public String toString( ) {
	      return "" + x + " " + y;
	   }

}
