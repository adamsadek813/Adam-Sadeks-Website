
public class Tester {
public static void main(String [] args) {
	BClass obj1 = new BClass(2,3,4);
	System.out.println(obj1.toString());
}
}
