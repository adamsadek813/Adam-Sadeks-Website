public class BoxVolumeCalculator {
double length, width, height, volume;

BoxVolumeCalculator() {
	length = 0;
	width = 0;
	height = 0;
	volume = 0;
}
public void setLength(double newLength) {
	length = newLength;
}
public void setWidth(double newWidth) {
	width = newWidth;
}	
public void setHeight(double newHeight) {
	height = newHeight;
}
public double getLength() {
	return length;
}
public double getWidth() {
	return width;
}
public double getHeight() {
	return height;
}
public double getVolume() {
	return volume;
}
public void calculateVolume() {
	if (length >= 0 && width >= 0 && height >= 0) {
	volume = length * width * height;
	}
	else {volume = 0;}
	
}
}
