public class Craps {
	public static void main(String[] args) {

		Die dice1 = new Die();
		Die dice2 = new Die();
		
		
			dice1.roll();
			dice2.roll();
			int targetRoll = dice1.getSide() + dice2.getSide();
			System.out.println("Target Roll: " + dice1.getSide() + " + " + dice2.getSide() + " = " + targetRoll);
			if (targetRoll == 7) {
				System.out.println("You won on the first roll!");
			}
		
		int numberGenerated = 0;
		while(numberGenerated != targetRoll && targetRoll != 7 && numberGenerated != 7) {
		 dice1.roll();
		 dice2.roll();
		 numberGenerated = dice1.getSide() + dice2.getSide();
		 System.out.println("You rolled: " + dice1.getSide() + " + " + dice2.getSide() + " = " + numberGenerated);
		 if (numberGenerated == 7) {
			 System.out.println("CRAPS! You lost."); 
		 }
		if (numberGenerated == targetRoll) {
			System.out.println("You rolled your target. You won!");
		}
		}

	
	}
}

