import java.util.Scanner;
import java.text.DecimalFormat;
public class LocationAndVelocity {
	public static void main( String args[]) {
		
double t;
Scanner myScanner = new Scanner(System.in);
System.out.println("Enter the values for a, b, c, d: ");
double [] anArray = new double[4];
double greatestVelocity = 0;
for(int i = 0; i <4; i++) {
	anArray[i] = myScanner.nextDouble();
}

System.out.println("Particle object created.");
System.out.println("location(t) = " + anArray[0]+"t^4"+"+"+anArray[1]+"t^3"+"+"+anArray[2]+"t^2"+"+"+anArray[3]+"t");
System.out.println("Enter the start time");
double startTime = myScanner.nextDouble();
System.out.println("Enter the end time");
double endTime = myScanner.nextDouble();
System.out.println("Enter the increment");
double increment = myScanner.nextDouble();
System.out.println("Time  Loc  Vel");
DecimalFormat df = new DecimalFormat("0.000");
double originalVelocity = (4*anArray[0]*Math.pow(startTime, 3)) + (3*anArray[1]*Math.pow(startTime, 2)) + (2*anArray[2]*startTime);
greatestVelocity = originalVelocity;
for(double x = startTime; x <= endTime; x=x+increment) {
	double location = (anArray[0]*Math.pow(x, 4))+(anArray[1]*Math.pow(x, 3))+(anArray[2]*Math.pow(x, 2))+(anArray[3]*x);
	double velocity = (4*anArray[0]*Math.pow(x, 3)) + (3*anArray[1]*Math.pow(x, 2)) + (2*anArray[2]*x);
	System.out.println(x + "  " + df.format(location) + "  " + df.format(velocity) );
	if((velocity - originalVelocity) > 1 ||  (velocity - originalVelocity) < -1) {
		System.out.println("More than 1 unit movement");
	}
	if(velocity > originalVelocity) {
		 greatestVelocity = velocity;
	}
	originalVelocity = velocity;
}
System.out.println("Max velocity in all tables = " + df.format(greatestVelocity));
}
}