import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class StudentAnswerSheetApp {
	public static void main (String args[]) {
		
		String fileName;
		File inputFile;
		char [] answerKey = null;
		String answerKeyString;
		String [] studentInfo;
		char [] studentAnswerSheet = null;
		String studentName = "";
		String bestScores = "";
		double initialChecker = 0.0;
		
		try {
			fileName = "answers.txt";
			inputFile = new File(fileName);
			Scanner fileScanner = new Scanner(inputFile);
			answerKeyString = fileScanner.nextLine();
			answerKey = new char[(answerKeyString.length()-3)/2];
			for(int x = 0; x < answerKey.length; x++) {
				answerKey[x] = answerKeyString.charAt(4 + (2*x));
			}
			studentAnswerSheet = new char[answerKey.length];
			StudentAnswerSheet.setKey(answerKey);
			
			while(fileScanner.hasNextLine()) {
			studentInfo = fileScanner.nextLine().split(",");
			studentName = studentInfo[0];
			for(int x = 0; x < studentInfo.length-1; x++) {	
				studentAnswerSheet[x] = studentInfo[x+1].charAt(0);
				}
			StudentAnswerSheet obj = new StudentAnswerSheet(studentName, studentAnswerSheet);
			obj.getName();
			obj.getScore();
			System.out.println(obj.toString());
			
			if(obj.getScore() > initialChecker) {
				initialChecker = obj.getScore();
				bestScores = studentName;
			}
			else {
			if(obj.getScore()==initialChecker) {
				initialChecker = obj.getScore();
				bestScores = bestScores + ", " + studentName;

			}
			}
			}
			System.out.println("Best student(s): " + bestScores);

		
		}
		catch (FileNotFoundException fnfe) {
			System.out.println("Message: " + fnfe.getMessage());
			System.out.println("\ntoString( ): " + fnfe + "\n" );
			fnfe.printStackTrace();
			}
	}
}
		

	

	
	
