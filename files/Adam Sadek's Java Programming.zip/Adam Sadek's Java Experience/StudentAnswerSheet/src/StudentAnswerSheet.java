import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class StudentAnswerSheet {

	String studentName;
	char [] studentAnswerSheet;
	static char [] answerKey;
	double score;
	

	StudentAnswerSheet(String newStudentName, char [] newStudentAnswerSheet){
		studentName = newStudentName;
	//	if (newStudentAnswerSheet.length == answerKey.length) {
			studentAnswerSheet = newStudentAnswerSheet;
	//	}
	//	else {
	//		System.out.println("Error! Answer sheet length does not match length of test questions.");
	//	}
	}
	
	public String getName(){
		return studentName;
	}
	
	public static void setKey(char [] newAnswerKey) {
		answerKey = newAnswerKey;
	}
	
	public double getScore() {
		 score = 0;
		 if(studentAnswerSheet.length != answerKey.length) {
			 return Double.NEGATIVE_INFINITY;
		 }
	for(int x = 0; x < studentAnswerSheet.length; x++) {
		if(studentAnswerSheet[x] == answerKey[x]) {
			score = score + 1.0;
		}
		if(studentAnswerSheet[x] == '?') {
			score = score;
		}
		if(studentAnswerSheet[x] != '?' && studentAnswerSheet[x] != answerKey[x]) {
			score = score - 0.25;
		}
		}
		return score;
	}
	
	public String toString() {
		return  studentName + " " + Arrays.toString(studentAnswerSheet) + " score=" + score;
	}
	
}
