
public abstract class CircleSolid {
protected double radius;

public CircleSolid() {
	radius = 28.0;
}

public CircleSolid(double newRadius) {
	setRadius(newRadius);
}

public double getRadius() {
	return radius;
}

public void setRadius(double newradius) {
	radius = newradius;
}

public double getCircumference() {
	return 2.0*Math.PI*radius;
}

public double getArea() {
	return Math.PI*Math.pow(radius, 2);
}

@Override
public String toString() {
	return   "CircleSolid: radius=" + radius;
}

public abstract double getVolume();

}
