
public class Cylinder extends CircleSolid {

	private double height;
	public Cylinder() {
		super();

	}
	
	public Cylinder(double newRadius, double newHeight) {
		super(newRadius);
		setHeight(newHeight);
	}
	
	
	
	public double getHeight() {
		return height;
	}

	public void setHeight(double newHeight) {
		height = newHeight;
	}

	@Override
	public double getVolume() {
		return Math.PI*Math.pow(radius, 2)*height;
	}

	@Override
	public String toString() {
		return super.toString() + "\n" + "Cylinder: Height=" + getHeight() + " Volume="
				+ getVolume();
	}

	
}

