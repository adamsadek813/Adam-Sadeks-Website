
public class Sphere extends CircleSolid{

	public Sphere() {
		super();
	}
	
	public Sphere(double newRadius) {
		super(newRadius);
	}
	
	public double getVolume() {
		return (4.0/3.0)*Math.PI*Math.pow(radius, 3);
	}

	@Override
	public String toString() {
		return super.toString() +"\n" + "Sphere: Volume="
				+ getVolume();
	}
	
	
}
