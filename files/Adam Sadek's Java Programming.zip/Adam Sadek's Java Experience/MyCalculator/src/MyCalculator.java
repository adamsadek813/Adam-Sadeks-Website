

import java.util.Scanner;

public class MyCalculator {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// Creating a scanner to read from the user
		Scanner scanner = new Scanner(System.in);

		while (true) {
			// Prints header
			System.out.println("Format: A operator B, where A and B are positive SINGLE DIGIT integers");
			System.out.println("Allowed operators: + - * / ^");
			System.out.println("Sample expressions: 6+3, 1-9, 0*8, 3/3, 7^4");
			System.out.println("***********************************************");

			// Asks for input
			System.out.print("Enter your arithmetic expression: ");

			// Reads input
			String expression = scanner.nextLine();
			System.out.println("User expression: " + expression);

			// Formats it
			String formattedExpression = expression.replace(" ", "");
			System.out.println("User expression after removing spaces: " + formattedExpression);

			// Evaluates and prints the result
			double result = evaluateExpression(formattedExpression);
			if (Double.isNaN(result))
				System.out.println("ERROR: Impossible to evaluate this expression.");
			else
				System.out.println(formattedExpression + "=" + result);
		}
	}

	private static double evaluateExpression(String expr) {
		// Checks for basic possible errors
		if (expr == null || expr.length() != 3) {
			System.out.println("ERROR: This expression is either too long or too short.");
			return Double.NaN;
		}

		// Checks if the operands are really numbers (told to ignore but we decided to
		// put here)
		if (!Character.isDigit(expr.charAt(0)) || !Character.isDigit(expr.charAt(2)))
			return Double.NaN;

		// Gets operands A and B
		int A = expr.charAt(0) - '0';
		int B = expr.charAt(2) - '0';

		// Evaluates the expression
		switch (expr.charAt(1)) {
		case '+':
			return A + B;
		case '-':
			return A - B;
		case '/':
			return A * 1f / B;
		case '*':
			return A * B;
		case '^':
			return Math.pow(A, B);
		default:
			System.out.println("ERROR: Unknown operator.");
			return Double.NaN;
		}
	}

}
