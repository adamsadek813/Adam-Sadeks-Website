import java.util.Scanner;
public class DateClient
{
  public static void main( String [] args )
  {
     // add code to construct Data objects
	  Date Date1 = new Date();
	  Date Date2 = new Date();
	  Date Date3 = new Date();
	  Date Date4 = new Date();
	  Date Date5 = new Date();
	  Date Date6 = new Date();
	  Date Date7 = new Date();
	  Date Date8 = new Date();
	  Date Date9 = new Date();
	  Date Date10 = new Date();
	  Date Date11 = new Date();

	 // and test and output if they are a
	 // leap year or not
	 
	 // not leap year (not divisible by 4)
	  Date1.setDate(8, 1, 2003);
	  System.out.print("The date " + Date1.getMonth() + "/" + Date1.getDay() + "/" + Date1.getYear());
	  if(Date1.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }

	 // leap year (divisible by 4, but not by 100)
	  Date2.setDate(6, 19, 2004);
	  System.out.print("The date " + Date2.getMonth() + "/" + Date2.getDay() + "/" + Date2.getYear());
	  if(Date2.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }


	 // not leap year (divisible by 4 and by 100)
	  Date3.setDate(9, 22, 200);
	  System.out.print("The date " + Date3.getMonth() + "/" + Date3.getDay() + "/" + Date3.getYear());
	  if(Date3.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }


	 // leap year (divisible by 4 and by 100 and by 400)
	  Date4.setDate(3, 7, 2000);
	  System.out.print("The date " + Date4.getMonth() + "/" + Date4.getDay() + "/" + Date4.getYear());
	  if(Date4.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }


	 // your birth year
	  Date5.setDate(8, 13, 2002);
	  System.out.print("The date " + Date5.getMonth() + "/" + Date5.getDay() + "/" + Date5.getYear());
	  if(Date5.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  
	  Date6.setDate(2, 29, -100);
	  System.out.print("The date " + Date6.getMonth() + "/" + Date6.getDay() + "/" + Date6.getYear());
	  if(Date6.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  
	  Date7.setDate(2, 29, 2006);
	  System.out.print("The date " + Date7.getMonth() + "/" + Date7.getDay() + "/" + Date7.getYear());
	  if(Date7.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  
	  Date8.setDate(2, 29, 2000);
	  System.out.print("The date " + Date8.getMonth() + "/" + Date8.getDay() + "/" + Date8.getYear());
	  if(Date8.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  
	  Date9.setDate(2, 29, 2004);
	  System.out.print("The date " + Date9.getMonth() + "/" + Date9.getDay() + "/" + Date9.getYear());
	  if(Date9.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  
	  Date10.setDate(2, 29, 1900);
	  System.out.print("The date " + Date10.getMonth() + "/" + Date10.getDay() + "/" + Date10.getYear());
	  if(Date10.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  
	  Date11.setDate(2, 29, 1600);
	  System.out.print("The date " + Date11.getMonth() + "/" + Date11.getDay() + "/" + Date11.getYear());
	  if(Date11.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  

	  while(true) {
		  Date newDate = new Date();
	  System.out.println("What is your birthday? Enter in form mm/dd/yyyy");
	  Scanner myScanner = new Scanner(System.in);
	  String userInput = myScanner.next();
	  String[] arrOfStr = userInput.split("/", -1);
	  String mm = arrOfStr[0];
	  String dd = arrOfStr[1];
	  String yyyy = arrOfStr[2];
	  int month = Integer.parseInt(mm);
	  int day = Integer.parseInt(dd);
	  int year = Integer.parseInt(yyyy);
	  newDate.setDate(month, day, year);
	  System.out.print("The date " + newDate.getMonth() + "/" + newDate.getDay() + "/" + newDate.getYear());
	  if(newDate.leapYear()==true) {
		  System.out.println(" is a leap year");
	  }
	  else {
		  System.out.println(" is not a leap year");
	  }
	  
	  }
  }
}
