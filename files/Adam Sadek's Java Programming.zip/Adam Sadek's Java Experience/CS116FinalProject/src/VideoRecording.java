public class VideoRecording extends Recording {

	private double framerate;

	public VideoRecording(String artist, String name, int duration, double framerate) {
		super(artist, name, duration);
		if (Double.isNaN(framerate) || Double.isInfinite(framerate) || framerate <= 0)
			throw new UnplayableException("Framerate is invalid: " + framerate);
		this.framerate = framerate;
	}

	@Override
	public String toString() {
		return super.toString() + " [VIDEO | framerate: " + framerate + " fps]";
	}

	public double getFramerate() {
		return framerate;
	}
}