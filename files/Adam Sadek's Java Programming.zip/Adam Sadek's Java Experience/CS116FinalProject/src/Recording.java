public abstract class Recording implements Playable {
	protected String artist, name;
	protected int duration;
	private int played;
	
	public Recording() {
		this(null, null, 0);
	}

	public Recording(String artist, String name, int duration) {
		this.artist = artist == null ? "Unknown" : artist;
		this.name = name == null ? "Unknown" : name;
		if (duration <= 0)
			throw new UnplayableException("Duration " + duration + " invalid!");
		this.duration = duration;
	}
	
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Recording))
			return false;
		Recording r = (Recording) o;
		return r.getArtist().equals(artist) && r.getName().equals(name);
	}

	public void play() {
		System.out.println("Now playing: " + this);
		played++;
	}

	@Override
	public String toString() {
		return artist + " - " + name + " " + Util.formatDuration(duration);
	}

	public String getArtist() {
		return artist;
	}

	public String getName() {
		return name;
	}

	public int getDuration() {
		return duration;
	}

	public int getPlayed() {
		return played;
	}

	public void setPlayed(int played) {
		this.played = played;
	}

}