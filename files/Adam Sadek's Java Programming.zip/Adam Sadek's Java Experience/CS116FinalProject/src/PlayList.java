
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringJoiner;

//Playlist actually doesn't require a name
public class PlayList implements Playable {
	private String name;
	private int duration, size;
	private int id;

	private ArrayList<Recording> recordings;

	private static int IDCount;

	public PlayList(String name) {
		this.recordings = new ArrayList<>();
		id = IDCount++;
		this.name = name;
	}

	public PlayList() {
		this(null);
	}

	public void add(Recording recording) {
		// This will trigger if the recording is either the same or has the same name
		// and artist, to avoid duplicates insertion (See Recording class)
		if (recordings.contains(recording))
			return;
		recordings.add(recording);
		duration += recording.duration;
		size++;
	}

	public void remove(int index) {
		if (index >= 0 && index < recordings.size())
			remove(recordings.get(index));
	}

	public void remove(Recording recording) {
		recordings.remove(recording);
		duration -= recording.getDuration();
		size--;
	}

	public void remove(String name) {
		for (int i = 0; i < recordings.size(); i++)
			if (recordings.get(i).getName().equals(name)) {
				remove(recordings.get(i));
				return;
			}
	}

	public Recording get(int index) {
		if (index >= 0 && index < recordings.size())
			return recordings.get(index);
		return null;
	}

	public Recording get(String name) {
		for (int i = 0; i < recordings.size(); i++)
			if (recordings.get(i).getName().equals(name))
				return recordings.get(i);
		return null;
	}

	public void play() {
		if (size == 0)
			throw new UnplayableException("Invalid size of playlist: 0");
		recordings.forEach((r) -> r.play());
	}

	public void shuffle() {
		Collections.shuffle(recordings);
	}

	// Loads using the name itself (we can discuss about this to even insert the csv
	// extension automatically when loading, so that we keep the name clean)
	public void load() {
		load(this);
	}

	// Loads a playlist from a file and gives the name of this playlist the name of
	// the file
	public static PlayList load(String name) {
		return load(new PlayList(name));
	}

	private static PlayList load(PlayList playlist) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(playlist.name)));
			String buff = "";
			while ((buff = br.readLine()) != null) {
				String[] s = buff.split(",");

				// Checks basic structure of a line
				if (s.length < 5) {
					System.out.println("ERROR: invalid recording format (" + buff + ")");
					continue;
				}

				Recording r = null;
				int duration = 0;
				double bfrate = 0;

				// Tries to parse numerical data
				try {
					duration = Integer.parseInt(s[3].trim());
					bfrate = Double.parseDouble(s[4].trim());
				} catch (NumberFormatException ne) {
					continue;
				}

				// Creates an appropriate recording depending on the type
				try {
					if (s[0].trim().equals("A"))
						r = new AudioRecording(s[2].trim(), s[1].trim(), duration, bfrate);
					else if (s[0].trim().equals("V"))
						r = new VideoRecording(s[2].trim(), s[1].trim(), duration, bfrate);
				} catch (UnplayableException e) {
					e.printStackTrace();
				} finally {
					if (r != null)
						playlist.add(r);
				}
			}
			br.close();
		} catch (IOException e) {
			System.out.println("ERROR: File <" + playlist.name + "> not found!");
		}
		return playlist;
	}

	public void save() {
		save(this.name);
	}

	public void save(String name) {
		if (size == 0)// Treats blank playlist
			return;
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(new File(name)));
			// We should actually add an abstract method toCSVString to Recording, so that
			// the developer could easily add more types of recordings without having to go
			// to many classes and change it
			recordings.forEach(r -> {
				// There are only audioRecording and videorecording in our project. No need to
				// check for video too

				// We can also encapsulate each insertion in the "database" with a try-catch.
				// even though we would require a more refined approach if something threw an
				// exception, as half insertion would be worse than no insertion. We should also
				// discuss this
				try {
					bw.append(r instanceof AudioRecording ? "A" : "V").append(",");
					bw.append(r.getName()).append(",");
					bw.append(r.getArtist()).append(",");
					bw.append(r.getDuration() + "").append(",");
					bw.append((r instanceof AudioRecording ? ((AudioRecording) r).getBitrate()
							: ((VideoRecording) r).getFramerate()) + "");
					bw.newLine();
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			bw.flush();
			bw.close();
		} catch (IOException e) {
			System.out.println("ERROR: Not possible to save " + name);
		}
	}

	// Merges two playlists together
	public PlayList merge(PlayList playlist2) {
		if (playlist2.equals(this) || size == 0 || playlist2.size == 0)
			return null;
		PlayList playlist1 = clone();
		// This name thing should be discussed
		playlist1.name += " " + playlist2.name;
		playlist2.recordings.forEach(r -> playlist1.add(r));
		return playlist1;
	}

	// Clones a playlist
	@Override
	public PlayList clone() {
		PlayList playlist = new PlayList(this.name);
		// Recordings not cloned here because they are not modifiable
		recordings.forEach(r -> playlist.add(r));
		return playlist;
	}

	@Override
	public String toString() {
		StringJoiner sj = new StringJoiner("Playlist: " + name + " " + Util.formatDuration(duration), "\n", "\n");
		recordings.forEach((r) -> sj.add(r.toString()));
		return sj.toString();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name != null)
			this.name = name;
	}

	public int getSize() {
		return recordings.size();
	}

	public int getId() {
		return id;
	}

	@Override
	public int getDuration() {
		return duration;
	}

}