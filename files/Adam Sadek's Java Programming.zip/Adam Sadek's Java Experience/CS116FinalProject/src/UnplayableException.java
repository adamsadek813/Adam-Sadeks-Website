public class UnplayableException extends IllegalArgumentException {
	private static final long serialVersionUID = 8858649246551701889L;

	public UnplayableException(String s, Throwable t) {
		super(s, t);
	}

	public UnplayableException(String s) {
		super(s);
	}
}