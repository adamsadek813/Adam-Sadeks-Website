import java.io.File;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

final public class Util {
	public static String formatDuration(int d) {
		return "[" + (d / 60) + "m" + (d % 60) + "s]";
	}

	public static boolean isInt(String str) {
		return str.matches("-?\\d+");
	}

	public static String closestString(List<String> strings, String c) {
		int min = 999999, index = -1;
		for (String a : strings) {
			int l = levenshtein(a, c);
			if (l < min) {
				min = l;
				index = strings.indexOf(a);
			}
		}
		return index == -1 ? null : strings.get(index);
	}

	// Levenshtein implementation
	public static int levenshtein(String a, String b) {
		String str = a.toLowerCase();
		String s = b.toLowerCase();
		int[][] dis = new int[str.length() + 1][s.length() + 1];
		for (int i = 0; i <= str.length(); i++)
			for (int j = 0; j <= s.length(); j++)
				dis[i][j] = i == 0 ? j
						: (j == 0 ? i
								: (min(dis[i - 1][j - 1] + (str.charAt(i - 1) == s.charAt(j - 1) ? 0 : 1),
										dis[i - 1][j] + 1, dis[i][j - 1] + 1)));
		return dis[str.length()][s.length()];
	}

	public static ArrayList<String> closestStrings(List<String> strings, String c, int tol) {
		ArrayList<String> results = new ArrayList<String>();
		for (String a : strings) {
			int l = levenshtein(c, a);
			if (l <= tol)
				results.add(a);
		}
		return results;
	}

	public static int min(int... numbers) {
		int min = Integer.MAX_VALUE;
		for (int i : numbers)
			min = i < min ? i : min;
		return min;
	}

	public static String getRootPath() {
		try {
			return new File(Util.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getPath();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static ArrayList<String> retrieveFilesWithExtension(String ext) {
		File root = new File(getRootPath());
		return retrieveAll(root.getParentFile().getParentFile(), ext);
	}

	private static ArrayList<String> retrieveAll(File f, String ext) {
		ArrayList<String> files = new ArrayList<String>();
		if (f.isDirectory())
			for (File child : f.listFiles())
				files.addAll(retrieveAll(child, ext));
		else if (f.getName().contains(ext))
			files.add(f.getAbsolutePath());
		return files;
	}
}