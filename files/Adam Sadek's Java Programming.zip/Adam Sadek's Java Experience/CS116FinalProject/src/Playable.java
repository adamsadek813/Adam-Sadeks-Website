public interface Playable {
	public void play();

	public int getDuration();
}