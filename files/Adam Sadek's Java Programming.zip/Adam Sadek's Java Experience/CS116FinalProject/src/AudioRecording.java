public class AudioRecording extends Recording {
	private double bitrate;

	public AudioRecording() {
		super();
		bitrate = 0;
	}

	public AudioRecording(String artist, String name, int duration, double bitrate) {
		super(artist, name, duration);
		if (Double.isNaN(bitrate) || Double.isInfinite(bitrate) || bitrate <= 0)
			throw new UnplayableException("Bitrate is invalid: " + bitrate);
		this.bitrate = bitrate;
	}

	public double getBitrate() {
		return bitrate;
	}

	@Override
	public String toString() {
		return super.toString() + " [AUDIO | bitrate: " + bitrate + " kbps]";
	}

}