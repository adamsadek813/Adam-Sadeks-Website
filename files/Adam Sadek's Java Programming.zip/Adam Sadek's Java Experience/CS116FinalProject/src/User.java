public class User implements Playable {
	private String name;
	private int id;
	private PlayList playlist;

	private static int IDCount;

	public User() {
		this.setPlaylist(new PlayList());
		id = IDCount++;
	}

	public User(String name) {
		this();
		this.name = name.toLowerCase();
	}

	public void shuffle() {
		if (playlist != null)
			playlist.shuffle();
	}

	@Override
	public String toString() {
		return name + " ID " + id;
	}

	@Override
	public void play() {
		if (playlist != null)
			playlist.play();
	}

	@Override
	public int getDuration() {
		if (playlist != null)
			return playlist.getDuration();
		return 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public PlayList getPlaylist() {
		return playlist;
	}

	public void setPlaylist(PlayList playlist) {
		this.playlist = playlist;
	}
	
	public void addToPlaylist(Recording recording) {
		playlist.add(recording);
	}

}