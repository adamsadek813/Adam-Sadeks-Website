import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         Text to be deleted later:
 * 
 *         Some explanation on the thought that we can still discuss: I added an
 *         utility class so that we can put widely used methods there, to avoid
 *         not needed repetition.
 * 
 *         I thought of doing a more intelligent system that minimizes the
 *         amount of work done by the user and avoids ambiguity or not wanted
 *         behavior, while still catching errors and suggesting smart options.
 *         This is the case of importing a playlist: it searches for matching
 *         files in the directory, either with the informed csv extension or
 *         not. If an user with that name (unlikely) is also found, it asks who
 *         are you referring to, to proceed. If only a user is found and not
 *         files in the directory, it promptly proceeds with the operation.
 *         Also, if the user already has recordings in its playlist, it may not
 *         want to override all of them. We give the option to merge or override
 *         everything. If nothing is really found, a deeper search in the users
 *         with similar name or files in nearby directories that have csv
 *         extension is done and suggestions are made to the user. Most of the
 *         paths followed are going to be: import something -> want to merge? ->
 *         proceeds with command, if the user inputs everything correctly. If it
 *         is a new user, it is literally one single command. We can even think
 *         of making a command that shows all files in the directory that the
 *         user can import from, so that he doesn't need to type it exactly from
 *         memory or copy and paste from somewhere else.
 * 
 *         The commands or even some cases where we want to search for a
 *         recording or an user inside the database to play, we don't have to
 *         input the exact command or value. There is an implementation inside
 *         Util of the Levenshtein distance, that returns the closest match to a
 *         given string and multiple others to be matched. For example, if the
 *         user inputs "user Sadk", it wouldn't be able to find it in the
 *         database normally. Like Google (that has a much more advanced
 *         implementation), we can still get a closer match to that command or
 *         value in the database. Probably, we would require to set a maximum
 *         distance, or maximum distortion that a word can have to match.
 *         because if we input anything random, currently, one command will
 *         always be matched, that has the closest meaning to the input.
 *         Lowering the acceptable distance would avoid this problem. This is a
 *         matter of testing and configuration.
 * 
 *         Lastly, I thought of doing an implementation of flexible menus that
 *         self configure, with given commands. An interface Commandable with
 *         the method execute(StreamingSystem system, Scanner s, String
 *         parameter) that can be implemented by a class, so that we can
 *         organize better, like you suggested before. We can have an abstract
 *         class called MenuRoutine that implements it and can be extended from
 *         another class, that provides to the parent a list of commands to
 *         build a menu interface automatically. Most of the repetitive menu
 *         work would be done inside the parent class (like looping and
 *         listening to return commands). Once a command is called, this
 *         abstract class could call an execute abstract method that has inside
 *         the child class and then proceed with the the operation. Commands
 *         could even have options like a boolean "has operation" or "must be
 *         exact" so that it avoids levenshtein search, a description and the
 *         command itself.
 * 
 *         I don't think there will be too much work now that this skeleton is
 *         mostly made. We surely will have to test a lot. Tell me what you
 *         think of this approach, and if this is way too overcomplicated. I
 *         wanted to do a great project, but still don't want to take too much
 *         of your time
 * 
 *         LIST OF THINGS TO DO
 * 
 *         TODO possibly add a debug option to insert many users with random
 *         playlists or even generate valid and invalid files with recordings
 *         inside. So that we can test it easily with many examples
 * 
 *         TODO organize menus in a flexible way exploiting object oriented
 *         practices
 * 
 *         TODO add option to remove user from the user menu (then it would need
 *         to go back to the main menu). We must also add the verification
 *         option "Are you sure?" to the removing user operation
 * 
 *         TODO add option to remove recording from playlist
 * 
 *         TODO treat the loading playlist routine (I don't think it treats
 *         invalid formats currently, properly)
 * 
 *         TODO add single recording to playlist
 * 
 *         TODO play entire playlist
 * 
 *         TODO polish the playlist importing routine (maybe limit the amount of
 *         suggestions and only suggest .csvs that have the needed format. There
 *         is no depth limit in the search of csv files in the Util routine. If
 *         the user has a million nested folders in the directory, that will be
 *         a problem, that we have to fix)
 * 
 *         TODO shuffle entire playlist (the option exists but I think we must
 *         play right after shuffling. I also imagine that we should not shuffle
 *         the original one. Maybe we can clone it and then shuffle it and play
 *         the clone, inside the shuffle method in the playlist class)
 * 
 *         TODO save playlist (function not tested yet. Only exists. Probably
 *         will require modifications). I noticed that it needs another name in
 *         the saving format. It is described as
 *         USERNAME_PLAYLIST_MM_DD_YYYY_HH_MM_SS.csv with the date being the
 *         saving moment
 * 
 *         TODO display playlist stats
 * 
 *         TODO I don't think the unplayable exception was fully catched
 *         everywhere. We have to check that and even think how to catch and
 *         proceed with the user interaction
 * 
 *         TODO polish the user addition with more name filters (can't be
 *         completely numerical, probably shouldn't have spaces, shouldn't
 *         contain not allowed characters)
 * 
 *         TODO check for command ambiguity in all other scenarios, that could
 *         exist, such as playing a recording by index or name. If the name is
 *         only numerical (could be possible), we must ask the user which one is
 *         he referring to.
 * 
 *         TODO organize overall code and polish it so that there is minimal not
 *         needed repetition
 * 
 *         TODO test it a lot to avoid errors. Some places there are only
 *         try-catches with default throwing. We must treat them too
 * 
 *         TODO polish the "user interface"
 * 
 */
public class StreamingSystem {

	private ArrayList<User> users;
	
	public StreamingSystem() {
		users = new ArrayList<>();

		// for debug only
		User gabriel = new User("Gabriel");
		gabriel.setPlaylist(PlayList.load("BillboardHot100.csv"));
		users.add(gabriel);
		users.add(new User("Roskowski"));
		users.add(new User("Gabrel"));
		users.add(new User("Gebreal"));
		users.add(new User("Adam"));
		users.add(new User("Sadek"));
	}

	public void run() {
		Scanner s = new Scanner(System.in);
		ArrayList<String> commandList = getCommandList();
		exit: while (true) {
			try {
				printMenu();

				String input = s.nextLine();

				String sp[] = input.split(" ");
				// Users don't have to input the exact command now. anything close will do
				String command = Util.closestString(commandList, sp[0].trim());
				String value = sp.length > 1 ? sp[1].trim() : null;
				// With the value, the user can input something like "user Gabriel" (name) or
				// "user 8" (index)
				switch (command) {
				case "user":
					if (value != null)
						runUserMenu(searchUser(value, true), s);
					else
						System.out.println("Invalid user command. Please include a value");
					break;
				case "add":
					addUserRoutine(s);
					break;
				case "remove":
					if (value != null) {
						User u = Util.isInt(value) ? searchUser(Integer.parseInt(value.toLowerCase())) : searchUser(value.toLowerCase(), false);
						if (u == null) {
							System.out.println("User not found!");
							break;
						}
						System.out.println("Are you sure you want to remove this user?");
						input = Util.closestString(commandList, s.nextLine());
						if (input.equals("return") || input.equals("no"))
							break;
						else if (input.equals("yes")) {
						users.remove(u);
						}
						System.out.println("User " + u.getName() + " removed from database.");
					} else
						System.out.println("Invalid remove command. Please include a value");
					break;
				case "list":
					users.forEach(System.out::println);
					break;
				case "exit":
					break exit;
				default:
					System.out.println("Command not found. Try again");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		s.close();
	}

	private void addUserRoutine(Scanner s) {
		ArrayList<String> commandList = getCommandList();
		while (true) {
			try {
				System.out.println("Provide name");
				String input = s.nextLine();
				if (input.equals("return"))
					break;
				// Later we have to implement a general function in Util maybe. Here are only
				// the main ones that could be used normally for files
				if (Util.isInt(input) || input.contains(".") || input.contains("/") || input.contains("\\")) {
					System.out.println("User name can't be only numerical or contain slashes");
					continue;
				}
				User user = new User();
				user.setName(input);
				users.add(user);
				System.out.println("Do you want to continue editing this user?");
				input = Util.closestString(commandList, s.nextLine());
				if (input.equals("return") || input.equals("no"))
					break;
				else if (input.equals("yes")) {
					runUserMenu(user, s);
					break;
				} else {
					System.out.println("Command not recognized. Going back to menu.");
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void runUserMenu(User user, Scanner s) {
		if (user == null) {
			System.out.println("User not found!");
			return;
		}
		ArrayList<String> commandList = getCommandList();
		PlayList playlist = user.getPlaylist();
		FileOutputStream fos = null;
		PrintWriter pw = null;
		back: while (true) {
			try {
				printUserMenu(user);

				String input = s.nextLine();

				String sp[] = input.split(" ");
				String command = Util.closestString(commandList, sp[0].trim());
				String value = sp.length > 1 ? sp[1].trim() : null;

				switch (command) {
				case "add":
					System.out.println("Is the recording an audio or video?");
					String audioOrVideo = s.nextLine();
					if(audioOrVideo.charAt(0) == 'a' || audioOrVideo.charAt(0) == 'A') {
					System.out.println("Please provide all information of the recording in the following format:");
					System.out.println("Song name, artist, duration, bitrate");
					String [] addedRecording = s.nextLine().split(", ");
					String artist = addedRecording[0];
					String name = addedRecording[1];
					int duration = Integer.parseInt(addedRecording[2]);
					int bitrate = Integer.parseInt(addedRecording[3]);
					Recording newRecording = new AudioRecording(artist, name, duration, bitrate);
					user.addToPlaylist(newRecording);
					System.out.println("Recording: " + newRecording + " added successfully");
					}
					else{
						if(audioOrVideo.charAt(0) == 'v' || audioOrVideo.charAt(0) == 'V') {
						System.out.println("Please provide all information of the recording in the following format:");
						System.out.println("Song name, artist, duration, framerate");
						String [] addedRecording = s.nextLine().split(", ");
						String artist = addedRecording[0];
						String name = addedRecording[1];
						int duration = Integer.parseInt(addedRecording[2]);
						int framerate = Integer.parseInt(addedRecording[3]);
						Recording newRecording = new AudioRecording(artist, name, duration, framerate);
						user.addToPlaylist(newRecording);
						System.out.println("Recording: " + newRecording + " added successfully");
						}
					}
						break;
				case "remove":
					if (value == null) {
						System.out.println("Please specify the recording. Try again!");
						break;
					}
					Recording removedRecording = Util.isInt(value) ? playlist.get(Integer.parseInt(value)) : playlist.get(value);
					if (removedRecording == null) {
						System.out.println("Recording not found! Make sure spelling and capitalization is right");
						break;
					}
					playlist.remove(removedRecording);
					System.out.println("Recording: " + removedRecording + " has been removed");
					break;
				case "entire":
					for(int i=0; i<playlist.getSize(); i++) {
						Recording r = playlist.get(i);
						r.play();
					}
					break;
				case "shuffle":
					playlist.shuffle();
					System.out.println("Playlist shuffled successfully");
					break;
				case "save":
					try {
					fos = new FileOutputStream("UserPlaylist.txt", false);
					pw = new PrintWriter(fos);
					for(int i=0; i< user.getPlaylist().getSize(); i++) {
					Recording r = playlist.get(i);
					pw.print(r + "\n");
					}
					}
					catch (FileNotFoundException e) {
						System.out.println("No file found");
					}
					finally {
						pw.close();
						try {
							fos.close();
						}
						catch (IOException ioe){
						}
					}
					System.out.println("Playlist saved successfully");
					break;
				case "stats":
					System.out.println("These are your stats:");
					System.out.println("(Artist – Name – Number of plays)");

					for(int i=0; i<playlist.getSize(); i++) {
						Recording r = playlist.get(i);
						System.out.println(r.artist + " - " + r.name + " - " + r.getPlayed() + "\n");
					}
					break;
				case "play":
					if (value == null) {
						System.out.println("Please specify the recording. Try again!");
						break;
					}
					Recording r = Util.isInt(value) ? playlist.get(Integer.parseInt(value)) : playlist.get(value);
					if (r == null) {
						System.out.println("Recording not found!");
						break;
					}
					r.play();
					break;
				case "back":
					break back;
				case "import":
					boolean merge = false;
					if (value == null) {
						System.out.println("Please provide the file or user name");
						break;
					}

					// Deals with merging possibility
					if (playlist != null && playlist.getSize() > 0) {
						System.out.println(
								"This user already has a playlist assigned to it. Do you want to merge the new one to it? (The other option will override everything)");
						String c = Util.closestString(commandList, s.nextLine());
						if (c.equals("yes"))
							merge = true;
					}

					// Enters the recursive importing menu
					importingMenu(s, value, user, merge);

					// Updates playlist being used here
					playlist = user.getPlaylist();

					break;
				case "return":
					run();
				default:
					System.out.println("Command not found. Try again");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void importingMenu(Scanner s, String value, User user, boolean merge) {
		PlayList playlist = user.getPlaylist();
		PlayList playlist2 = null;

		// Cancel must only be exact due to the problem of value also being the file or
		// user we want to import. We must not allow any user to have a command name.
		// That could cause some problems
		if (value.equals("cancel")) {
			System.out.println("Operation cancelled by the user");
			return;
		}

		// Tries to find a file with that string input
		try {
			if (new File(value).exists()) 
				playlist2 = PlayList.load(value);
	
			if (playlist2 == null && new File(value + ".csv").exists()) 
				playlist2 = PlayList.load(value + ".csv");
		
			User found = Util.isInt(value) ? searchUser(Integer.parseInt(value)) : searchUser(value, false);

			if (playlist2 == null) {
				if (found == null) {
					System.out.println("Nothing was found. Searching possibilities...");
					ArrayList<String> options = Util.retrieveFilesWithExtension(".csv");
					// We could check if they are in the correct format we want to import. but that
					// would be way too much work. We can stick with only csv extension that it will
					// be no problem I think
					if (options.size() != 0)
						System.out.println("Here are some file suggestions found nearby:");
					// We have to filter the options that have the format we want later
					options.forEach(System.out::println);
					ArrayList<String> bestMatches = Util.closestStrings(userSummary(), value, 3);
					// Filter matches
					bestMatches.remove(user.getName());
					if (bestMatches.size() > 0)
						System.out.println("Here are users with similar name:");
					// And look only for users that have non-blank playlists
					bestMatches.forEach(System.out::println);
					if (options.size() > 0 || bestMatches.size() > 0) {
						System.out.println("Choose one of them or input a valid file or user or cancel the operation");
						value = s.nextLine();
						importingMenu(s, value, user, merge);
					}
				} else
					playlist2 = found.getPlaylist().clone();
			} else if (found != null) {
				System.out.println(
						"Looks like there is a user with the same name as a file that exists in the directory. Do you want to import from the user?");
				playlist2 = Util.closestString(getCommandList(), s.nextLine()).equals("yes")
						? found.getPlaylist().clone()
						: playlist2;
			}

			if (playlist2 != null)
				if (merge) {
					user.setPlaylist(playlist.merge(playlist2));
					System.out.println("Merged successfully " + (user.getPlaylist().getSize() - playlist.getSize())
							+ " recordings");
				} else {
					user.setPlaylist(playlist2);
					System.out.println("Imported successfully " + user.getPlaylist().getSize() + " recordings");
				}

		} catch (Exception e) {
			System.out.println("Error while importing playlist. Try again");
			e.printStackTrace();
		}
	}

	private void printMenu() {
		System.out.println("~~Welcome to Gabriel and Adam's Playlist main menu~~");
		System.out.println("Please enter one of the following options:");
		System.out.println("User <your username>     -> to enter the user menu");
		System.out.println("Add user                 -> to add a new user");
		System.out.println("Remove user              -> to remove an existing user");
		System.out.println("List all users           -> to list all existing users");
		System.out.println("exit                     -> to exit from the system");

	}

	private void printUserMenu(User user) {
		System.out.println(user.getName() + "'s user menu [ID: " + user.getId() + "]");
		System.out.println("Choose an option:");
		
		System.out.println("play <song name or id>         -> to play a recording of the playlist");
		System.out.println("Entire                         -> to play the enitre playlist once");
		System.out.println("Shuffle                        -> to shuffle the playlist once");
		System.out.println("Add                            -> to manually add one recording");
		System.out.println("Remove <song name or id>       -> to remove one recording based on id or name");
		System.out.println("Save                           -> to save the playlist to a file ");
		System.out.println("Stats                          -> to display playlist statistics");
		System.out.println("import <user or file name>     -> to import a playlist from a user or a file");
		System.out.println("return                         -> to return");
		System.out.println("Exit                           -> to exit");
	}

	// We should also separate this in different menus
	private ArrayList<String> getCommandList() {
		ArrayList<String> commands = new ArrayList<String>();
		commands.add("play");
		commands.add("exit");
		commands.add("user");
		commands.add("return");
		commands.add("list");
		commands.add("remove");
		commands.add("yes");
		commands.add("cancel");
		commands.add("shuffle");
		commands.add("import");
		commands.add("no");
		commands.add("add");
		commands.add("save");
		commands.add("stats");
		commands.add("entire");
		return commands;
	}

	// Search user by name or index
	private User searchUser(String value, boolean levenshtein) {
		if (Util.isInt(value)) {
			int index = Integer.parseInt(value);
			if (index >= 0 && index < users.size())
				return users.get(index);
		} else {
			// User name don't have to be exact
			if (levenshtein)
				value = Util.closestString(userSummary(), value);
			for (User u : users)
				if (u.getName().equals(value))
					return u;
		}
		return null;
	}

	private ArrayList<String> userSummary() {
		ArrayList<String> names = new ArrayList<String>();
		users.forEach(u -> names.add(u.getName()));
		return names;
	}

	// Search user by id
	private User searchUser(int id) {
		for (User u : users)
			if (u.getId() == id)
				return u;
		return null;
	}

}