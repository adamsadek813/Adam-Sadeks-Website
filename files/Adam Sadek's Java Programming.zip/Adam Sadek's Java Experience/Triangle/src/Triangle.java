public class Triangle {
double a;
double b;


Triangle() {
	a=1;
	b=1;
}
Triangle(double newA, double newB) {
	a=newA;
	b=newB;
}
void setA(double newA) {
	a=newA;
}

void setB(double newB) {
	b=newB;
}
double getA() {
	return a;
}
double getB() {
	return b;
}

double calculateArea() {
	double triangleArea = b * a;
	return triangleArea;
}
}
