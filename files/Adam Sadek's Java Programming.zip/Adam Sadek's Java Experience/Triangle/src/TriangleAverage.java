import java.util.Random;
public class TriangleAverage {
	public static void main(String[] args){ 
	Random randomizer = new Random();
double c = 7;
double d = randomizer.nextInt(12) + 3;
double e = Math.cos(d);
int f = 7;
Triangle triangA1 = new Triangle();
Triangle triangB1 = new Triangle(c,d);

triangA1.setA(e);
triangA1.setB(f);
triangA1.calculateArea();
triangB1.calculateArea();

double avg = (triangB1.calculateArea() + triangA1.calculateArea()) / 2;
System.out.println("The average area is " + avg);
	}
}
