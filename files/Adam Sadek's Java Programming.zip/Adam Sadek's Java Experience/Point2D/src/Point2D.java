class Point2D {
   	// Attributes
   	int x;
   	int y;
    double distFromOrigin;
    double distFromPoint;
    int x2;
    int y2;
    
   	// Methods
   	// Accessor / getter method for attribute x
   	int getX() {
          	return x;
   	}
      
   	// Accessor / getter method for attribute y
   	int getY(){
          	return y;
   	}
      
   	// Mutator / setter method for attribute x
   	void setX(int newX){
          	x = newX;
   	}
      
	// Mutator / setter method for attribute y
   	void setY(int newY){
          	y = newY;
   	}
 
// Add method printDistanceToOrigin below [2.5 pts]
 double printDistanceToOrigin() {
	 distFromOrigin = Math.sqrt((Math.pow(x, 2)) + (Math.pow(y, 2)));
	 return distFromOrigin;
 }
 
 // Add method calculateDistanceToX2AndY2 below [2.5 pts]
 double calculateDistanceToX2AndY2(int x2, int y2) {
	 distFromPoint = Math.sqrt((Math.pow((x-x2), 2)) + (Math.pow((y-y2), 2)));
	 return distFromPoint;
 }
}

