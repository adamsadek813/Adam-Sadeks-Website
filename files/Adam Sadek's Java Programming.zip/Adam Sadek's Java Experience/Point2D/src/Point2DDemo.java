class Point2DDemo {
	public static void main (String args[]){
          	 
          	 // Other variables
          	 int x2 = 3;
          	 int y2 = 4;
          	 
          	 // Instantiating (creating) objects
          	 Point2D p1 = new Point2D();
          	 Point2D p2 = new Point2D();
          	 
          	 // Set the attribute values for p1
          	 p1.x = 4;
          	 p1.y = 0;
          	 
          	 // Set the attribute values for p2
          	 p2.x = 5;
          	 p2.y = 4;
          	 
          	 System.out.println("P1: The distance from this point to origin is: " + p1.printDistanceToOrigin());
          	 
          	 
          	 System.out.println("P2: The distance from this point to origin is: " + p2.printDistanceToOrigin());
          	 
          	 System.out.println("Distance from P1 to (0,2): " + p1.calculateDistanceToX2AndY2(2, 0));
          	 
          	 System.out.println("Distance from P2 to (" + x2 + "," + y2 + "): " + p1.calculateDistanceToX2AndY2(x2, y2));
 
   	}
}

