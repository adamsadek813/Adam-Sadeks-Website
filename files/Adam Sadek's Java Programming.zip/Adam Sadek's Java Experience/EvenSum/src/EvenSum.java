import java.util.Scanner;
public class EvenSum {
	public static void main (String args[]) {
		
	String enteredValue;
	int doubleValue = 0;
	int sum = 0;
	int x = 0;
		while(x <10) {
	Scanner scan = new Scanner (System.in);
	System.out.println("Enter a number >");
	enteredValue = scan.next();
	doubleValue = Integer.parseInt(enteredValue);
	if(doubleValue % 2 == 0) {
	sum = sum + doubleValue;
	x = x + 1;
		}
			else {
				System.out.println("Try Again!");
			}
		}
		System.out.println("The total sum is: " + sum);
}
}