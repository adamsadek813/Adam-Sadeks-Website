
/**
 * @author Adam Sadek
 * @author Gabriel Roskowski
 */
public class Runner {
	private String name;
	private int marathonTimeSeconds;
	private static final int WORLD_RECORD_TIME_SECONDS = (3600 * 2) + (60 * 3) + 59;

	public Runner(String n, int h, int m, int s) {
		name = n;
		setTime(h, m, s);
	}

	public void setTime(int h, int m, int s) {
		if (h >= 0 && m >= 0 && s >= 0) {
			marathonTimeSeconds = (h * 3600) + (m * 60) + s;
		}
	}

	public String getName() {
		return name;
	}

	public int getSeconds() {
		return marathonTimeSeconds;
	}

	public double percentageSlower() {
		//When there is an input error the marathonTimeSeconds and percentSlower immediately go to 0, to imply there is a problem with the input
		double roundedDouble = 0;
		double percentSlower;
		if(marathonTimeSeconds != 0) {
		percentSlower = ((((double) marathonTimeSeconds) / ((double) WORLD_RECORD_TIME_SECONDS)) - 1) * 100.0d;
		roundedDouble = Math.round(percentSlower * 100.00) / 100.00;
		}
		return roundedDouble;
	}

	public Runner(String n, String data) {
		name = n;

		if (data == null)
			return;

		String[] arrOfStr = data.split(":", -1);

		//If the input format is incorrect, set everything to zero and return
		if (arrOfStr == null || arrOfStr.length < 3
				|| (!isInteger(arrOfStr[0]) || !isInteger(arrOfStr[1]) || !isInteger(arrOfStr[2]))) {
			setTime(0, 0, 0);
			return;
		}

		String h = arrOfStr[0];
		String m = arrOfStr[1];
		String s = arrOfStr[2];
		int hours = Integer.parseInt(h);
		int minutes = Integer.parseInt(m);
		int seconds = Integer.parseInt(s);
		setTime(hours, minutes, seconds);
	}

	public static boolean isInteger(String s) {
		if (s.isEmpty())
			return false;
		for (int i = 0; i < s.length(); i++) 
				if (Character.digit(s.charAt(i), 10) < 0)
					return false;
		return true;
	}

}
