
public class VectorGabriel {
        public static void main(String[] args) {
                int [] v1 = { 1, 3, 5};
                int [] v2 = { -1, -3, -5};
                int [] v3 = { 1, 2, 3, 4};
                int [] v4 = { 1, 1, 1, 1};
               
                System.out.println(vectorToString(add(v1,v2)));
                System.out.println(vectorToString(add(v1,v3)));
                System.out.println(vectorToString(add(v2,v3)));
                System.out.println(vectorToString(add(v3,v4)));
                
                System.out.println(dotProduct(v1,v2));
                System.out.println(dotProduct(v1,v3));
                System.out.println(dotProduct(v2,v3));
                System.out.println(dotProduct(v3,v4));
                
          
       }
static String vectorToString(int [] anArray){
	String arrayString = "<";
	for(int x = 0; x < anArray.length; x++) {
		if(x == anArray.length - 1) {
			arrayString = arrayString + anArray[x];
		}
		else {
		arrayString = arrayString + anArray[x] + ",";
	}
	}
	return arrayString.concat(">");
	}

static int [] add(int [] array1, int [] array2){
	
	int [] addedArray = new int[0];
	if (array1.length == array2.length) {
		addedArray = new int[array1.length];
		for(int x = 0; x < array1.length; x++) {
			addedArray[x] = array1[x] + array2[x];
		}
		System.out.print(vectorToString(array1) + "+" + vectorToString(array2) + "=");
	}
	else {
		System.out.print("Sum not defined, vectors of different length" + vectorToString(array1) + "+" + vectorToString(array2) + "=");
	}
	return addedArray;
}

static int dotProduct(int [] array1, int [] array2){
	int multipliedValue = 0;
	if(array1.length == array2.length) {
		for(int x = 0; x<array1.length; x++) {
			multipliedValue = multipliedValue + (array1[x] * array2[x]);
		}
		System.out.print(vectorToString(array1) + "." + vectorToString(array2) + "=");
	}
	else {
		System.out.print("Dot Product not defined, vectors of different length" + vectorToString(array1) + "." + vectorToString(array2) + "=");
	}
	return multipliedValue;
}
}

