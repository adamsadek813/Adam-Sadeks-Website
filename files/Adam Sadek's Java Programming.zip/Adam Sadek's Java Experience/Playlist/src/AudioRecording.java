

public class AudioRecording extends Recording {
	private final double bitrate;

	public AudioRecording() {
		super();
		bitrate = 0;
	}

	public AudioRecording(String artist, String name, int duration, double bitrate) {
		super(artist, name, duration);
		this.bitrate = Double.isNaN(bitrate) || Double.isInfinite(bitrate) ? 0 : bitrate;
	}

	public double getBitrate() {
		return bitrate;
	}

	@Override
	public String toString() {
		return super.toString() + " [AUDIO | bitrate: " + bitrate + " kbps]";
	}
}
