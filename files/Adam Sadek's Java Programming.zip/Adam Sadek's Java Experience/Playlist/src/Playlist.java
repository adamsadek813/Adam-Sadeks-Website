
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.StringJoiner;

public class Playlist {
	private String name;
	private int numberOfRecordings;
	private int durationInSeconds;
	private final int MAX_PLAYLIST_SIZE;
	private Recording[] recordingList;

	public Playlist() {
		this(null, 5);
	}

	// It was decided to set the size of the array when invalid sizes (<0) are given
	// to zero

	public Playlist(String name, int maxSize) {
		this.name = name == null ? "Unknown" : name;
		this.MAX_PLAYLIST_SIZE = maxSize <= 0 ? 0 : maxSize;
		this.recordingList = new Recording[MAX_PLAYLIST_SIZE];
	}

	// Adds properly valid recordings to the array and updates important methods
	public boolean add(Recording recording) {
		if (recording != null && numberOfRecordings < MAX_PLAYLIST_SIZE) {
			recordingList[numberOfRecordings++] = recording;
			durationInSeconds += recording.getDuration();
			return true;
		}
		return false;
	}

	// There is no need to check prior to the loop if the number of registered
	// recordings is non-zero. The loop would just skip and have no evaluation as
	// the first loop checking would return false
	public void play() {
		for (int i = 0; i < numberOfRecordings; i++)
			if (recordingList[i] != null)
				recordingList[i].play();

		if (numberOfRecordings == 0)
			System.out.println("ERROR: empty playlist");
		else
			System.out.println();
	}

	// StringJoiner was chosen to be used here because of its time efficiency when
	// joining strings with a common separator
	@Override
	public String toString() {
		StringJoiner sj = new StringJoiner("\n");

		sj.add("Playlist: " + name + " " + formatDuration(durationInSeconds));
		for (int i = 0; i < numberOfRecordings; i++)
			sj.add(recordingList[i].toString());

		return sj.toString() + "\n";
	}

	public void shuffle(int numberOfRecordingsToPlay) {
		Random r = new Random();
		for (int i = 0; i < numberOfRecordingsToPlay; i++) {
			Recording recording = recordingList[r.nextInt(recordingList.length)];
			if (recording != null)
				recording.play();
		}
		System.out.println();
	}

	public void load(String fileName) {
		try {
			File file = new File(fileName);
			BufferedReader br = new BufferedReader(new FileReader(file));

			String buff = "";

			// This code served to count how many recordings would be added to the playlist.
			// However, it seems like this number is already provided in the constructor
			/*
			 * int lines = 0; while ((buff = br.readLine()) != null) if (!buff.isEmpty() &&
			 * !buff.isBlank()) lines++;
			 * 
			 * recordingList = new Recording[lines]; br = new BufferedReader(new
			 * FileReader(file));
			 */

			int i = 0;
			while ((buff = br.readLine()) != null) {
				String[] s = buff.split(",");

				// Checks basic structure of a line
				if (s.length < 5) {
					System.out.println("ERROR: invalid recording format (" + buff + ")");
					continue;
				}

				Recording r = null;
				int duration = 0;
				double bfrate = 0;

				// Tries to parse numerical data
				try {
					duration = Integer.parseInt(s[3].trim());
					bfrate = Double.parseDouble(s[4].trim());
				} catch (NumberFormatException ne) {
					System.out.println("ERROR: Number format exception. Recording rejected (" + buff + ")");
					continue;
				}

				// Creates an appropriate recording depending on the type
				if (s[0].trim().equals("A"))
					r = new AudioRecording(s[2].trim(), s[1].trim(), duration, bfrate);
				else if (s[0].trim().equals("V"))
					r = new VideoRecording(s[2].trim(), s[1].trim(), duration, bfrate);

				// Stops adding recordings in case the provided number is smaller than what
				// there is in reality
				if (i > recordingList.length)
					break;

				// Either way null recordings will be filtered later
				recordingList[i++] = r;
			}

		} catch (IOException e) {
			System.out.println("ERROR: File <" + fileName + "> not found!");
		}
	}

	// This method also exist in the Recording class. Maybe in a real project these
	// types of common auxiliary methods could be added to a utility class that has
	// everything static
	private static String formatDuration(int d) {
		return "[" + (d / 60) + "m" + (d % 60) + "s]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		if (name != null)
			this.name = name;
	}

	public int getNumberOfRecordings() {
		return numberOfRecordings;
	}

	public int getDurationInSeconds() {
		return durationInSeconds;
	}

	public int getMAX_PLAYLIST_SIZE() {
		return MAX_PLAYLIST_SIZE;
	}

	public Recording[] getRecordingList() {
		return recordingList;
	}

}
