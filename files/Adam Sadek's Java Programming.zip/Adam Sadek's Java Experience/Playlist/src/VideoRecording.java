

public class VideoRecording extends Recording {

	private final double framerate;

	public VideoRecording() {
		super();
		framerate = 0;
	}

	public VideoRecording(String artist, String name, int duration, double framerate) {
		super(artist, name, duration);
		this.framerate = Double.isNaN(framerate) || Double.isInfinite(framerate) ? 0 : framerate;
	}

	@Override
	public String toString() {
		return super.toString() + " [VIDEO | framerate: " + framerate + " fps]";
	}

	public double getFramerate() {
		return framerate;
	}
}
