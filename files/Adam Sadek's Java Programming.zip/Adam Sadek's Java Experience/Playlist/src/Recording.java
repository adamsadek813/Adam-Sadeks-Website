

public class Recording {
	protected final String ARTIST, NAME;
	protected final int DURATION_IN_SECONDS;

	public Recording() {
		this(null, null, 0);
	}

	public Recording(String artist, String name, int duration) {
		this.ARTIST = artist == null ? "Unknown" : artist;
		this.NAME = name == null ? "Unknown" : name;
		this.DURATION_IN_SECONDS = duration < 0 ? 0 : duration;
	}

	// Plays the recording only if the duration is not equal to zero (negative
	// durations will not exist because of the constructor validation)
	public void play() {
		if (DURATION_IN_SECONDS == 0)
			System.out.println("Error: cannot play this recording");
		else
			System.out.println("Now playing: " + this);
	}

	@Override
	public String toString() {
		return ARTIST + " - " + NAME + " " + formatDuration(DURATION_IN_SECONDS);
	}

	private static String formatDuration(int d) {
		return "[" + (d / 60) + "m" + (d % 60) + "s]";
	}

	public String getArtist() {
		return ARTIST;
	}

	public String getName() {
		return NAME;
	}

	public int getDuration() {
		return DURATION_IN_SECONDS;
	}

}
