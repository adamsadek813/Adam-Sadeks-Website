import java.util.Random;

public class Problem2b {
	public static void main(String[] args) {
		// Starting data with a "random" sorted array
		Random r = new Random();
		int[] array = new int[20];
		int q = r.nextInt(10);
		for (int i = 0; i < array.length; i++)
			array[i] = (q += r.nextInt(50));
		int x = r.nextInt(800);

		// Printing stuff
		for (int i = 0; i < array.length; i++)
			System.out.print(array[i] + "\t");
		System.out.println();
		System.out.println("Is there two distinct elements that sum into " + x + " inside the array above? "
				+ (isThere(array, x) ? "YES!" : "NO!"));
	}

	private static boolean isThere(int[] array, int x) {
		// Verify trivial scenarios first
		int l = array.length;
		if (l < 2)
			return false;
		if (array[0] + array[1] > x)
			return false;
		if (array[l - 1] + array[l - 2] < x)
			return false;

		int s = 0;
		int[] other = new int[l];
		// Creates another array that is the difference between the original array and x
		for (int i = 0; i < l; i++) {
			other[i] = x - array[i];
			if (other[i] >= array[0] && s == 0)
				s = i;
		}
		// Checks for every item in the other array: if it exists in the original array,
		// that means there are two different numbers that summed up result in x
		for (int i = s; i < l; i++) {
			int index = binarySearch(array, other[i]);
			if (index != -1 && index != i) {
				System.out.println("Found " + array[i] + " at " + i + " and " + array[index] + " at " + index
						+ " that add to " + x);
				return true;
			}
		}
		return false;
	}

	private static int binarySearch(int[] array, int a) {
		int l = 0, h = array.length - 1, m = array.length;
		while (l <= h) {
			m = (l + h) >> 1;
			long mk = array[m];
			if (mk < a)
				l = m + 1;
			else if (mk > a)
				h = m - 1;
			else
				return m;
		}
		return -1;
	}
}
