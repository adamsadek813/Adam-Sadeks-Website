import java.util.Random;

//Program to measure elapsed time in Java
class TimeUtil {
	public static void main(String[] args) throws InterruptedException {
		// Warming up time (5s)
		long warming = System.currentTimeMillis();
		int i = 0;
		while (System.currentTimeMillis() - warming < 5000)
			i++;
		System.out.println(i);//Compiler will destroy i if it doesn't see its use
		// Computes the default execution time of the testing loop
		long startTime = System.nanoTime();
		long startingTime = 0;
		int executions = 0;
		// Executes blank algorithm for 5 seconds
		while (System.nanoTime() - startTime < 5E9) {
			startingTime += testMethod();
			executions++;
		}
		long endTime = System.nanoTime();
		long defaultTime = (endTime - startTime) / executions;
		long defaultStartingTime = startingTime / executions;
		// Starts counting time
		startingTime = 0;
		executions = 0;
		startTime = System.nanoTime();
		// Executes algorithm for 5 seconds
		while (System.nanoTime() - startTime < 5E9) {
			startingTime += executesTheAlgorithm();
			executions++;
		}
		endTime = System.nanoTime();

		//Prints results
		System.out.println("Average empty execution time:     " + Math.max(0, defaultTime) + "ns");
		System.out.println("Average empty starting time:      " + Math.max(0, defaultStartingTime) + "ns");
		System.out.println("Average starting time:            " + Math.max(0, startingTime / executions) + "ns");
		System.out.println(
				"Average execution time w error:   " + Math.max(0, ((endTime - startTime) / executions)) + "ns");
		System.out.println("Average algorithm execution time: "
				+ Math.max(0, ((endTime - startTime - startingTime) / executions - defaultTime) + defaultStartingTime)
				+ "ns");
		//The last one is the only that really matters
	}

	// A blank method just to get the amount of time each call and blank starting
	// space takes to execute in the processor
	private static long testMethod() {
		long start = System.nanoTime();
		long end = System.nanoTime();
		return end - start;
	}

	// The algorithm itself, with space for startup process
	private static long executesTheAlgorithm() throws InterruptedException {
		long start = System.nanoTime();
		Random r = new Random();
		int[] array = new int[12000];
		for (int i = 0; i < array.length; i++)
			array[i] = r.nextInt(20001) - 10000;
		long end = System.nanoTime();
		
		//Replace this by insertion or binary insertion methods
		binaryInsertionSort(array);

		return end - start;
	}

	//1000  elements:   355270ns =   0.35ms
	//2000  elements:  1631568ns =   1.63ms
	//4000  elements:  5740809ns =   5.74ms
	//8000  elements: 25976271ns =  25.97ms
	//12000 elements: 61671283ns =  61.67ms
	//16000 elements 112154791ns = 112.15ms
	private static void insertionSort(int[] array) {
		for (int i = 1; i < array.length; i++) {
			int a = array[i], j = i - 1;
			for (; j >= 0 && array[j] >= a; j--)
				array[j + 1] = array[j];
			array[j + 1] = a;
		}
	}

	//1000  elements:   315974ns =   0.32ms
	//2000  elements:  1068394ns =   1.07ms
	//4000  elements:  4092775ns =   4.09ms
	//8000  elements: 14463389ns =  14.46ms
	//12000 elements: 33242169ns =  33.24ms
	//16000 elements: 71169188ns =  71.17ms
	private static void binaryInsertionSort(int[] array) {
		for (int i = 1; i < array.length; i++) {
			int a = array[i];
			int index = binarySearch(array, i, a);
			for (int e = i - 1; e >= index; e--)
				array[e + 1] = array[e];
			array[index] = a;
		}
	}

	private static int binarySearch(int[] array, int i, int a) {
		int l = 0, h = i - 1, m = i;
		while (l <= h) {
			m = (l + h) >> 1;
			long mk = array[m];
			if (mk < a)
				l = m + 1;
			else if (mk > a)
				h = m - 1;
			else
				return m;
		}
		return l;
	}
}