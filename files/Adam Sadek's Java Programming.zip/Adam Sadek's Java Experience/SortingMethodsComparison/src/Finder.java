
import java.util.Arrays;
import java.util.Random;

public class Finder {
	public static void main(String[] args) {
		Random r = new Random();
		int[] array = new int[20];
		int q = r.nextInt(10);
		int x = 0;

		for (int i = 0; i < array.length; i++)
			array[i] = (q += r.nextInt(10));
		x = r.nextInt(array.length * 5 + 10);
		q = 0;

		for (int i = 0; i < array.length; i++)
			System.out.print(array[i] + "\t");
		System.out.println();

		int index = find(x, array);
		if (index != -1)
			System.out.println("Found the number " + x + " at index " + index);
		else
			System.out.println("The number " + x + " wasn't found inside the array");
	}

	private static int find(int x, int[] array) {
		// Checks if x is outside the extremities of this sorted segment
		if (array[0] > x || array[array.length - 1] < x)
			return -1;
		// Performs a default search in arrays that aren't divisible anymore
		if (array.length < 3) {
			for (int i = 0; i < array.length; i++)
				if (x == array[i])
					return i;
			return -1;
		}
		// Calculates the remainder from the division of the array size by 3
		int rem = array.length % 3, k = 0;
		// Ghostly divides the array into sub-arrays to check if x is inside its sorted
		// bounds
		for (int i = 0; i < array.length; i += array.length / 3) {
			// This is the superior index of the sub-array
			int ind = Math.min(array.length, i + array.length / 3 + k);
			// Checks if x isn't contained here
			if (array[i] > x || array[ind - 1] < x) {
				// Final rearrangements for when rem is not zero
				i += k;
				k = 0;
				if (rem > 0)
					k = rem == 1 ? rem-- : --rem;
				continue;
			}
			// If it could be, then definitely generate a sub-array from the needed segment
			// and recursively search inside it
			int a = find(x, Arrays.copyOfRange(array, i, ind));
			// If something is found inside it, returns the index where it was found in the
			// sub-array + the position of the subarray in the original array
			if (a != -1)
				return a + i;
			// Final rearrangements for when rem is not zero
			i += k;
			k = 0;
			if (rem > 0)
				k = rem == 1 ? rem-- : --rem;
		}
		// Returns -1 if nothing is found
		return -1;
	}
}
