
import java.text.DecimalFormat;

public class InvestCalc {
	public static final int SHORT_TERM = 5;
	public static final int MIDDLE_TERM = 10;
	public static final int LONG_TERM = 20;

	public static final String FORMAT_OUTPUT_PERCENTAGE = "##0.00%";
	public static final String FORMAT_OUTPUT_DOLAR = "$###,##0.00";

	private double rate, principal;

	public InvestCalc(double rate, double principal) {
		this.rate = rate;
		this.principal = principal;
	}

	public InvestCalc() {
		this(0, 0);
	}

	public double futureValue(int year) {
		return principal * Math.pow(1 + rate, year);
	}

	public void displayTable() {

		System.out.println("YEAR\tINTEREST RATE\tPRINCIPAL\tFUTURE VALUE");
		displayRow(SHORT_TERM);
		displayRow(MIDDLE_TERM);
		displayRow(LONG_TERM);

	}

	private void displayRow(int year) {
		DecimalFormat percentageFormatter = new DecimalFormat(FORMAT_OUTPUT_PERCENTAGE);
		DecimalFormat dolarFormatter = new DecimalFormat(FORMAT_OUTPUT_DOLAR);
		System.out.println(year + "\t" + percentageFormatter.format(rate) + "\t\t" + dolarFormatter.format(principal)
				+ "\t\t" + dolarFormatter.format(futureValue(year)));
	}

	@Override
	public String toString() {
		DecimalFormat percentageFormatter = new DecimalFormat(FORMAT_OUTPUT_PERCENTAGE);
		DecimalFormat dolarFormatter = new DecimalFormat(FORMAT_OUTPUT_DOLAR);
		return "Principal: " + dolarFormatter.format(principal) + " Interest rate: " + percentageFormatter.format(rate);
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getPrincipal() {
		return principal;
	}

	public void setPrincipal(double principal) {
		this.principal = principal;
	}

}
