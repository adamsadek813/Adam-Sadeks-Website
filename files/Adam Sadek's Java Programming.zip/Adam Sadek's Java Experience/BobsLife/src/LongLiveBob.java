public class LongLiveBob {
public static void main (String args[]) {
	
	BobsLife hisLife = new BobsLife(0, 5, 4, "at the gym");
	System.out.println(hisLife.toString());
	
	hisLife.move("at the gym");
	hisLife.nextTime();
	System.out.println(hisLife.toString());
	
	hisLife.move("at home");
	hisLife.nextTime();
	System.out.println(hisLife.toString());
	
	hisLife.move("at work");
	hisLife.nextTime();
	System.out.println(hisLife.toString());

	hisLife.move("at home");
	hisLife.nextTime();
	System.out.println(hisLife.toString());
	
	hisLife.move("at work");
	hisLife.nextTime();
	System.out.println(hisLife.toString());
	
	hisLife.move("at home");
	hisLife.nextTime();
	System.out.println(hisLife.toString());
	
}
}
