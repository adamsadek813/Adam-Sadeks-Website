public class BobsLife {

String h = "at home";
String w = "at work";
String g = "at the gym";
String j = "in jail";
String location;
int hunger;
int money;
int fitness;
int time = 0;
boolean dead;
boolean alive;
boolean brokeAndJail;

public BobsLife(int newHunger, int newMoney, int newFitness, String newLocation){
	time = 0;
	dead = false;
	brokeAndJail = false;
	hunger = newHunger;
	money = newMoney;
	fitness = newFitness;
	location = newLocation;
	this.correctLocation();
}

private void correctLocation() {
	if (location != h && location != w && location != g && location != j) {
		location = h;
	}
}


void move(String newLocation) {
	location = newLocation;
	this.correctLocation();
	}
	
void nextTime() {
	time = time + 1;
	if (brokeAndJail == true || dead == true) {
	}
	else {
	if (h.equals(location)) {
		hunger = hunger - 3;
		money = money - 1;
		if (hunger < 0) {
			hunger = 0;
	}
	}
	else if (w.equals(location)) {
		hunger = hunger + 2;
		money = money + 3;
		fitness = fitness - 1;
	}
		else if (g.equals(location)) {
		hunger = hunger + 3;
		money = money - 2;
		fitness = fitness + 2;
		}
	}
	if (hunger > 6 || fitness < 0) {
		dead = true;
	}
	else {dead = false;}
	if (money < 0) {
		brokeAndJail = true;
		location = j;
	}
	else {brokeAndJail = false;}
}


public String toString() {
	String bobsState = "Time: " + time + " - location: " + location + ", hunger: " + hunger + ", money: " + money + ", fitness: " + fitness + ", dead? " + dead + ", in jail? " + brokeAndJail;
return bobsState;
}

}