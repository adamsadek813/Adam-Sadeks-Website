public class LongLiveBob2 {
	public static void main (String args[]) {
		
		BobsLife hisLife = new BobsLife(0, 5, 4, "at the gym");
		System.out.println(hisLife.toString());
		
		String [] loop = {"at home", "at work", "at the gym"};
		
		for(int x = 0; x < 167; x++) {
			hisLife.move(loop[2]);
			hisLife.nextTime();
			System.out.println(hisLife.toString());
			hisLife.move(loop[0]);
			hisLife.nextTime();
			System.out.println(hisLife.toString());
			hisLife.move(loop[1]);
			hisLife.nextTime();
			System.out.println(hisLife.toString());
			hisLife.move(loop[0]);
			hisLife.nextTime();
			System.out.println(hisLife.toString());
			hisLife.move(loop[1]);
			hisLife.nextTime();
			System.out.println(hisLife.toString());
			hisLife.move(loop[0]);
			hisLife.nextTime();
			System.out.println(hisLife.toString());
			
		}
	
	}
}

//2 0 1 0 1 0
