public class Book {

	String author;
	String title;
	int pages;
	double price;
	String publishDate;
	String releaseDate;
	int reviewNumber;
	String reviews;
	String [] sameAuthorBooks;
	String sameBookLists;
	
	
}
