
public class Sphere extends Circle {

	Sphere(){
		super();
	}
	
	Sphere(double newRadius){
		super(newRadius);
	}
	
	
	double getVolume() {
		return (4.0/3.0)*Math.PI*Math.pow(radius, 3);
	}


	public String toString() {
		return "This is a sphere with radius " + radius;
	}
	
}
