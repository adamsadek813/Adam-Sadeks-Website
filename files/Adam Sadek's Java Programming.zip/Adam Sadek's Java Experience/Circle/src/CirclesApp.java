import java.util.Random;

public class CirclesApp {
	public static void main (String args[]) {
		Random myRandom = new Random();
		
		for(int i=0;i<6;i++) {
		Sphere mySphere1 = new Sphere(myRandom.nextInt(10) + 1.0);
		System.out.println(mySphere1.toString());
		}
		
	}
}
