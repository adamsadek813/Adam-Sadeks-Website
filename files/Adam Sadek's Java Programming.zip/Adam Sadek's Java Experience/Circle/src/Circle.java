
public class Circle {
protected double radius;

Circle(){
	 radius = 5;
}

Circle(double newRadius){
	if(newRadius < 0) {
		radius = 5;
	}
	else {
	radius = newRadius;
	}
}

double getRadius(){
	return radius;
}

double getSurfaceArea() {
	return Math.PI*radius;
}
}
