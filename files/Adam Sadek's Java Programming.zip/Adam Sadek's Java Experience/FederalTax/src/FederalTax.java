import java.util.Locale;
import java.text.NumberFormat;
public class FederalTax {
	double taxableIncome;
	double taxPaid;
double a = 22100;
double b = 53500;
double c = 115000;
double d = 250000;

double z = 3315;
double y = 12107;
double x = 31172;
double w = 79772;

double p1 = .15;
double p2 = .28;
double p3 = .31;
double p4 = .36;
double p5 = .396;

public FederalTax() {
	taxableIncome = 0;
}

public FederalTax(double newTaxableIncome) {
	if (newTaxableIncome < 0) {
		taxableIncome = 0;
		}
		else {taxableIncome = newTaxableIncome;}
}

public double getTaxableIncome() {
return taxableIncome;
}

public void setTaxableIncome(double newTaxableIncome) {
	if (newTaxableIncome < 0) {
		taxableIncome = 0;
		}
		else {taxableIncome = newTaxableIncome;}
		}

public double taxPaid() {
	if (taxableIncome <= a) {
		taxPaid = taxableIncome * p1;
	}
		else if (taxableIncome > a && taxableIncome <= b) {
			taxPaid = ((taxableIncome-a )* p2) + z;
		}
		else if (taxableIncome > b && taxableIncome <= c) {
			taxPaid = ((taxableIncome-b )* p3) + y;
		}
		else if (taxableIncome > c && taxableIncome <= d) {
			taxPaid = ((taxableIncome-c )* p4) + x;
		}
		else if (taxableIncome > d) {
			taxPaid = ((taxableIncome-d )* p5) + w;
		}
		return taxPaid;
	}


NumberFormat USFormat = NumberFormat.getCurrencyInstance();

public String toString() {
	String incomeAndTax = "Taxable income: " + USFormat.format(taxableIncome) + "  Tax Paid: " + USFormat.format(taxPaid());
	return incomeAndTax;
	
}
}




