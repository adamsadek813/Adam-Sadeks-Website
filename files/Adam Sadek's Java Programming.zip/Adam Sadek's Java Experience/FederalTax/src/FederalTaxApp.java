import java.util.Scanner;
public class FederalTaxApp {
	public static void main (String args[]) {
	
	FederalTax defaultTest = new FederalTax();
	String test1 = defaultTest.toString();
	System.out.println("Default FederalTax Object: " + test1);
	
	Scanner scan = new Scanner (System.in);
	System.out.print("Enter your taxable income >");
	String enteredIncomeString = scan.next();
	double enteredIncomeDouble = Double.parseDouble(enteredIncomeString);
	 
	FederalTax enteredIncome = new FederalTax(enteredIncomeDouble);
	System.out.println("Updated FederalTax Object: " + enteredIncome.toString());
	
	Scanner scan2 = new Scanner (System.in);
	System.out.print("Enter another taxable income >");
	String enteredIncomeString2 = scan.next();
	double enteredIncomeDouble2 = Double.parseDouble(enteredIncomeString2);
	
	FederalTax enteredIncome2 = new FederalTax(enteredIncomeDouble2);
	System.out.println("Updated FederalTax Object: " + enteredIncome2.toString());
	
	Scanner scan3 = new Scanner (System.in);
	System.out.print("Test a negative income >");
	String enteredIncomeString3 = scan.next();
	double enteredIncomeDouble3 = Double.parseDouble(enteredIncomeString3);
	
	FederalTax enteredIncome3 = new FederalTax(enteredIncomeDouble3);
	System.out.println("Updated FederalTax Object: " + enteredIncome3.toString());
	}
}