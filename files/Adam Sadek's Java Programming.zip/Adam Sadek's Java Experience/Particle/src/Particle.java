import java.text.DecimalFormat;
public class Particle {
	
	static double A , B , C , D, start, end, increment, location, velocity, originalVelocity;
	static double greatestVelocity = 0;
	
	
	 Particle(double a, double b, double c, double d){
			A = a;
			B = b;
			C = c;
			D = d;
	}
	
		
	public String toString(){
		String locationEquation = "location(t) = " + A+"t^4"+"+"+B+"t^3"+"+"+C+"t^2"+"+"+D+"t";
			return locationEquation;
		}
		
	void table(double newStart, double newEnd, double newIncrement){
		start = newStart;
		end = newEnd;
		increment = newIncrement;
		System.out.println("Time   Loc     Vel");
		DecimalFormat df = new DecimalFormat("0.000");
		originalVelocity = (4*A*Math.pow(start, 3)) + (3*B*Math.pow(start, 2)) + (2*C*start);
		for(double x = start; x <= end; x=x+increment) {
			 location = (A*Math.pow(x, 4))+(B*Math.pow(x, 3))+(C*Math.pow(x, 2))+(D*x);
			 velocity = (4*A*Math.pow(x, 3)) + (3*B*Math.pow(x, 2)) + (2*C*x);
			 if((velocity - originalVelocity) > 1 ||  (velocity - originalVelocity) < -1) {
			System.out.println(x + "  " + df.format(location) + "  " + df.format(velocity) + " More than 1 unit movement");
			 }
			 else {
				 System.out.println(x + "  " + df.format(location) + "  " + df.format(velocity));
				 }
			originalVelocity = velocity;
	}
	}
	
	static double getMaxVelocity(){
		originalVelocity = (4*A*Math.pow(start, 3)) + (3*B*Math.pow(start, 2)) + (2*C*start);
		greatestVelocity = originalVelocity;
		for(double x = start; x <= end; x=x+increment) {
		velocity = (4*A*Math.pow(x, 3)) + (3*B*Math.pow(x, 2)) + (2*C*x);
		if(velocity > originalVelocity) {
			 greatestVelocity = velocity;
		}
		originalVelocity = velocity;
	}
		return greatestVelocity;
	}
}
		
		
		
		
		
		
		
		
		
//double t;
//Scanner myScanner = new Scanner(System.in);
//System.out.println("Enter the values for a, b, c, d: ");
//double [] anArray = new double[4];
//double greatestVelocity = 0;
//for(int i = 0; i <4; i++) {
//	anArray[i] = myScanner.nextDouble();
//}
//
//System.out.println("Particle object created.");
//System.out.println("location(t) = " + anArray[0]+"t^4"+"+"+anArray[1]+"t^3"+"+"+anArray[2]+"t^2"+"+"+anArray[3]+"t");
//System.out.println("Enter the start time");
//double startTime = myScanner.nextDouble();
//System.out.println("Enter the end time");
//double endTime = myScanner.nextDouble();
//System.out.println("Enter the increment");
//double increment = myScanner.nextDouble();
//System.out.println("Time  Loc  Vel");
//DecimalFormat df = new DecimalFormat("0.000");
//double originalVelocity = (4*anArray[0]*Math.pow(startTime, 3)) + (3*anArray[1]*Math.pow(startTime, 2)) + (2*anArray[2]*startTime);
//greatestVelocity = originalVelocity;
//for(double x = startTime; x <= endTime; x=x+increment) {
//	double location = (anArray[0]*Math.pow(x, 4))+(anArray[1]*Math.pow(x, 3))+(anArray[2]*Math.pow(x, 2))+(anArray[3]*x);
//	double velocity = (4*anArray[0]*Math.pow(x, 3)) + (3*anArray[1]*Math.pow(x, 2)) + (2*anArray[2]*x);
//	System.out.println(x + "  " + df.format(location) + "  " + df.format(velocity) );

//	}
//	if(velocity > originalVelocity) {
//		 greatestVelocity = velocity;
//	}
//	originalVelocity = velocity;
//}
//System.out.println("Max velocity in all tables = " + df.format(greatestVelocity));
//}