import java.util.Random;
public class RandomIntegersSum {
	public static void main(String[] args) {

		int numInts = 0;
		int sumInts = 0;
		int value = 0;
		
		while(numInts != 10 && sumInts <=40) {
			Random randomizer = new Random();
			value = randomizer.nextInt(10) + 1;
			sumInts = sumInts + value;
			numInts = numInts + 1;
		}
		System.out.println("Number of integers generated is: " + numInts + " The sum of the integers generated is " + sumInts);
		
	}
}
