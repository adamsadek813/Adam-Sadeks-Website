import java.util.Scanner;
public class IntegerSum {
	public static void main (String args[]) {
	String enteredValue = null;
	double sum = 0;
	double doubleValue = 1;
	while (doubleValue != -1) {
		Scanner scan = new Scanner (System.in);
		System.out.println("Enter a number >");
		enteredValue = scan.next();
		 doubleValue = Double.parseDouble(enteredValue);
		sum = sum + doubleValue;
	}
	System.out.println("The sum of all values is " + sum);
}
}
