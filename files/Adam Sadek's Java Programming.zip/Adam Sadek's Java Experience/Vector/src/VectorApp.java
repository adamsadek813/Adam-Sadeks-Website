
public class VectorApp {
	public static void main (String [] args){
	BoundVector V1 = new BoundVector(5,5,2,2);
	
	System.out.println(V1.getEndPointX());
	}
}
