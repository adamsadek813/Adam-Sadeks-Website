public class Vector {

	protected int xCoordinate = 0;
	protected int yCoordinate = 0;
	
	public Vector(){
		xCoordinate = 0;
		yCoordinate = 0;
	}
	
	public Vector(int newXCoordinate, int newYCoordinate){
		xCoordinate = newXCoordinate;
		yCoordinate = newYCoordinate;
	}
	
	public int getStartPointX() {
		return 0;
	}
	
	public int getStartPointY() {
		return 0;
	}
	
	public int getEndPointX() {
		return xCoordinate;
	}
	
	public int getEndPointY() {
		return yCoordinate;
	}
	
	public double getLength() {
		return Math.sqrt(Math.pow(xCoordinate, 2) + Math.pow(yCoordinate, 2));
	}

	
}
