
public class BoundVector extends Vector {

	private int initialXCoordinate;
	private int initialYCoordinate;
	
	public BoundVector(){
		super();
		initialXCoordinate = 0;
		initialYCoordinate = 0;
	}
	
	public BoundVector(int newXCoordinate, int newYCoordinate){
		super(newXCoordinate, newYCoordinate);
	}
	
	public BoundVector(int newXCoordinate, int newYCoordinate, int newInitialXCoordinate, int newInitialYCoordinate){
		super(newXCoordinate, newYCoordinate);
		initialXCoordinate = newInitialXCoordinate;
		initialYCoordinate = newInitialYCoordinate;
	}
	
	public double getLength() {
		return Math.sqrt(Math.pow(xCoordinate-initialXCoordinate, 2) + Math.pow(yCoordinate-initialYCoordinate, 2));
	}
	
	public int getStartPointX() {
		return initialXCoordinate;
	}
	
	public int getStartPointY() {
		return initialYCoordinate;
	}
}
