
/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         An unplayable exception that is thrown when invalid arguments are
 *         provided to the constructor of a recording-type class.
 */
@SuppressWarnings("serial")
public class UnplayableException extends IllegalArgumentException {

	public UnplayableException(String s, Throwable t) {
		super(s, t);
	}

	public UnplayableException(String s) {
		super(s);
	}
}