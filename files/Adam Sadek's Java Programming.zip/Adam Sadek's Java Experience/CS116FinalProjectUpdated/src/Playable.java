
/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         We couldn't find a legitimate way to use properly the Playable
 *         interface in this scenario. It is just implemented in the required
 *         classes to fit the project description.
 */
public interface Playable {
	/**
	 * Plays something
	 */
	public void play();

	/**
	 * A method to get the duration. Everything playable should have some duration
	 * 
	 * @return
	 */
	public int getDuration();
}