
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;



/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         This class exists as an extension of a command, of type menu, that
 *         has commands inside and displays a table with them, listening to the
 *         user input and redirecting to the appropriate commands
 */
public class Menu extends Command {
	private List<Command> commands;
	private Command returnCommand;
	private String menuTitle;

	/**
	 * Simple constructor with only the title of the menu
	 * 
	 * @param title
	 */
	public Menu(String title) {
		this(title, null, null);
	}

	/**
	 * Another more generic constructor mostly used by the class itself, that
	 * instantiates everything needed and makes sure everything works properly
	 * 
	 * @param title
	 * @param parameter
	 * @param description
	 */
	public Menu(String title, String parameter, String description) {
		super(title, parameter, description);
		this.commands = new ArrayList<Command>();
		// Instantiates the default return command to exit the menu
		this.returnCommand = new Command("return", null, "return to previous menu") {
			public void execute(Scanner scanner, String parameter, StreamingSystem system, User user) {
			}
		};
		this.returnCommand.setExactCommand(true);
		this.commands.add(returnCommand);
		this.menuTitle = title;
	}

	/**
	 * 
	 * The most complete constructor of the menu class, with all command related
	 * information + the menu title provided
	 * 
	 * @param menuTitle
	 * @param commandName
	 * @param parameter
	 * @param description
	 */
	public Menu(String menuTitle, String commandName, String parameter, String description) {
		this(commandName, parameter, description);
		this.menuTitle = menuTitle;
	}

	/**
	 * This method is executed when the menu is called. Keeps executing until the
	 * user inputs the proper exit command. Inherited from the abstract command
	 * class, adapting the menu utility
	 */
	@Override
	public void execute(Scanner scanner, String param, StreamingSystem system, User user) {
		while (true) {
			// As it is a very important loop, we catch almost every error possible from
			// called commands to make the experience of the user less frustrating if
			// something wrong happens. At least, the user still remains in the menu it
			// wants
			try {
				// If user is not given and the param is provided, it may be the user name/id.
				// Helpful in cases where it is used. However, most commands don't rely totally
				// on this information. Should still be organized
				if (param != null && user == null)
					user = system.searchUser(param, scanner);

				printHeader();

				// Does basic command listening while in the menu and treats different outcomes
				String input = scanner.nextLine();
				String sp[] = input.split(" ");
				Command command = getCommand(sp[0].trim());
				if (command == null) {
					Util.printBox("Command not found! Please try again");
					continue;
				}
				if (command == returnCommand) {
					command.execute(scanner, null, system, user);
					break;
				}

				// This line is somewhat a workaround to get all the separated words into one
				// string. In the past, we planned to add the possibility of having
				// multiparameter commands. But it turned out that it wouldn't be used. There
				// are probably better solutions to this part
				String parameter = null;
				if (sp.length > 1) {
					parameter = "";
					for (int i = 1; i < sp.length; i++)
						parameter += sp[i] + " ";
				}
				// If the command expects parameters and they aren't provided, tell the user
				if (parameter == null && command.getParameters() != null) {
					System.out.println("Error: Not enough parameters provided for this command");
					continue;
				}
				command.execute(scanner, parameter == null ? null : parameter.trim(), system, user);
			} catch (UnplayableException e) {
				System.out.println("Error: Not possible to create this recording or to play it. Try again");
			} catch (NoSuchElementException e) {
				System.out.println("Error: Problem while trying to input command");
			} catch (Exception e) {
				System.out.println("Error: Unknown exception.");
			}
		}

	}

	/**
	 * Just prints the entire menu in a table format
	 */
	private void printHeader() {
		String[][] table = new String[commands.size()][3];
		// This code fill the String table with commands information
		for (int i = 0; i < commands.size(); i++) {
			Command command = commands.get(i);
			table[i][0] = command.getTitle();
			if (command.getParameters() != null)
				table[i][1] = "<" + command.getParameters() + ">";
			else
				table[i][1] = "";
			if (command.getDescription() == null)
				table[i][2] = "";
			else
				table[i][2] = command.getDescription();
		}
		// And uses the Util method to print it
		Util.printIdentedTable(table, new String[] { "Command", "Parameters", "Description" }, menuTitle);

		// Asks for an input
		Util.printBox("Enter some command in the format <command> <parameter, if any>");
	}

	/**
	 * Gets an available command from a raw string (Either uses Levenhstein or not,
	 * depending on the command specifications). If nothing is found, returns null.
	 * 
	 * @param raw
	 * @return
	 */
	private Command getCommand(String raw) {
		List<String> names = new ArrayList<String>();
		commands.forEach((c) -> names.add(c.getTitle()));
		// Tries to find it with levenshtein
		String match = Util.closestString(names, raw, 2);
		Command found = null;
		// Tries manually through all commands, identifying if the command is allowed ot
		// use non-exact matching or not
		for (Command c : commands)
			if (c.getTitle().equals(match))
				if (raw.equals(c.getTitle()) || (match.equals(c.getTitle()) && !c.isExactCommand())) {
					found = c;
					break;
				}
		return found;
	}

	/**
	 * Used to add other commands to the menu
	 * 
	 * @param command
	 * @return
	 */
	public Menu addCommand(Command command) {
		this.commands.add(command);
		return this;
	}

	/**
	 * This command is used to customize the command used to exit from the menu
	 * 
	 * @param returnCommand
	 */
	public void setReturnCommand(Command returnCommand) {
		this.commands.remove(this.returnCommand);
		returnCommand.setExactCommand(true);
		this.returnCommand = returnCommand;
		this.commands.add(returnCommand);
	}

	/**
	 * Returns the menu title
	 * 
	 * @return
	 */
	public String getMenuTitle() {
		return menuTitle;
	}

	/**
	 * Sets the menu title
	 * 
	 * @param menuTitle
	 */
	public void setMenuTitle(String menuTitle) {
		this.menuTitle = menuTitle;
	}

}