
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;


/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         This class has the purpose of storing and managing multiple
 *         recordings (either video, audio or whatever type of recording). It
 *         has support of having id, in the case an user could have multiple
 *         playlists. It keeps track of the size (even though we could just
 *         return the array size or use it as reference), and the total
 *         duration.
 */
public class PlayList implements Playable {
	private int duration, size;
	private int id;

	private ArrayList<Recording> recordings;

	private static int IDCount;

	/**
	 * Basic constructor
	 */
	public PlayList() {
		this.recordings = new ArrayList<>();
		id = IDCount++;
	}

	/**
	 * Method to properly add a recording to the list
	 * 
	 * @param recording
	 */
	public void add(Recording recording) {
		// This will trigger if the recording is either the same or has the same name
		// and artist, to avoid duplicates insertion (See Recording class)
		if (containsDuplicate(recording))
			return;
		recordings.add(recording);
		duration += recording.getDuration();
		size++;
	}

	/**
	 * Methods to remove the recordign with name or index or the object itself
	 */

	public void remove(int index) {
		if (index >= 0 && index < recordings.size())
			remove(recordings.get(index));
	}

	public void remove(Recording recording) {
		recordings.remove(recording);
		duration -= recording.getDuration();
		size--;
	}

	public void remove(String name) {
		for (int i = 0; i < recordings.size(); i++)
			if (recordings.get(i).getName().equals(name)) {
				remove(recordings.get(i));
				return;
			}
	}

	/**
	 * Two methods to get a recording based on the index or its name. We could have
	 * only one and do similarly to what was done to the user in StreamingSystem.
	 * 
	 * There is the unlikely ambiguity problem of having a numerical only recording
	 * name and the possibility of not being able to get or remove it, as it will
	 * always be treated as an index. Could be quickly solved asking the user, in
	 * the case of an existing recorgin
	 */
	public Recording get(int index) {
		if (index >= 0 && index < recordings.size())
			return recordings.get(index);
		return null;
	}

	public Recording get(String name) {
		for (int i = 0; i < recordings.size(); i++)
			if (recordings.get(i).getName().equals(name))
				return recordings.get(i);
		return null;
	}

	/**
	 * Plays the entire playlist, with some small delay between the songs, to add
	 * depth to the action. This could organize the played songs in an idented way
	 * using the table without borders in the Util class. However, it would not be
	 * able to use the default play method of the recording
	 */
	public void play() {
		if (size == 0)
			throw new UnplayableException("Invalid size of playlist: 0");
		recordings.forEach((r) -> {
			r.play();
			try {
				TimeUnit.MILLISECONDS.sleep(50);
			} catch (InterruptedException e) {
				System.out.println("Error: Not possible to delay");
			}
		});
	}

	/**
	 * A lazy way of shuffling the playlist using the existing Java methods. The
	 * shuffling algorithm could be executed this way, if manually crafted: Iterates
	 * at least n times (n is the size of the list) swapping two different random
	 * elements in the list. This wouldn't guarantee total shuffling. However, with
	 * a higher amount of shuffling k per element, such as two or even three, we can
	 * obtain an algorithm O(kn) that shuffles more or less decently, that works for
	 * our purposes
	 * 
	 * @return
	 */
	public PlayList shuffle() {
		Collections.shuffle(recordings);
		return this;
	}

	/**
	 * Loads the playlist from a file. Returns the fully built playlist
	 * 
	 * @param name
	 * @return
	 */
	public static PlayList load(String name) {
		return load(new PlayList(), name);
	}

	/**
	 * This method could actually not require the Playlist parameter and only
	 * request the String, so the one above would not be needed anymore. Loads a
	 * playlist from a file.
	 * 
	 * @param playlist
	 * @param name
	 * @return
	 */
	private static PlayList load(PlayList playlist, String name) {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(name)));
			String buff = "";
			// While the buffer is not null, or, readLine() returns something, keeps looping
			while ((buff = br.readLine()) != null) {
				String[] s = buff.split(",");

				// Checks basic structure of a line
				if (s.length < 5) {
					System.out.println("ERROR: invalid recording format (" + buff + ")");
					continue;
				}

				Recording r = null;
				int duration = 0;
				double bfrate = 0;

				// Tries to parse numerical data
				try {
					duration = Integer.parseInt(s[3].trim());
					bfrate = Double.parseDouble(s[4].trim());
				} catch (NumberFormatException ne) {
					continue;
				}

				// Creates an appropriate recording depending on the type
				try {
					if (s[0].trim().equals("A"))
						r = new AudioRecording(s[2].trim(), s[1].trim(), duration, bfrate);
					else if (s[0].trim().equals("V"))
						r = new VideoRecording(s[2].trim(), s[1].trim(), duration, bfrate);
				} catch (UnplayableException e) {
					e.printStackTrace();
				} finally {
					if (r != null)
						playlist.add(r);
				}
			}
			br.close();
		} catch (IOException e) {
			System.out.println("ERROR: File <" + name + "> not encountered or something unexpected happened!");
		}
		return playlist;
	}

	/**
	 * Checks if a recording already exists inside the list (Uses the custom equals
	 * method in the Recording class)
	 * 
	 * @param recording
	 * @return
	 */
	public boolean containsDuplicate(Recording recording) {
		return this.recordings.contains(recording);
	}

	/**
	 * 
	 * @param name
	 */
	public void save(String name) {
		if (size == 0)
			return;
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter(new File(name)));
			// We should actually add an abstract method toCSVString to Recording, so that
			// the developer could easily add more types of recordings without having to go
			// to many classes and change it
			recordings.forEach(r -> {
				// We can also encapsulate each insertion in the "database" with a try-catch.
				// Even though we would require a more refined approach if something threw an
				// exception, as half insertion would be worse than no insertion
				try {
					bw.append(r instanceof AudioRecording ? "A" : "V").append(",");
					bw.append(r.getName()).append(",");
					bw.append(r.getArtist()).append(",");
					bw.append(r.getDuration() + "").append(",");
					bw.append((int) (r instanceof AudioRecording ? ((AudioRecording) r).getBitrate()
							: ((VideoRecording) r).getFramerate()) + "");
					bw.newLine();
				} catch (IOException e) {
					System.out.println("Error: Not possible to save " + r);
				}
			});
			bw.flush();
			bw.close();
			System.out.println("Playlist saved successfully with the name '" + name + "'!");
		} catch (IOException e) {
			System.out.println("ERROR: Not possible to save " + name);
		}
	}

	/**
	 * Merges two playlists together
	 * 
	 * @param playlist2
	 * @return
	 */
	public PlayList merge(PlayList playlist2) {
		if (playlist2.equals(this))
			return null;
		PlayList playlist1 = clone(true);
		playlist2.recordings.forEach(r -> playlist1.add(r.clone()));
		return playlist1;
	}

	/**
	 * Returns itself with played times sorted descendingly, with a default
	 * algorithm provided by Java.
	 * 
	 * @return
	 */
	public PlayList sort() {
		Collections.sort(recordings, new Comparator<Recording>() {
			@Override
			public int compare(Recording o1, Recording o2) {
				return -Integer.compare(o1.getPlayed(), o2.getPlayed());
			}
		});
		return this;
	}

	/**
	 * Clones a playlist. RetainPlays = true to not clone the recordings
	 */
	public PlayList clone(boolean retainPlays) {
		PlayList playlist = new PlayList();
		recordings.forEach(r -> playlist.add(retainPlays ? r : r.clone()));
		return playlist;
	}

	/**
	 * Default toString method adapted to print the playlist. In the past, it was
	 * supposed to print with all the recordings together. However, it is more
	 * appropriate to make a compact form in this scenario
	 */
	@Override
	public String toString() {
		return "Playlist " + Util.formatDuration(duration);
	}

	/**
	 * 
	 * @param r
	 * @return
	 */
	public int indexOf(Recording r) {
		return recordings.indexOf(r);
	}

	/**
	 * Getter methods
	 */

	public int getSize() {
		return recordings.size();
	}

	public int getId() {
		return id;
	}

	@Override
	public int getDuration() {
		return duration;
	}
}