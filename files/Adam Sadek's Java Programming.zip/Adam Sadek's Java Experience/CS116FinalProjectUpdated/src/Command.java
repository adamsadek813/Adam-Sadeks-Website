
import java.util.Scanner;


/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         This class is a fundamental command template, that is inherited by
 *         other commands
 */
public abstract class Command {
	private String title;
	private String description;
	private String parameters;
	private boolean exactCommand;

	/**
	 * Complete constructor
	 * 
	 * @param title
	 * @param parameters
	 * @param description
	 */
	public Command(String title, String parameters, String description) {
		this.title = title;
		this.setParameters(parameters);
		this.description = description;
	}

	/**
	 * An abstract method to execute the command, given the scanner, parameters, a
	 * user and the system, as a context. It would probably be easier to make a
	 * Scanner object inside the StreamingSystem class and access it from outside,
	 * so it doesn't have to be passed everywhere. The user is also only used in the
	 * user menu context. There would be no reason to have it for all commands. This
	 * method could easily be compressed into only two parameters: system (context)
	 * and parameters.
	 * 
	 * To generalize it even better, there could be an object called Context, where
	 * important parameters could be stored inside a HashMap, with key and values,
	 * including the system
	 */
	public abstract void execute(Scanner scanner, String parameters, StreamingSystem system, User user);

	/**
	 * Getters and setters
	 * 
	 */
	public boolean isExactCommand() {
		return exactCommand;
	}

	public void setExactCommand(boolean exactCommand) {
		this.exactCommand = exactCommand;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getParameters() {
		return parameters;
	}

	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

}