

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;



/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         There could be probably a way to get this class to be smaller (Making
 *         the commands more compact by re-utilizing more things), however, it
 *         would consume way too much time to optimize this non-essential
 *         characteristic. We chose to structure the program this way so that we
 *         could have an API-like extension to build the commands with menus or
 *         simple routines. More complicated routines having multi-command could
 *         also have a custom class just like Menu extends from Command. Command
 *         could also redirect other commands by, instead of being void,
 *         returning other commands. This is flexible enough to be used in other
 *         projects. Still, there are no formal OOP patterns implemented.
 * 
 *         This class is just a grouping of commands of the user menu into a
 *         class that extends from menu, to make less big the StreamSystem class
 */
public class UserMenu extends Menu {
	private String originalTitle;

	/**
	 * A simple constructor to be used in the user menu creation scenario, that
	 * builds the menu with commands
	 */
	public UserMenu() {
		super("User Menu", "user", "username or ID", "Enter in the user menu");
		originalTitle = "User Menu";
		build();
	}

	/**
	 * Method to build the menu
	 * 
	 * Consider using the eclipse function to collapse everything, so that it
	 * becomes easier to see the commands in a more organized way.
	 */
	private void build() {
		addCommand(new Command("play", "song name or ID", "Plays a recording") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				String value = parameters;
				PlayList playlist = user.getPlaylist();
				// If it is an integer, gets as the index of the recording, otherwise, try to
				// get as the name. Maybe this could have a method inside playlist to return the
				// recording already from a provided string, automatically
				Recording r = Util.isInt(value) ? playlist.get(Integer.parseInt(value)) : playlist.get(value);
				if (r == null) {
					System.out.println("Recording not found!");
					return;
				}
				r.play();
			}
		});
		addCommand(new Command("add", "song/video name", "Adds a recording") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				if (user.getPlaylist() == null)
					user.setPlaylist(new PlayList());

				System.out.println("Is the recording an audio or video? (A/V)");
				String audioOrVideo = scanner.nextLine().toLowerCase();
				if (!audioOrVideo.equals("a") && !audioOrVideo.equals("v")) {
					System.out.println("Error: Format not identified");
					return;
				}

				boolean audio = audioOrVideo.equals("a");
				System.out.println("Please provide the artist of the recording");
				String artist = scanner.nextLine();

				// Informs the user if there is already a duplicate inside the system
				if (user.getPlaylist().containsDuplicate(new VideoRecording(artist, parameters, 1, 1))) {
					System.out.println("Error: there is already a duplicate recording in the database!");
					return;
				}

				System.out.println("Now, provide the duration of the recording");
				String buffer = "";

				// Asks for a numerical duration until the user gives up or accepts
				// collaborating. It is used later again - maybe we should consider making a
				// method in Util to force the user to input a numerical value like this
				while (!Util.isInt(buffer = scanner.nextLine().trim())) {
					// Levenhstein distances of 2 or 3 were empirically tested to be considered safe
					// enough
					if (Util.levenshtein(buffer, "return") <= 2)
						return;
					System.out.println("This information is not a valid number. Try again or return");
				}

				int duration = Integer.parseInt(buffer);
				System.out.println("Finally, enter the " + (audio ? "bitrate" : "framerate"));

				while (!Util.isInt(buffer = scanner.nextLine().trim())) {
					System.out.println("This information is not a valid number. Try again or return");
					if (Util.levenshtein(buffer, "return") <= 2)
						return;
				}

				// If things are correct, creates and adds a proper recording type to the
				// playlist
				Recording recording = audio ? new AudioRecording(artist, parameters, duration, Integer.parseInt(buffer))
						: new VideoRecording(artist, parameters, duration, Integer.parseInt(buffer));
				System.out.println("Recording " + recording + " added successfully");

				// This type of interaction happens many times over the project. We could try to
				// find a more appropriate way of dealing with these trainwrecks
				user.getPlaylist().add(recording);
			}
		});
		addCommand(new Command("playall", null, "Plays entire user playlist") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				PlayList pl = user.getPlaylist();
				if (pl != null && pl.getSize() > 0)
					user.play();
				else
					System.out.println("Error: empty or non-existent playlist");
			}
		});
		addCommand(new Command("remove", "index or name", "Removes a recording") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				String value = parameters;
				PlayList playlist = user.getPlaylist();
				Recording removedRecording = Util.isInt(value) ? playlist.get(Integer.parseInt(value))
						: playlist.get(value);
				if (removedRecording == null) {
					System.out.println(
							"Error: Recording not found! Make sure spelling and capitalization is right or that the index is valid.");
					return;
				}
				playlist.remove(removedRecording);
				System.out.println("Recording: " + removedRecording + " has been removed");

			}
		});
		addCommand(new Command("shuffle", null, "Shuffles a playlist and plays it") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				PlayList pl = user.getPlaylist();
				// Crazy trainwreck to shuffle and play a cloned playlist if it is valid enough.
				// We cloned it to shuffle to conserve the original order of everything
				if (pl != null && pl.getSize() > 0) {
					user.getPlaylist().clone(true).shuffle().play();
				} else
					System.out.println("Error: empty or non-existent playlist");
			}
		});
		addCommand(new Command("stats", null, "Displays playlist statistics") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				String[][] table = new String[user.getPlaylist().getSize()][3];
				// Again, we cloned it before changing its order, as it is just for display
				PlayList sorted = user.getPlaylist().clone(true).sort();
				if (sorted.getSize() <= 0) {
					System.out.println("Error: Playlist still empty!");
					return;
				}
				// We build our table and display it with an existing function in Util
				for (int i = 0; i < sorted.getSize(); i++) {
					Recording r = sorted.get(i);
					table[i] = system.isShowIndex()
							? new String[] { user.getPlaylist().indexOf(r) + "", r.getName(), r.getArtist(),
									r.getPlayed() + "" }
							: new String[] { r.getName(), r.getArtist(), r.getPlayed() + "" };
				}
				Util.printIdentedTable(table,
						system.isShowIndex() ? new String[] { "Index", "Song", "Artist", "Times played" }
								: new String[] { "Song", "Artist", "Times played" },
						sorted + " statistics");
			}
		});
		addCommand(new Command("import", "user or file name", "Imports playlist") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				PlayList pl = user.getPlaylist();
				boolean merge = false;
				if (pl != null && pl.getSize() > 0) {
					System.out.println(
							"This user already has a playlist assigned to it. Do you want to merge the new one to it? (yes/no) (The option \"no\" will override everything)");
					if (Util.yes(scanner))
						merge = true;
				}
				PlayList playlist = user.getPlaylist();
				PlayList playlist2 = null;

				String value = parameters;

				while (true) {
					// Tries to find a file with that string input
					try {
						if (new File(value).exists())
							playlist2 = PlayList.load(value);

						if (playlist2 == null && new File(value + ".csv").exists())
							playlist2 = PlayList.load(value + ".csv");

						User found = system.searchUser(value, scanner);

						if (found != null && found.equals(user)) {
							System.out.println(
									"The user can't be the same. Input another name or ID or valid file or return.");
							value = scanner.nextLine();
							if (Util.levenshtein("return", value) <= 2)
								return;
							continue;
						}

						if (playlist2 == null) {
							if (found == null) {
								System.out.println("Nothing was found. Searching possibilities...");
								ArrayList<String> options = Util.retrieveFilesWithExtension(".csv", system.getDepth());
								// We could check if they are in the correct format we want to import. but that
								// would be way too much work. We can stick with only csv extension that it will
								// be no problem I think
								if (options.size() != 0)
									System.out.println("Here are some file suggestions found nearby:");
								// We have to filter the options that have the format we want later
								options.forEach(System.out::println);
								ArrayList<String> bestMatches = Util.closestStrings(system.userSummary(), value, 3);
								// Filter matches
								bestMatches.remove(user.getName());
								if (bestMatches.size() > 0)
									System.out.println("Here are users with similar name:");
								// And look only for users that have non-blank playlists
								bestMatches.forEach(System.out::println);
								if (options.size() > 0 || bestMatches.size() > 0) {
									System.out.println("Choose one of them or input a valid file or user or return");
									value = scanner.nextLine();
									if (Util.levenshtein("return", value) <= 2)
										return;
									continue;
								} else {
									System.out.println("No valid suggestion was found! Try again");
									return;
								}
							} else
								playlist2 = found.getPlaylist().clone(false);
						} else if (found != null) {
							System.out.println(
									"Looks like there is a user with the same name as a file that exists in the directory. Do you want to import from the user? (yes/no)");
							playlist2 = Util.yes(scanner) ? found.getPlaylist().clone(false) : playlist2;
						}

						if (playlist2 != null) {
							if (merge) {
								user.setPlaylist(playlist.merge(playlist2));
								System.out.println("Merged successfully "
										+ (user.getPlaylist().getSize() - playlist.getSize()) + " recordings");
							} else {
								user.setPlaylist(playlist2);
								System.out.println(
										"Imported successfully " + user.getPlaylist().getSize() + " recordings");
							}
							return;
						}
					} catch (Exception e) {
						System.out.println("Error: try again");
						e.printStackTrace();
					}
				}
			}
		});
		addCommand(new Command("save", null, "Saves user playlist") {
			public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
				PlayList pl = user.getPlaylist();
				// Saves the playlist with the appropriate format (we were not sure if the word
				// PLAYLIST should be included). We should consider adding utility methods
				// inside Playlist, such as isValid, to perform this exact validation + others
				if (pl != null && pl.getSize() > 0)
					pl.save(user.getName() + "_PLAYLIST_"
							+ new SimpleDateFormat("MM_dd_YYYY_HH_mm_ss").format(new Date()) + ".csv");
				else
					System.out.println("Error: empty or non-existent playlist");
			}
		});
	}

	/**
	 * This execute method inherited from Command is customized to ensure that the
	 * user exists and can be used by all its commands. If no user is ever provided,
	 * the menu is not executed
	 */
	@Override
	public void execute(Scanner scanner, String params, StreamingSystem system, User user) {
		user = system.searchUser(params, scanner);
		if (user != null) {
			super.setMenuTitle(originalTitle + " - " + user.getName() + "[" + user.getId() + "]");
			super.execute(scanner, params, system, user);
		} else
			System.out.println("Error: username not found!");
	}
}