

/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         A recording of the type Audio. has an additional bit rate parameter
 */
public class AudioRecording extends Recording {
	private double bitrate;

	/**
	 * Complete constructor, that checks the bit rate value and throws unplayable
	 * exception if invalid
	 * 
	 * @param artist
	 * @param name
	 * @param duration
	 * @param bitrate
	 */
	public AudioRecording(String artist, String name, int duration, double bitrate) {
		super(artist, name, duration);
		if (Double.isNaN(bitrate) || Double.isInfinite(bitrate) || bitrate <= 0)
			throw new UnplayableException("Bitrate is invalid: " + bitrate);
		this.bitrate = bitrate;
	}

	/**
	 * Overridden string representation of the audio recording, that still uses its
	 * parent method
	 */
	@Override
	public String toString() {
		return super.toString() + " [AUDIO | bitrate: " + bitrate + " kbps]";
	}

	/**
	 * Overridden cloning method
	 */
	@Override
	public Recording clone() {
		return new AudioRecording(getArtist(), getName(), getDuration(), bitrate);
	}

	public double getBitrate() {
		return bitrate;
	}

}