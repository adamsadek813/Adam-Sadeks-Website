
import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         This is an utility class with many purposes widely used in the entire
 *         project to avoid repeated repetition
 */
final public class Util {
	/**
	 * Makes the provided duration in seconds be properly formatted into a string
	 * (the challenge here was doing it in one line)
	 * 
	 * @param duration
	 * @return
	 */
	public static String formatDuration(int d) {
		return "[" + (d / 3600 >= 1 ? (d / 3600) + "h" : "") + ((d % 3600) / 60 >= 1 ? ((d % 3600) / 60) + "m" : "")
				+ (d % 60) + "s]";
	}

	/**
	 * 
	 * Checks if a string is an integer to avoid using an exception for that (not
	 * sure which one is faster, there was no benchmarking)
	 * 
	 * Used https://regexr.com to build the regex pattern
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isInt(String str) {
		return str.matches("-?\\d+");
	}

	/**
	 * Uses levenshtein distance to get the return the closest string in a list,
	 * compared to a provided string, within a tolerance
	 * 
	 * 
	 * @param strings
	 * @param compared
	 * @param tolerance
	 * @return
	 */
	public static String closestString(List<String> strings, String c, int tol) {
		int min = 999999, index = -1;
		for (String a : strings) {
			int l = levenshtein(a, c);
			if (l < min && l <= tol) {
				min = l;
				index = strings.indexOf(a);
			}
		}
		return index == -1 ? null : strings.get(index);
	}

	/**
	 * The basic levenshtein distance implementation to find the distance between
	 * two words https://en.wikipedia.org/wiki/Levenshtein_distance
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static int levenshtein(String a, String b) {
		String str = a.toLowerCase();
		String s = b.toLowerCase();
		int[][] dis = new int[str.length() + 1][s.length() + 1];
		for (int i = 0; i <= str.length(); i++)
			for (int j = 0; j <= s.length(); j++)
				dis[i][j] = i == 0 ? j
						: (j == 0 ? i
								: (min(dis[i - 1][j - 1] + (str.charAt(i - 1) == s.charAt(j - 1) ? 0 : 1),
										dis[i - 1][j] + 1, dis[i][j - 1] + 1)));
		return dis[str.length()][s.length()];
	}

	/**
	 * Same thing as closestString method, but returns an array with strings within
	 * a certain distance tolerance compared to the provided string
	 * 
	 * @param strings
	 * @param compared
	 * @param tollerance
	 * @return
	 */
	public static ArrayList<String> closestStrings(List<String> strings, String c, int tol) {
		ArrayList<String> results = new ArrayList<String>();
		for (String a : strings) {
			int l = levenshtein(c, a);
			if (l <= tol)
				results.add(a);
		}
		return results;
	}

	/**
	 * Returns the minimum number
	 * 
	 * Using another implementation such as converting the array into a stream and
	 * then a lambda expression to achieve the min number could be another option,
	 * maybe even faster and in one line
	 * 
	 * @param numbers
	 * @return
	 */
	public static int min(int... numbers) {
		int min = Integer.MAX_VALUE;
		for (int i : numbers)
			min = i < min ? i : min;
		return min;
	}

	/**
	 * Trainwreck to get the path where the source code/compiled executed files sit
	 * 
	 * @return
	 */
	public static String getRootPath() {
		try {
			return new File(Util.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getPath();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * A method to open a web page
	 * 
	 * @param page
	 */
	public static void openPage(String page) {
		try {
			Desktop.getDesktop().browse(new URI(page));
		} catch (IOException | URISyntaxException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method returns a list of all file names with paths, that contain a
	 * certain extension, within a certain depth of search. Depth of 1 means that it
	 * will go to the parent folder of the current executable/compiled and start
	 * going into its branches searching for files
	 * 
	 * @param extension
	 * @param depth
	 * @return
	 */
	public static ArrayList<String> retrieveFilesWithExtension(String ext, int depth) {
		File root = new File(getRootPath());
		for (int i = 0; i < depth; i++)
			if (root.getParentFile() != null)
				root = root.getParentFile();
		return retrieveAll(root, ext);
	}

	/**
	 * A recursive approach to retrieve all files with a certain extension from a
	 * folder and subfolders
	 * 
	 * @param file
	 * @param exttension
	 * @return
	 */
	private static ArrayList<String> retrieveAll(File f, String ext) {
		ArrayList<String> files = new ArrayList<String>();
		if (f == null)
			return files;
		if (f.getName().contains(ext) && !f.isDirectory()) {
			files.add(f.getAbsolutePath());
		} else if (f.isDirectory() && f.canRead())
			if (f.listFiles() != null)
				for (File child : f.listFiles())
					files.addAll(retrieveAll(child, ext));
		return files;
	}

	/**
	 * A terrible way of doing this (for the table). In fact, this is one of the
	 * ways to break the code if you want: inputting more than around 460 characters
	 * in the user name will make it impossible to display either the user menu and
	 * the user list. A quick fix to that would be to limit the amount of chars a
	 * username can possibly have
	 */
	private static final String blank = "                                                                                                                                                                                                                               ";

	/**
	 * Prints a boxed text
	 * 
	 * @param text
	 */
	public static void printBox(String text) {
		printIdentedTable(null, text);
	}

	/**
	 * Three methods to print tables (only title and table/same but with columns
	 * description/same but with optional border)
	 */
	public static void printIdentedTable(String[][] table, String title) {
		printIdentedTable(table, null, title);
	}

	public static void printIdentedTable(String[][] table, String[] columns, String title) {
		printIdentedTable(table, columns, title, true);
	}

	/**
	 * This just works. Took some couple hours to get it fully working the most
	 * generic way possible, with word parity included. The output will be a table
	 * from given information. This could have surely been optimized to take less
	 * space and reutilize methods
	 * 
	 * @param table
	 * @param columns
	 * @param title
	 * @param border
	 */
	public static void printIdentedTable(String[][] table, String[] columns, String title, boolean border) {
		// Returns if invalid format is provided
		if (columns != null && table != null && table[0].length != columns.length)
			return;

		// Calculates important table metrics
		int[] maxLength = { title.length() };
		if (table != null) {
			maxLength = new int[table[0].length];
			for (int i = 0; i < maxLength.length; i++) {
				int max = 0;
				for (String[] s : table)
					max = s[i].length() > max ? s[i].length() : max;
				if (columns != null)
					max = columns[i].length() > max ? columns[i].length() : max;
				maxLength[i] = max;
			}
		}

		StringBuilder sb = new StringBuilder();

		int max = 0;
		for (int m : maxLength)
			max += m;

		if (title.length() > max)
			maxLength[0] += title.length() % max;

		max = (title.length()) > max ? (title.length()) : max;

		int totalSpacing = max + 2 * maxLength.length;
		int remainder = totalSpacing % 2 - title.length() % 2;

		// Draws the header with title
		if (border) {
			sb.append(" ");
			for (int i = 0; i < max + 2 * maxLength.length; i++)
				sb.append("_");
			sb.append("\n|");
			for (int i = 0; i < max + 2 * maxLength.length; i++)
				sb.append(" ");
			sb.append("|\n");
			sb.append("|" + blank.substring(0, totalSpacing / 2 - title.length() / 2 + remainder) + title
					+ blank.substring(0, totalSpacing / 2 - title.length() / 2) + "|\n");
			sb.append("|");
		} else
			sb.append(blank.substring(0, totalSpacing / 2 - title.length() / 2 + remainder) + title
					+ blank.substring(0, totalSpacing / 2 - title.length() / 2) + "\n");

		if (border) {
			for (int i = 0; i < max + 2 * maxLength.length; i++)
				sb.append("_");
			sb.append("|\n");
		}

		// Draws the column names if they exist
		if (columns != null && columns.length == table[0].length) {
			if (border)
				sb.append("|");
			for (int i = 0; i < columns.length; i++)
				sb.append(columns[i] + blank.substring(0, maxLength[i] - columns[i].length() + 2));
			if (border) {
				sb.append("|\n|");
				for (int i = 0; i < max + 2 * maxLength.length; i++)
					sb.append("_");
				sb.append("|\n");
			} else
				sb.append("\n");
		}

		// Draws the table contents if it exists
		if (table != null) {
			for (String s[] : table) {
				if (border)
					sb.append("|");
				for (int i = 0; i < maxLength.length; i++)
					sb.append(s[i] + blank.substring(0, maxLength[i] - s[i].length() + 2));
				if (border)
					sb.append("|\n");
				else
					sb.append("\n");
			}
			if (border) {
				sb.append("|");
				for (int i = 0; i < max + 2 * maxLength.length; i++)
					sb.append("_");
				sb.append("|");
			}
		}
		// Prints the completed table
		System.out.println(sb.toString());
	}

	/**
	 * If someone writes something close to a yes, returns true, if not, false
	 * 
	 * @param scanner
	 * @return
	 */
	public static boolean yes(Scanner s) {
		return levenshtein("yes", s.nextLine().trim().toLowerCase()) <= 1;
	}
}