
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;



/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         The core class of the project, that contains functions for user
 *         search, general configurations and most importantly, the main menu
 *         and the user database.
 */
public class StreamingSystem {

	private ArrayList<User> users;
	private boolean levenshtein;
	private int depth = 1;
	private boolean showIndex;

	/**
	 * A basic constructor to initialize the database
	 */
	public StreamingSystem() {
		users = new ArrayList<>();
	}

	/**
	 * A method to run the system
	 */
	public void run() {
		// If every single error catching fails, there is still this one that will keep
		// the system alive
		while (true) {
			try {
				// It is a preference to use the same scanner everywhere in the system. Only
				// restarted if an "uncatched" exception is thrown
				Scanner s = new Scanner(System.in);

				// Consider using the collapsing functions of Eclipse to visualize the commands
				// better

				// Note that these information could be added to another class similar to
				// UserMenu, called MainMenu. But it was simpler to let them exist here in this
				// method

				// Some routines here are self-explanatory and may not have comments if not
				// needed
				Menu mainMenu = new Menu("Welcome to Adam and Gabriel's Playlist Main Menu");
				Menu userMenu = new UserMenu();

				mainMenu.addCommand(userMenu);
				mainMenu.addCommand(new Command("add", "username", "Adds a new user") {
					public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
						String name = parameters;
						// Checks for every kind of validation in the user name except size. See
						// printIdentedTable in Util
						if (Util.isInt(name)) {
							System.out.println("Error: Username cannot contain only numbers");
							return;
						}
						String letterPallete = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_&%$#@1234567890 ";
						for (char c : name.toCharArray())
							if (letterPallete.indexOf(c) == -1) {
								System.out.println("Error: Username cannot contain the charactere '" + c + "'");
								return;
							}

						// If everything is correct, adds the user to the database
						User u = new User(name);
						users.add(u);
						System.out.println("User " + name + " with ID " + u.getId() + " added to the database!");
					}
				});
				mainMenu.addCommand(new Command("remove", "username or ID", "Removes a user") {
					public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
						String value = parameters;
						User u = searchUser(value, scanner);

						if (u == null) {
							System.out.println("User not found!");
							return;
						}

						// Asks the user for removal confirmation
						System.out.println("Are you sure you want to remove the user " + u.getName() + " with ID "
								+ u.getId() + "? (yes/no)");

						// And waits for a response
						if (Util.yes(s)) {
							users.remove(u);
							System.out.println("User " + u.getName() + " removed from database.");
						} else
							System.out.println("Operation cancelled by the user");
					}
				});
				mainMenu.addCommand(new Command("list", null, "Lists all users in the database") {
					public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
						system.printTableFromUsers(system.users);
					}
				});

				// Builds the settings menu
				Menu settings = new Menu("Settings", "settings", null, "Go to settings menu");

				settings.addCommand(
						new Command("levenshtein", null, "Toggles search algorithm with basic Levenshtein") {
							public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
								system.levenshtein = !system.levenshtein;
								System.out.println("Levenshtein: " + system.levenshtein);
							}
						});
				settings.addCommand(new Command("depth", "number", "File depth search (default = 1)") {
					public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
						if (Util.isInt(parameters) && Integer.parseInt(parameters) > 0)
							system.depth = Integer.parseInt(parameters);
						else
							System.out.println("Error: invalid parameter");
						// Warns the user about performance issues
						System.out.println("A bigger depth may impact a lot in the performance. Be aware of this");
					}
				});
				settings.addCommand(new Command("surprise", null, "A surprise for the user") {
					public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
						Util.openPage("https://www.youtube.com/watch?v=xvFZjo5PgG0");
						System.out.println("You were Rickrolled!");
					}
				});

				// There could be a generic settings command class that uses Java Reflection to
				// toggle or set variables in the system class within certain bounds, in a more
				// flexible and easy way
				settings.addCommand(new Command("index", null, "Toggles appearance of index in playlist stats") {
					public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
						system.showIndex = !system.showIndex;
						System.out.println("Index: " + system.showIndex);
					}
				});

				mainMenu.addCommand(settings);

				mainMenu.setReturnCommand(new Command("exit", null, "Exits from program") {
					public void execute(Scanner scanner, String parameters, StreamingSystem system, User user) {
						System.exit(0);
					}
				});

				// After building the command/menu tree, executes the main menu
				mainMenu.execute(s, null, this, null);

				s.close();
			} catch (Exception e) {
				System.out.println("Error: Uknown error");
				e.printStackTrace();
			}
		}
	}

	/**
	 * A method used multiple times to print an arraylist of users
	 * 
	 * @param users
	 */
	protected void printTableFromUsers(ArrayList<User> users) {
		if (users.size() == 0) {
			System.out.println("Error: user list empty");
			return;
		}
		String table[][] = new String[users.size()][2];
		int i = 0;
		for (User u : users)
			table[i++] = new String[] { u.getName(), u.getId() + "" };
		Util.printIdentedTable(table, new String[] { "Username", "ID" }, "User List");
	}

	/**
	 * Standard routine to find a user inside a database, with the id or the name in
	 * the same parameter. Notice that no user will be allowed to have numerical
	 * only name, so there would be no confusion between the two parameters. Also,
	 * if there are more than one user with the same name, it prints a user table
	 * and asks the user to input the wanted id. If nothing was found, return null.
	 * Levenshtein is also used if enabled. We also thought of giving the option to
	 * perform a quick search if nothing was found, using Levenshtein.
	 * 
	 * @param key
	 * @param scanner
	 * @return
	 */
	public User searchUser(String key, Scanner s) {
		// Checks if it is entirely numerical and try to find a user that has the id
		// matching the key
		if (Util.isInt(key)) {
			int id = Integer.parseInt(key);
			for (User u : users)
				if (u.getId() == id)
					return u;
		} else {
			// Counts the frequency of users with the sake name in the platform
			int freq = 0;
			for (User user2 : users)
				if (user2.getName().equals(key))
					freq++;
			// If more than one, displays the table and ask for the id
			if (freq > 1) {
				String v = key;
				printTableFromUsers((ArrayList<User>) users.stream().filter(us -> us.getName().equals(v))
						.collect(Collectors.toList()));
				System.out.println("More than one user found with the same name. Please choose one by ID");
				key = s.nextLine();
				if (!Util.isInt(key))
					return null;
				return searchUser(key, s);
			}

			// Use levenshtein if enabled
			if (levenshtein)
				key = Util.closestString(userSummary(), key, 2);
			// Or just match the name
			for (User u : users)
				if (u.getName().equals(key))
					return u;
		}
		return null;
	}

	/**
	 * Usually used for levenshtein search in the project. Returns a list with all
	 * names of users
	 * 
	 * @return
	 */
	public ArrayList<String> userSummary() {
		ArrayList<String> names = new ArrayList<String>();
		users.forEach(u -> names.add(u.getName()));
		return names;
	}

	/**
	 * Getters
	 */
	public int getDepth() {
		return depth;
	}

	public boolean isShowIndex() {
		return showIndex;
	}

}