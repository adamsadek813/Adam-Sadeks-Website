

/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         Abstract recording class that implements Playable. Should be extended
 *         by other recording-type classes. Generically used in PlayList class.
 *         Contains all the required information for a recording to be valid
 */
public abstract class Recording implements Playable {
	/**
	 * Whether being protected or not is discussable
	 */
	private String artist, name;
	private int duration;
	private int played;

	/**
	 * Basic constructor for a recording
	 */
	public Recording() {
		this(null, null, 0);
	}

	/**
	 * Complete constructor for a recording, that throws UnplayableException if an
	 * invalid duration is given
	 * 
	 * @param artist
	 * @param name
	 * @param duration
	 */
	public Recording(String artist, String name, int duration) {
		this.artist = artist == null ? "Unknown" : artist;
		this.name = name == null ? "Unknown" : name;
		if (duration <= 0)
			throw new UnplayableException("Duration " + duration + " invalid!");
		this.duration = duration;
	}

	/**
	 * Checks if a recording is equal to another, using the equality criteria of
	 * artist and name
	 */
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Recording))
			return false;
		Recording r = (Recording) o;
		return r.getArtist().equals(artist) && r.getName().equals(name);
	}

	/**
	 * Plays the recording with the string representing it
	 */
	public void play() {
		System.out.println("Now playing: " + this);
		played++;
	}

	/**
	 * Returns a string representation of the recording. Is usually overridden by a
	 * child class
	 */
	@Override
	public String toString() {
		return artist + " - " + name + " " + Util.formatDuration(duration);
	}

	/**
	 * An abstract method to clone the recording
	 * @param retainPlays 
	 */
	public abstract Recording clone();

	/**
	 * Getters
	 */
	public String getArtist() {
		return artist;
	}

	public String getName() {
		return name;
	}

	public int getDuration() {
		return duration;
	}

	public int getPlayed() {
		return played;
	}

}