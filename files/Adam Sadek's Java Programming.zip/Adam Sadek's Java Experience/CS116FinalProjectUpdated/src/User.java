

/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         This class is essentially used to store user information, such its
 *         id, name and playlist. Supports ID auto-increment.
 */
public class User implements Playable {
	private String name;
	private int id;
	private PlayList playlist;

	private static int IDCount;

	/**
	 * Fundamental constructor
	 */
	public User() {
		this.setPlaylist(new PlayList());
		id = IDCount++;
	}

	/**
	 * Constructor with the name input
	 * 
	 * @param name
	 */
	public User(String name) {
		this();
		this.name = name;
	}

	/**
	 * This method is never used anywhere. But serves to shuffle the playlist from
	 * the user.
	 */
	public void shuffle() {
		if (playlist != null)
			playlist.shuffle();
	}

	/**
	 * Basic string representation of the user
	 */
	@Override
	public String toString() {
		return name + " ID " + id;
	}

	/**
	 * This is never used, but can be used to directly play all the musics in the
	 * playlist
	 */
	@Override
	public void play() {
		if (playlist != null)
			playlist.play();
	}

	/**
	 * Getters and setters
	 */
	@Override
	public int getDuration() {
		return playlist.getDuration();
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	public PlayList getPlaylist() {
		return playlist;
	}

	public void setPlaylist(PlayList playlist) {
		this.playlist = playlist;
	}

}