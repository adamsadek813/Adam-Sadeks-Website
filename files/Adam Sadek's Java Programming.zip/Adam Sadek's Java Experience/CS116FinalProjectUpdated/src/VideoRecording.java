

/**
 * 
 * @author Gabriel Roskowski
 * @author Adam Sadek
 * 
 *         A recording of the type video. has an additional frame rate parameter
 */
public class VideoRecording extends Recording {

	private double framerate;

	/**
	 * Complete constructor, that checks the frame rate value and throws unplayable
	 * exception if invalid
	 * 
	 * @param artist
	 * @param name
	 * @param duration
	 * @param framerate
	 */
	public VideoRecording(String artist, String name, int duration, double framerate) {
		super(artist, name, duration);
		if (Double.isNaN(framerate) || Double.isInfinite(framerate) || framerate <= 0)
			throw new UnplayableException("Framerate is invalid: " + framerate);
		this.framerate = framerate;
	}

	/**
	 * Overridden string representation of the video recording, that still uses its
	 * parent method
	 */
	@Override
	public String toString() {
		return super.toString() + " [VIDEO | framerate: " + framerate + " fps]";
	}

	/**
	 * Overridden cloning method
	 */
	@Override
	public Recording clone() {
		return new VideoRecording(getArtist(), getName(), getDuration(), framerate);
	}

	public double getFramerate() {
		return framerate;
	}
}