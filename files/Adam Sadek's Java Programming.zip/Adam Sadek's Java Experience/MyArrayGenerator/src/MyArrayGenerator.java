

import java.util.Random;

public class MyArrayGenerator {
	private int[] array;
	private int numberOfElements;

	public MyArrayGenerator() {
		Random r = new Random();
		numberOfElements = r.nextInt(16);
		array = new int[numberOfElements];
		fill(r);
	}

	private void fill(Random r) {
		for (int i = 0; i < array.length; i++)
			array[i] = r.nextInt(10);
	}

	public int getArrSize() {
		return numberOfElements;
	}

	public int[] getArr() {
		return array;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i : array)
			sb.append(i + "  ");
		return sb.toString();
	}

}
