

public class WhatIsInCommon {
	public static void main(String[] args) {
		// Instantiate random array generator
		MyArrayGenerator arrA = new MyArrayGenerator();
		MyArrayGenerator arrB = new MyArrayGenerator();

		// Prints both arrays
		System.out.println("Array A: " + arrA);
		System.out.println("Array B: " + arrB);

		// Makes arrays to store the number of numbers found in an array in each index
		// of it and iterate through the arrays to count the amount of each number
		// contained in the array
		int[] iA = new int[11], iB = new int[11];
		for (int i = 0; i < arrA.getArrSize(); i++)
			iA[arrA.getArr()[i]]++;
		for (int i = 0; i < arrB.getArrSize(); i++)
			iB[arrB.getArr()[i]]++;

		// Count how many duplicates are there between the two arrays (if the same index
		// in both arrays is not zero, it increments the duplication count)
		int dup = 0;
		for (int i = 0; i < iA.length; i++)
			if (iA[i] != 0 && iB[i] != 0)
				dup++;

		// If there are duplicates, run through the auxiliary array to print the amount
		// of numbers in each array for each different number from 0 to 10
		if (dup != 0) {
			System.out.println("Element:\t# in A:\t\t# in B:");
			for (int i = 0; i < iA.length; i++)
				if (iA[i] != 0 && iB[i] != 0)
					System.out.println(i + "\t\t" + iA[i] + "\t\t" + iB[i]);
		}

		// Finally, print the amount of duplicates in both arrays
		System.out.println("Number of elements that are both in both A and B: " + dup);
	}

}
