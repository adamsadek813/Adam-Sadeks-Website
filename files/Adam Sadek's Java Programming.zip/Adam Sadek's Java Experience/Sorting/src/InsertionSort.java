import java.util.Arrays;
public class InsertionSort {
	
	//this is the left to right, cards in hand method
	public static void main(String[] args) {

	int j, temp;
	int [] array = {2,1,9,6,7};
	
	for ( int i = 1; i < array.length; i++ ){
	j = i;
	temp = array[i];
	while ( j != 0 && array[j - 1] > temp ){
	array[j] = array[j - 1];
	j--;
	}
	array[j] = temp;
	}
	
	System.out.println(Arrays.toString(array));
}
}