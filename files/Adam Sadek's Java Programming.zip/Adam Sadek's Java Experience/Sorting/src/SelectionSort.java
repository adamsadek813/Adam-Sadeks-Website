
public class SelectionSort {
	public static void main(String[] args) {
		
		//swapping highest element to leftmost available spot
		int [] array = new int[8];
	int temp; //temporary location for swap
	int max=0; //index of max value in subarray
	for ( int i = 0; i < array.length - 1; i++ ) {
		//max = indexOfLargestElement(array,
//		array.length - i);
		for (int j = 0; j < array.length-i; j++) {
			if (max < array[j]) {
				max = j;
			}
		}
	// swap array[max] and
	// array[array.length - i - 1]
	temp = array[max];
	array[max] = array[array.length - i - 1];
	array[array.length - i - 1] = temp;
	}
	}
}
