
public class BinarySearch {
	
	public int binarySearch( int [] array, int key )
	{
	int start = 0, end = array.length - 1;
	while ( end >= start )
	{
	int middle = ( start + end ) / 2;
	if ( array[middle] == key )
	return middle; // key found
	else if ( array[middle] > key )
	end = middle - 1; // search left
	else
	start = middle + 1; // search right
	}
	return -1; // key not found
	}
}
