
public class Animal implements SoundInterface, MovementInterface {

	@Override
	public void makeSound() {
		System.out.println("I am an Animal. I make sounds");
	}

	public void memberOf() {
		System.out.println("I am a member of the Animal Kingdom");
	}
	
}
