
public class Car extends Vehicle {
	@Override
	public void makeSound() {
		System.out.println("I am a Car. I honk");
	}

	@Override
	public void move() {
		System.out.println("I am a Car. I drive");
	}
}
