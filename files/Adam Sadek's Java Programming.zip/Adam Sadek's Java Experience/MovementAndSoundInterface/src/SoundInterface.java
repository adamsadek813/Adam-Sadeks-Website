
public interface SoundInterface {
	public void makeSound();
}
