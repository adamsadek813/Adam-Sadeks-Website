
public class Vehicle implements SoundInterface, MovementInterface {

	public void memberOf() {
		System.out.println("I am a member of the Vehicle class");
	}

	@Override
	public void makeSound() {
		System.out.println("I am Vehicle. I make sounds");
	}
}
