import java.util.Scanner;
public class ZoningApp {
	public static void main(String[] args) {

		//testing zones 1 through 5
	Zoning lot1 = new Zoning(50,40);
	Zoning lot2 = new Zoning(50,45);
	Zoning lot3 = new Zoning(50,60);
	Zoning lot4 = new Zoning(50,80);
	Zoning lot5 = new Zoning(55,100);
	
	lot1.heightLimit();
	lot1.unitCountLimit();
	System.out.println(lot1.toString());
	
	lot2.heightLimit();
	lot2.unitCountLimit();
	System.out.println(lot2.toString());
	
	lot3.heightLimit();
	lot3.unitCountLimit();
	System.out.println(lot3.toString());
	
	lot4.heightLimit();
	lot4.unitCountLimit();
	System.out.println(lot4.toString());
	
	lot5.heightLimit();
	lot5.unitCountLimit();
	System.out.println(lot5.toString());

	//testing user input
	while(true) {
	System.out.println("What is the length of your lot in feet?");
	Scanner myScanner = new Scanner(System.in);
	double userInputtedLength = myScanner.nextDouble();
	System.out.println("What is the width of your lot in feet?");
	double userInputtedWidth = myScanner.nextDouble();
	Zoning newLot = new Zoning (userInputtedLength, userInputtedWidth);
	newLot.heightLimit();
	newLot.unitCountLimit();
	System.out.println(newLot.toString());
	}
	
	}
}
