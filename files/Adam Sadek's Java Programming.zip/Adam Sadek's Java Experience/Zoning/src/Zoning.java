import java.text.DecimalFormat;

public class Zoning {
private double lotLength;
private double lotWidth;
private double lotArea;
private double heightLimit;
private int unitCountLimit;

final private int lotArea1Max = 2000;
final private int lotArea2Max = 2500;
final private int lotArea3Max = 3500;
final private int lotArea4Max = 5000;

final private double heightLimit1 = 25;
final private double heightLimit2 = 25;
final private double heightLimit3 = 35;
final private double heightLimit4 = 45 ;
final private double heightLimit5 = 52.5;

final private double lotAreaPercentage2 = 0.02;
final private double lotAreaPercentage3 = 0.01;
final private double lotAreaPercentage4 = 0.005;
final private double lotAreaPercentage5 = 0.0025;

 Zoning(){
lotLength = 0;
lotWidth = 0;
}

 Zoning(double LotLength, double LotWidth) {
	setLotLength(LotLength);
	setLotWidth(LotWidth);
}

public double getLotLength() {
	return lotLength;
}

public double getLotWidth() {
	return lotWidth;
}

public void setLotLength(double lotLength) {
	if (lotLength < 0) {
		lotLength = 0;
	}
	else {
	this.lotLength = lotLength;
	}
}

public void setLotWidth(double lotWidth) {
	if (lotWidth < 0) {
		lotWidth = 0;
	}
	else {
	this.lotWidth = lotWidth;
	}
}

public int unitCountLimit() {
	lotArea = lotLength*lotWidth;
	if(lotArea <= lotArea1Max) {
		unitCountLimit = 1;
	}
	else{
		if  (lotArea <= lotArea2Max) {
			unitCountLimit = 2;
	}
		else{
			if (lotArea <= lotArea3Max) {
				unitCountLimit = 2;

		}
			else{
				if (lotArea <= lotArea4Max) {
					unitCountLimit = 3;

				}
				else{
					if (lotArea > lotArea4Max) {
						unitCountLimit = 4;

					}
				}
			}
		}	
	}
	return unitCountLimit;
}


public double heightLimit() {
	lotArea = lotLength*lotWidth;
	if(lotArea <= lotArea1Max) {
		heightLimit = heightLimit1;
	}
	else{
		if  (lotArea <= lotArea2Max) {
			heightLimit = heightLimit2 + ((lotAreaPercentage2*lotArea)/2000);
	}
		else{
			if (lotArea <= lotArea3Max) {
				heightLimit = heightLimit3 + ((lotAreaPercentage3*lotArea)/2500);

		}
			else{
				if (lotArea <= lotArea4Max) {
					heightLimit = heightLimit4 + ((lotAreaPercentage4*lotArea)/3500);

				}
				else{
					if (lotArea > lotArea4Max) {
						heightLimit = heightLimit5 + ((lotAreaPercentage5*lotArea)/5000);

					}
				}
			}
		}	
	}
	DecimalFormat df = new DecimalFormat("#.##");
	heightLimit = Double.valueOf(df.format(heightLimit));
		return heightLimit;
	}

@Override
public String toString() {
	return "lotArea=" + lotArea + ", heightLimit=" + heightLimit + ", unitCountLimit=" + unitCountLimit;
}



}
