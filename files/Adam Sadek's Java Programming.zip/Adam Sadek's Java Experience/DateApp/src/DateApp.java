import java.util.Scanner;
public class DateApp {
public static void main (String args[]) {
	
	Scanner scan = new Scanner (System.in);
	System.out.println("Enter your birthday in mm/dd/yyyy format >");
	String birthday = scan.next();
	
	String month = birthday.substring(0, 2);
	String day = birthday.substring(3, 5);
	String year = birthday.substring(6, 10);

	int m = Integer.parseInt(month);
	int d = Integer.parseInt(day);
	int y = Integer.parseInt(year);
	Date date1 = new Date(m, d, y);
	
	
	Date date2 = new Date(8, 13, 2002);
	System.out.println(date1);
	System.out.println("Your birthday is the same as the programmer: " + date1.equals(date2) );
	
	}
}
