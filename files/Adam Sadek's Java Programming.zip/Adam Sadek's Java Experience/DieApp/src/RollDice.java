public class RollDice {
	public static void main (String args[]) {
SixSidedDie A = new SixSidedDie();
TwelveSidedDie B = new TwelveSidedDie();

int sumAB = 0;
System.out.println("Game 1");
for (int x = 0; x < 10; x++) {
	A.roll();
	B.roll();
	System.out.println("Iteration " + (x+1) + ": A " + A.toString() + " and B " + B.toString());
		sumAB += A.roll() + B.roll();
}
System.out.println("Final sum of rolls: " + sumAB);

int sum8 = 0;
int attempts = 0;
System.out.println("Game 2");
while (sum8 != 8) {
	attempts++;
	int aRoll = A.roll();
	int bRoll = B.roll();
	
	System.out.println("Iteration " + attempts + ": A " + A.toString() + " and B " + B.toString());
	if (aRoll + bRoll == 8) {
		sum8 = 8;
	}
}
System.out.println("It took us " + attempts + " iterations to roll a sum of 8");
}
}
