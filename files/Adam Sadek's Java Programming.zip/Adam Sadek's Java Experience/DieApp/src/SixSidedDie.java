import java.util.Random;
public class SixSidedDie {
	
private int value = 1;

public int roll() {
	Random random6 = new Random();
	value = random6.nextInt(6) + 1;
	return value;
}

public String toString() {
	String valueRolled = "Rolled: " + value;
	return valueRolled;
}

}

