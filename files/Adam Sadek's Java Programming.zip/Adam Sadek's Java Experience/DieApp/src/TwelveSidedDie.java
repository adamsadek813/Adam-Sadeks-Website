import java.util.Random;
public class TwelveSidedDie {

private int value = 1;

public int roll() {
	Random random12 = new Random();
	value = random12.nextInt(12) + 1;
	return value;
}

public String toString() {
	String valueRolled = "Rolled: " + value;
	return valueRolled;
}
}
