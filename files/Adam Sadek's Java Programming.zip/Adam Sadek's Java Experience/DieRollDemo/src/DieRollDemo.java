import java.util.Random;
public class DieRollDemo {
    public static void main (String args[]){
    	Random myGenerator = new Random();
    	int a, b, c, d, e, f, g, h, i, j;
    	
a = myGenerator.nextInt(6) + 1;
		System.out.println(a);

b = myGenerator.nextInt(6) + 1;
		System.out.println(b);
		
c = myGenerator.nextInt(6) + 1;
		System.out.println(c);
		
d = myGenerator.nextInt(6) + 1;
		System.out.println(d);
		
e = myGenerator.nextInt(6) + 1;
		System.out.println(e);
		
double average1 = (a+b+c+d+e) / 5.0;
System.out.println("First average is "+ average1);	

f = myGenerator.nextInt(6) + 1;
		System.out.println(f);
		
g = myGenerator.nextInt(6) + 1;
		System.out.println(g);
		
h = myGenerator.nextInt(6) + 1;
		System.out.println(h);
		
i = myGenerator.nextInt(6) + 1;
		System.out.println(i);
		
j = myGenerator.nextInt(6) + 1;
		System.out.println(j);
	
double average2 = (a+b+c+d+e+f+g+h+i+j) / 10.0;
System.out.println("Second average is "+ average2);	

    }
}
