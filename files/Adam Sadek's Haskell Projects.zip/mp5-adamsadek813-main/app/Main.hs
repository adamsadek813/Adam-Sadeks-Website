module Main where

import MP5b

main :: IO ()
main = playAI
