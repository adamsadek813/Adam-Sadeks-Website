module MP5a where

import Data.Maybe
import Data.Ord
import Data.List
import Data.Tree
import Data.Map (Map, empty, fromList, (!), keys, elems, assocs,
                 findWithDefault, member, insert, insertWith)
import System.Random
import System.Random.Shuffle
import Control.Concurrent
import Control.Monad.State
import System.IO
import System.Console.ANSI
import GHC.IO ( unsafePerformIO )
import Data.List.Split (chunksOf)


-- Search function from lecture notes
search :: (Eq a, Show a) =>
          (a -> Bool)
          -> (a -> [a])
          -> ([a] -> [a] -> [a])
          -> [a] -> [a]
          -> Maybe a
search goal getAdjPorts comb unvisited visited
  | null unvisited = Nothing
  | goal (head unvisited) = Just (head unvisited)
  | otherwise = let (n:ns) = unvisited
                in -- debug n $ -- uncomment to "debug"
                   search goal getAdjPorts comb
                          (comb (removeDups (getAdjPorts n)) ns)
                          (n:visited)
  where removeDups = filter (not . (`elem` (unvisited ++ visited)))


debug :: Show a => a -> b -> b
debug x y = unsafePerformIO clearScreen `seq`
            unsafePerformIO (setCursorPosition 0 0) `seq`
            unsafePerformIO (putStrLn $ show x) `seq`
            unsafePerformIO (threadDelay $ 3*10^5) `seq`
            y


-- Call with an admissible heuristic as the cost function to carry out A* search
bFSearch :: (Eq a, Show a, Ord b) =>
                   (a -> Bool)
                   -> (a -> [a])
                   -> (a -> b)
                   -> a -> Maybe a
bFSearch goal succ cost start = search goal succ comb [start] []
  where comb new old = sortOn cost (new ++ old)

type Ports = [Coords]
type FlightPath = [Coords]
type Dimensions = (Int, Int)
type Coords = (Int, Int)

data FlightMap = FlightMap {
                           dims :: Dimensions,
                           flightPath :: FlightPath,
                           portList :: Ports,
                           portAdjMap :: Map Coords [Coords]
                           } deriving (Eq)

makeBordersNandW :: Coords -> FlightMap -> (String, String)
makeBordersNandW c@(x, y) (FlightMap (w, h) fP pL pamap) =
 -- let nCoord = (x, y-1)
 --     wCoord = (x-1, y)
 --     getAdjPorts = findWithDefault [] c pamap
 -- in 
    ("+" ++ "------",
      ("|")
        ++ (if c `elem` pL then " P " else "   ")
        ++ (if c `elem` fP then " X " else "   "))

printMaze :: FlightMap -> String
printMaze m@(FlightMap (w, h) _ _ _) = (concat $ map makeRow $ chunksOf w printCells) ++ (concat $ replicate w "+------") ++ "+"
  where makeRow coords = let (l1, l2) = unzip coords
                         in concat l1 ++ "+ \n" ++ concat l2 ++ "| \n"
        printCells = [makeBordersNandW (x, y) m | y <- [1..h], x <- [1..w]]
instance Show FlightMap where
  show = printMaze

getPath :: FlightMap -> [Coords]
getPath (FlightMap _  _ p _) = p

getPL :: FlightMap -> [Coords]
getPL (FlightMap _ _ pL _) = pL

getAdjMap :: FlightMap -> Map Coords [Coords]
getAdjMap (FlightMap _ _ _ aM) = aM

buildFlightMap :: (Int,Int) -> FlightMap
buildFlightMap dim@(x,y) = make locations $ FlightMap dim [] locations empty
  where make [loc] map = map
        make (loc:locs) map = make (locs) $ connectPorts loc map
        locations = truncateNodes dim $ nodes ++ [(x,y)]

buildFlightMapRand :: (Int,Int) -> FlightMap
buildFlightMapRand (x,y) = make locations $ FlightMap (x,y) [] locations empty
  where 
    make [loc] map = map
    make (loc:locs) map = make locs $ connectPorts loc map
    locations = sort(truncateNodes (x,y) $ buildNodes (x,y) ++ [(x,y),(1,1)])

pythag :: Coords -> Coords -> Int
pythag (x1,y1) (x2,y2) = round $ sqrt(((fromIntegral x2) - (fromIntegral x1))^2+((fromIntegral y2) - (fromIntegral y1))^2)

nodes :: [Coords]
nodes = [(1,1),(2,8),(14,5),(9,9),(8,6),(17,1),(9,12), (14,9),
  (12,11),(11,9),(8,8),(12,3),(11,3),(15,4),(12,9),(5,18),(7,12),
  (20,17),(5,20),(16,16),(3,4),(11,7),(18,16),(20,2),(1,14)]

truncateNodes :: Dimensions -> [Coords] -> [Coords]
truncateNodes _ [] = []
truncateNodes (w,h) ((x,y):xs)
  | w >= x && h >= y = (x,y):truncateNodes (w,h) xs
  | otherwise = truncateNodes (w,h) xs

buildNodes :: (Int,Int) -> [(Int,Int)]
buildNodes (w,h) = take (h+10) $ randomPair (1,w) $ mkStdGen (w*h)
  where randomPair range gen = zip (randomRs range a) (randomRs range b) 
          where (a,b) = split gen  

buildAdjPortMap :: [Coords] -> FlightMap -> FlightMap
buildAdjPortMap [loc] map = map
buildAdjPortMap (loc:locs) map = buildAdjPortMap locs $ connectPorts loc map   

connectPorts :: Coords -> FlightMap -> FlightMap
connectPorts coord1 fm@(FlightMap _ _ pL@((x,y):_) pamap) =
  fm {portAdjMap = insertWith (++) coord1 (getAdjPorts coord1 pL) pamap}

getAdjPorts :: Coords -> Ports -> Ports
getAdjPorts _ [] = []
getAdjPorts coord (x:xs)
  | pythag coord x <= 5 && coord /= x = x:getAdjPorts coord xs
  | otherwise = getAdjPorts coord xs

bestPort :: FlightMap -> [FlightMap]
bestPort fm@(FlightMap dims fp@(loc:_) _ pamap) =
  do
    getAdjPorts <- filter (not . flip elem fp) $ findWithDefault [] loc pamap
    return $ fm {flightPath = getAdjPorts:fp}

findPath :: FlightMap -> Maybe FlightMap
findPath fm@(FlightMap (w,h) _ _ _) =
  do
    let 
      cost fm'@(FlightMap _ fp@((x,y):_) _ _ ) = pythag (x,y) (w,h) + length fp
    bFSearch ((==(w,h)) . head . flightPath) bestPort cost (fm {flightPath = [(1,1)]})