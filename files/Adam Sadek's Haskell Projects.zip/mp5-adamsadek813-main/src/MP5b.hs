module MP5b where

import Data.Maybe
import Data.Ord
import Data.List
import Data.Tree
import Data.Map (Map, empty, fromList, (!), findWithDefault, member, insert, insertWith)
import System.Random
import System.Random.Shuffle
import Control.Concurrent
import Control.Monad.State
import System.IO
import System.Console.ANSI
import GHC.IO


{- Replace with your own game data types  -}

data Player = YOU | AI deriving(Eq)

type Move = Int

type Pile = Int

data Board = Board {
                    playedMoves :: [Int], 
                    board::[Int], 
                    player :: Player} 
                    deriving(Eq)


{- Some convenience functions and types -- feel free to replace/modify  -}

prune :: Int -> Tree a -> Tree a
prune 0 (Node x _) = Node x []
prune _ (Node x []) = Node x []
prune n (Node x ns) = Node x $ map (prune (n-1)) ns


data Scored a = Scored { score :: Int, scoredVal :: a }


instance Eq (Scored a) where
  (Scored x _) == (Scored y _) = x == y


instance Ord (Scored a) where
  compare (Scored x _) (Scored y _) = compare x y


instance Show a => Show (Scored a) where
  show (Scored s v) = "Score: " ++ show s ++ "\n\n" ++ show v


-- Minimax function from lecture notes
minimax :: (a -> Scored a) -> Tree a -> Scored a
minimax scorefn (Node _ ns) = maximize ns
  where maximize = maximumBy (comparing score) . map (eval minimize)
        minimize = minimumBy (comparing score) . map (eval maximize)
        eval _ (Node x []) = scorefn x
        eval f (Node x ns) = let Scored s _ = f ns in Scored s x


drawBoard :: Pile -> Board
drawBoard pile = Board [] (moves 1 pile) YOU
  where
    moves _ 0 = []
    moves counter pile = counter:moves (counter+1) (pile-1)

printBoard :: Board -> String
printBoard b@(Board _ ls p) = show (length ls) ++ " sticks left\nCurrent Turn: "++p'
  where
    ls' = show ls
    p'
      | p == YOU = "You"
      | otherwise = "AI"
instance Show Board where
    show = printBoard

updateBoard :: Board -> Move -> Board
updateBoard b@(Board pM ls t) remove = Board (pM++[remove]) (drop remove ls) (whoseTurn t)

whoseTurn :: Player -> Player
whoseTurn YOU = AI
whoseTurn AI = YOU

validTurn :: Board -> Move ->  Bool
validTurn b@(Board _ ls _) move
  | move > 0 && move <= 3 && move <= length ls = True
  | otherwise = False

playMoves :: [Int] -> Board -> Board
playMoves xs b = foldl updateBoard b xs

win :: Player -> Board -> Bool
win p b@(Board _ ls t)
  | p == t && null ls = True
  | otherwise = False

getScoreBoard :: Player -> Board -> Scored Board
getScoreBoard p b@(Board pM ls _)
 | win p b = Scored (-10) b
 | win (whoseTurn p) b = Scored 10 b
 | otherwise = scoreBoard pM where 
     scoreBoard [] = Scored 0 b
     scoreBoard pM = Scored (length ls - length pM) b

gameTree :: Board -> Tree Board
gameTree b = Node b
             $ map gameTree
             $ map (\i -> updateBoard b (i+1)) moves
  where moves | win YOU b = []
              | win AI b = []
              | otherwise = [0,1,2]

printTree :: Board -> IO ()
printTree = putStrLn . drawTree . fmap (show . getScoreBoard YOU) . gameTree

-- Plays a game with the AI
playAI :: IO ()
playAI = do
  putStr "Try to pick up the last stick! (21 sticks)\n"
  putStr "Would you like to go first? [y] or [n] "
  answer <- getLine
  if answer == "y"
    then
      do play YOU (Board [] [1..21] YOU)
  else 
        do play AI (Board [] [1..21] AI)
  where play _ b
          | win AI b = putStrLn "You win!"
          | win YOU b = putStrLn "You lost!"
        play YOU b = do
          putStr "How many sticks do you want to take? (1-3): "
          move <- readLn
          if validTurn b move
            then 
              do
                let b' = updateBoard b move
                print b'
                play AI b'
            else
              do
                putStrLn "Sorry. Not a valid move."
                play YOU b
        play AI b = do
          let b' = scoredVal $ minimax (getScoreBoard AI) (gameTree b)
          print b'
          play YOU b'
